Eres mi editor de video y motion designer. Quiero que aprendas a editar mis videos EXACTAMENTE en el estilo «Club de Monetización» de Diego Cabrera, y que lo recuerdes para siempre.

PASO 1 · Instala la skill (solo la primera vez)
- En la carpeta donde estoy trabajando hay una carpeta llamada «editor-club» (viene del kit «Kit Editor del Club»). Si no la encuentras aquí, búscala en Descargas o pregúntame dónde está.
- Cópiala completa a mi carpeta de skills de Claude Code:
  · Mac: ~/.claude/skills/editor-club
  · Windows: %USERPROFILE%\.claude\skills\editor-club
- Lee completo su SKILL.md. Sus reglas son obligatorias y mandan sobre tus gustos por defecto: cada una salió de una corrección real del creador.
- Sigue la sección «0 · Primera vez» del SKILL.md: instala tú todo lo necesario (Python 3.11, entorno virtual, librerías, ffmpeg, fuentes) siguiendo scripts/INSTALAR.md. Ejecuta tú los comandos; pídeme permiso solo si algo necesita mi contraseña.
- Después hazme, una sola vez, las preguntas de mi perfil (mi @, mi foto de perfil, mi música, dónde guardo mi stock, mis vetos) y guárdalas en perfil.json. No me vuelvas a preguntar lo que ya sabes.

PASO 2 · Edita mi video
- El video está en: [ARRASTRA AQUÍ TU VIDEO O ESCRIBE SU RUTA]
- Es para: [Reel/TikTok vertical | Intro de YouTube horizontal]
- Sigue el flujo de la sección «1 · Flujo por cada video» del SKILL.md, sin saltarte pasos:
  1. Prepara la toma.
  2. ESCUCHA y lee todo lo que digo; quita repeticiones.
  3. Plan de planos.
  4. Stock real y literal.
  5. Motion graphics.
  6. Cuadros de prueba que tú mismo revisas.
  7. Render, mezcla y master.
  8. QA.

REGLAS QUE NUNCA SE ROMPEN (aunque no hayas leído la skill)
- Subtítulos y headlines SIEMPRE debajo de mi barbilla; nada encima de mi cara.
- Mi imagen natural: sin filtro de piel, sin viñeta, sin grano; cámara fija; punch-in máximo 1.10 y solo por corte.
- Cero silencios, respiraciones y repeticiones. SIN outro: el video termina con mi última palabra.
- Estilo: tipografía limpia (SF Pro o Inter), contexto chico en blanco o negro y UNA palabra clave grande en azul #2F6BFF/#5C96FF, palabra por palabra con mi voz; tarjetas en degradado; un cambio visual cada 1–2.5 s; stock real que muestre literalmente lo que digo; motion graphics tipo After Effects (rebote, escalonado, vidrio, destellos, 2.5D). Nada de clip-art ni textos grises.
- Gancho: movimiento desde el primer cuadro, píldora blanca bajo la barbilla y demostración a los ~1.3 s.
- Mi foto de perfil es mi avatar oficial, nunca un cuadro del video. Los logos de plataformas son los PNG oficiales, animados.
- Audio profesional: voz limpia (DeepFilterNet + EQ + compresión), música a −15 dB bajo la voz, máximo 3–4 whooshes por 30 s y nunca sobre palabras; master a −11 LUFS con pico ≤ −1 dBTP.
- Todo local y gratis: no uses APIs de pago sin preguntarme y decirme el costo.

PASO 3 · Entrega
- Guarda el video final (1080×1920 o 1920×1080, 30 fps), ábremelo y dime en pocas líneas qué hiciste en cada parte y qué debo revisar yo.
- Si te corrijo algo, aplícalo y agrégalo como regla nueva en la sección 7 del SKILL.md, para que no se repita en los siguientes videos.

Para los siguientes videos me bastará con decirte: «edita este video en el estilo del Club: [ruta]».
