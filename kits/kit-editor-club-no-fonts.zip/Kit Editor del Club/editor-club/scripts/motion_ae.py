"""motion_ae — efectos tipo After Effects para el motor de los reels (estilo Club de Monetización).

Destilado de las referencias «motion-design-with-code» y adaptado al render de los reels: cuadros RGB float32 0–1 (H×W×3) y capas RGBA PREMULTIPLICADAS, cada cuadro función pura del tiempo.

    import motion_ae as ae          # vive junto a motor_club.py en scripts/

Contenido
  Curvas ........ ease_out_back, ease_out_elastic, spring, ease_in_out_expo, stagger
  Cámara 2.5D ... Camera (zoom/paneo/giro suaves) + cam.place(capa, x, y, z) con paralaje por profundidad
  Composición ... over (normal), add (aditivo para halos), glow (bloom), drop_shadow
  Vidrio ........ glass_card: tarjeta glassmorphism (desenfoca lo de atrás, tinte, borde con brillo, sombra)
  Revelados ..... wipe_reveal (barrido con borde suave), circle_reveal, light_sweep (destello que recorre)
  Detalle vivo .. particles (polvo/partículas sutiles), grid_floor (rejilla en perspectiva)
  Transiciones .. rect_morph (match cut: una tarjeta se convierte en el siguiente marco), whip_blur
  Error ......... glitch (separación RGB + rebanadas desplazadas)
  Holograma ..... holo_outline (contorno luminoso con esquinas sobre un objeto de la toma)
"""
import math

import cv2
import numpy as np

# ------------------------------------------------------------------ curvas (nada lineal)
def clamp(x, a=0.0, b=1.0): return a if x < a else b if x > b else x
def ramp(t, a, b): return clamp((t - a) / (b - a)) if b > a else float(t >= a)

def ease_out_back(u, s=1.70158):
    """Llega con un pequeño rebote (overshoot). s≈1.7 sutil, 2.5 marcado."""
    u = clamp(u) - 1
    return 1 + (s + 1) * u ** 3 + s * u ** 2

def ease_out_elastic(u, periodo=0.32):
    u = clamp(u)
    if u in (0.0, 1.0): return u
    return 2 ** (-10 * u) * math.sin((u - periodo / 4) * 2 * math.pi / periodo) + 1

def spring(t, freq=4.5, damping=6.0):
    """Resorte físico 0→1 (t en segundos desde que arranca). Más natural que back para logos y botones."""
    if t <= 0: return 0.0
    return 1 - math.exp(-damping * t) * math.cos(2 * math.pi * freq * t)

def ease_in_out_expo(u):
    u = clamp(u)
    if u in (0.0, 1.0): return u
    return 2 ** (20 * u - 10) / 2 if u < 0.5 else (2 - 2 ** (-20 * u + 10)) / 2

def ease_out_cubic(u): u = clamp(u); return 1 - (1 - u) ** 3

def stagger(t, i, t0, paso=0.06, dur=0.45, curva=ease_out_back):
    """Progreso del elemento i de una serie que entra escalonada: arranca en t0 + i·paso y dura dur."""
    return curva(ramp(t, t0 + i * paso, t0 + i * paso + dur))

# ------------------------------------------------------------------ composición
def over(fr, rgba, x, y, op=1.0):
    """Pega una capa RGBA premultiplicada en (x, y) esquina sup. izq. (recorta a los bordes)."""
    if op <= 0.002: return
    H, W = fr.shape[:2]; x, y = int(round(x)), int(round(y)); h, w = rgba.shape[:2]
    x0, y0, x1, y1 = max(0, x), max(0, y), min(W, x + w), min(H, y + h)
    if x1 <= x0 or y1 <= y0: return
    s = rgba[y0 - y:y1 - y, x0 - x:x1 - x]; a = s[..., 3:4] * op
    fr[y0:y1, x0:x1] = fr[y0:y1, x0:x1] * (1 - a) + s[..., :3] * op

def add(fr, rgb, x, y, op=1.0):
    """Suma aditiva (halos, luces, destellos). rgb puede ser H×W×3."""
    H, W = fr.shape[:2]; x, y = int(round(x)), int(round(y)); h, w = rgb.shape[:2]
    x0, y0, x1, y1 = max(0, x), max(0, y), min(W, x + w), min(H, y + h)
    if x1 <= x0 or y1 <= y0: return
    fr[y0:y1, x0:x1] = np.minimum(1.0, fr[y0:y1, x0:x1] + rgb[y0 - y:y1 - y, x0 - x:x1 - x] * op)

def glow(rgba, radio=18, fuerza=0.9, color=None):
    """Bloom de una capa: devuelve RGB para sumar con add() en la misma posición (con margen ya incluido)."""
    pad = int(radio * 2)
    a = np.pad(rgba, ((pad, pad), (pad, pad), (0, 0)))
    base = a[..., :3] if color is None else a[..., 3:4] * np.asarray(color, np.float32)
    g = cv2.GaussianBlur(base, (0, 0), radio) * fuerza + cv2.GaussianBlur(base, (0, 0), radio * 0.35) * fuerza * 0.6
    return g, pad

def drop_shadow(fr, rgba, x, y, dist=14, blur=18, op=0.35):
    a = rgba[..., 3]; pad = int(blur * 2)
    s = cv2.GaussianBlur(np.pad(a, pad), (0, 0), blur) * op
    sh = np.zeros(s.shape + (4,), np.float32); sh[..., 3] = s
    over(fr, sh, x - pad, y - pad + dist)

def rrect_mask(w, h, r, feather=1.2):
    """Máscara de rectángulo redondeado antialias (supermuestreo ×4)."""
    S = 4; m = np.zeros((h * S, w * S), np.uint8); rr = int(r * S)
    cv2.rectangle(m, (rr, 0), (w * S - rr, h * S), 255, -1); cv2.rectangle(m, (0, rr), (w * S, h * S - rr), 255, -1)
    for cx, cy in ((rr, rr), (w * S - rr, rr), (rr, h * S - rr), (w * S - rr, h * S - rr)):
        cv2.circle(m, (cx, cy), rr, 255, -1, cv2.LINE_AA)
    m = cv2.resize(m, (w, h), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
    return cv2.GaussianBlur(m, (0, 0), feather) if feather > 0 else m

# ------------------------------------------------------------------ vidrio (glassmorphism)
def glass_card(fr, x, y, w, h, r=34, op=1.0, tinte=(1, 1, 1), tinte_op=0.10, blur=24, borde=0.55, sombra=0.30):
    """Tarjeta de vidrio esmerilado: desenfoca lo que hay detrás, tiñe, borde fino con brillo arriba y sombra suave.
    Dibuja directo en fr. Devuelve la máscara (para recortar contenido dentro)."""
    H, W = fr.shape[:2]; x, y, w, h = int(x), int(y), int(w), int(h)
    m = rrect_mask(w, h, r)
    if sombra > 0:
        sh = np.zeros((h, w, 4), np.float32); sh[..., 3] = m
        drop_shadow(fr, sh, x, y, dist=int(h * 0.04) + 8, blur=26, op=sombra * op)
    x0, y0, x1, y1 = max(0, x), max(0, y), min(W, x + w), min(H, y + h)
    if x1 <= x0 or y1 <= y0: return m
    pad = blur * 2
    X0, Y0, X1, Y1 = max(0, x0 - pad), max(0, y0 - pad), min(W, x1 + pad), min(H, y1 + pad)
    bl = cv2.GaussianBlur(fr[Y0:Y1, X0:X1], (0, 0), blur)[y0 - Y0:y1 - Y0, x0 - X0:x1 - X0]
    mm = m[y0 - y:y1 - y, x0 - x:x1 - x][..., None] * op
    tin = np.asarray(tinte, np.float32)
    vidrio = bl * (1 - tinte_op) + tin * tinte_op
    fr[y0:y1, x0:x1] = fr[y0:y1, x0:x1] * (1 - mm) + vidrio * mm
    # borde: más brillante arriba (luz cenital), tenue abajo
    ed = np.clip(m - cv2.erode(m, np.ones((3, 3), np.uint8)), 0, 1)
    grad = np.linspace(1.0, 0.25, h, dtype=np.float32)[:, None]
    add(fr, (ed * grad * borde)[..., None] * np.ones(3, np.float32), x, y, op)
    return m

# ------------------------------------------------------------------ revelados
def wipe_reveal(rgba, u, angulo=0.0, suave=0.08):
    """Barrido que revela la capa de izquierda a derecha (angulo en grados), con borde suave. u 0→1."""
    h, w = rgba.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    a = math.radians(angulo); d = (xx * math.cos(a) + yy * math.sin(a))
    d = (d - d.min()) / (d.max() - d.min() + 1e-6)
    k = np.clip((u * (1 + suave) - d) / suave, 0, 1)[..., None]
    return rgba * k

def circle_reveal(rgba, u, cx=None, cy=None, suave=24):
    h, w = rgba.shape[:2]; cx = w / 2 if cx is None else cx; cy = h / 2 if cy is None else cy
    R = math.hypot(max(cx, w - cx), max(cy, h - cy)) * u
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    k = np.clip((R - np.hypot(xx - cx, yy - cy)) / suave, 0, 1)[..., None]
    return rgba * k

def light_sweep(rgba, u, ancho=0.18, fuerza=0.55, angulo=20.0):
    """Destello especular que cruza la capa (premium, «producto Apple»). Devuelve RGB aditivo dentro del alfa."""
    h, w = rgba.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    a = math.radians(angulo); d = (xx * math.cos(a) + yy * math.sin(a)) / (w * math.cos(a) + h * math.sin(a))
    c = -ancho + u * (1 + 2 * ancho)
    s = np.exp(-((d - c) / (ancho * 0.5)) ** 2) * fuerza
    return (s * rgba[..., 3])[..., None] * np.ones(3, np.float32)

# ------------------------------------------------------------------ cámara 2.5D
class Camera:
    """Cámara virtual: (cx, cy) a dónde mira, zoom y giro. Las capas con z > 1 están más lejos (se mueven menos:
    paralaje). Movimientos suaves: alimentar cx/cy/zoom con curvas, nunca lineales."""
    def __init__(self, W, H, cx=None, cy=None, zoom=1.0, rot=0.0):
        self.W, self.H = W, H; self.cx = W / 2 if cx is None else cx; self.cy = H / 2 if cy is None else cy
        self.zoom, self.rot = zoom, rot

    def to_screen(self, x, y, z=1.0):
        k = self.zoom / z
        dx, dy = (x - self.W / 2) - (self.cx - self.W / 2) / z, (y - self.H / 2) - (self.cy - self.H / 2) / z
        c, s = math.cos(math.radians(self.rot)), math.sin(math.radians(self.rot))
        return self.W / 2 + k * (dx * c - dy * s), self.H / 2 + k * (dx * s + dy * c), k

    def place(self, fr, rgba, x, y, z=1.0, op=1.0):
        """Coloca una capa centrada en (x, y) del mundo a profundidad z (1 = plano principal)."""
        sx, sy, k = self.to_screen(x, y, z)
        if abs(k - 1) > 1e-3 or abs(self.rot) > 0.05:
            h, w = rgba.shape[:2]
            M = cv2.getRotationMatrix2D((w / 2, h / 2), -self.rot, k)
            nw, nh = int(w * k + 4), int(h * k + 4)
            M[0, 2] += nw / 2 - w / 2; M[1, 2] += nh / 2 - h / 2
            rgba = cv2.warpAffine(rgba, M, (nw, nh), flags=cv2.INTER_LINEAR)
        over(fr, rgba, sx - rgba.shape[1] / 2, sy - rgba.shape[0] / 2, op)

# ------------------------------------------------------------------ detalle vivo
def particles(fr, t, n=60, seed=7, color=(0.36, 0.59, 1.0), op=0.5, area=None, vel=18.0, tam=(1.2, 3.2)):
    """Partículas sutiles que flotan (polvo de luz). Deterministas: cada cuadro es función de t."""
    H, W = fr.shape[:2]; x0, y0, x1, y1 = area or (0, 0, W, H)
    rng = np.random.default_rng(seed)
    px = rng.uniform(x0, x1, n); py = rng.uniform(y0, y1, n); sz = rng.uniform(*tam, n)
    ph = rng.uniform(0, 2 * math.pi, n); sp = rng.uniform(0.4, 1.0, n)
    yy = (py - t * vel * sp - y0) % (y1 - y0) + y0
    xx = px + np.sin(t * 0.7 + ph) * 12
    lay = np.zeros((H, W), np.float32)
    for x, y, s, f in zip(xx, yy, sz, 0.5 + 0.5 * np.sin(t * 2.2 + ph)):
        cv2.circle(lay, (int(x * 4), int(y * 4)), max(1, int(s * 4)), float(f), -1, cv2.LINE_AA, 2)
    lay = cv2.GaussianBlur(lay, (0, 0), 1.2)
    fr[:] = np.minimum(1.0, fr + lay[..., None] * np.asarray(color, np.float32) * op)

def grid_floor(fr, t, color=(0.36, 0.59, 1.0), horizonte=0.42, op=0.55, vel=0.25, celdas=14):
    """Rejilla en perspectiva que avanza (look técnico/IG). Dibuja directo en fr."""
    H, W = fr.shape[:2]; hy = int(H * horizonte); lay = np.zeros((H, W), np.float32)
    for i in range(-celdas, celdas + 1):
        cv2.line(lay, (int(W / 2 + i * W / celdas * 0.12), hy), (int(W / 2 + i * W / celdas * 2.2), H), 1.0, 1, cv2.LINE_AA)
    off = (t * vel) % 1.0
    for k in range(18):
        z = (k + off) / 18; y = int(hy + (H - hy) * z ** 2.2)
        cv2.line(lay, (0, y), (W, y), float(0.25 + 0.75 * z), 1, cv2.LINE_AA)
    fade = np.clip((np.arange(H, dtype=np.float32) - hy) / (H - hy), 0, 1)[:, None] ** 0.8
    lay *= fade
    fr[:] = np.minimum(1.0, fr + (lay + cv2.GaussianBlur(lay, (0, 0), 6) * 0.8)[..., None] * np.asarray(color, np.float32) * op)

# ------------------------------------------------------------------ transiciones
def rect_morph(r0, r1, u, curva=ease_in_out_expo):
    """Match cut: interpola un rectángulo (x, y, w, h, radio) hacia otro; la tarjeta se vuelve el siguiente marco."""
    k = curva(u)
    return tuple(a + (b - a) * k for a, b in zip(r0, r1))

def whip_blur(fr, fuerza, horizontal=True):
    """Desenfoque direccional de barrido rápido (whip pan) para cortes con energía. fuerza 0–1."""
    if fuerza <= 0.01: return fr
    n = int(3 + fuerza * 60) | 1
    k = np.zeros((n, n), np.float32)
    if horizontal: k[n // 2, :] = 1.0 / n
    else: k[:, n // 2] = 1.0 / n
    return cv2.filter2D(fr, -1, k)

# ------------------------------------------------------------------ error / falla
def glitch(fr, t, fuerza=1.0, seed=3):
    """Falla digital breve: separación RGB + rebanadas desplazadas. Usar 0.1–0.3 s, nunca sobre su cara."""
    H, W = fr.shape[:2]; rng = np.random.default_rng(seed + int(t * 30))
    out = fr.copy(); k = int(8 * fuerza)
    out[..., 0] = np.roll(fr[..., 0], k, 1); out[..., 2] = np.roll(fr[..., 2], -k, 1)
    for _ in range(int(6 * fuerza)):
        y = rng.integers(0, H - 20); h = rng.integers(6, 40); dx = int(rng.integers(-60, 60) * fuerza)
        out[y:y + h] = np.roll(out[y:y + h], dx, 1)
    return out

# ------------------------------------------------------------------ holograma sobre la toma
def holo_outline(fr, x, y, w, h, u, color=(0.36, 0.59, 1.0), esquina=0.18, grosor=3, op=1.0):
    """Contorno luminoso con esquinas tipo HUD alrededor de un objeto real (la caja sale del seguimiento).
    u 0→1 dibuja las esquinas; con brillo aditivo. Nunca sobre su cara."""
    H, W = fr.shape[:2]; lay = np.zeros((H, W), np.float32); L = min(w, h) * esquina * clamp(u * 1.4)
    for (cx, cy, sx, sy) in ((x, y, 1, 1), (x + w, y, -1, 1), (x, y + h, 1, -1), (x + w, y + h, -1, -1)):
        cv2.line(lay, (int(cx), int(cy)), (int(cx + sx * L), int(cy)), 1.0, grosor, cv2.LINE_AA)
        cv2.line(lay, (int(cx), int(cy)), (int(cx), int(cy + sy * L)), 1.0, grosor, cv2.LINE_AA)
    if u > 0.6:
        cv2.rectangle(lay, (int(x), int(y)), (int(x + w), int(y + h)), 0.25 * clamp((u - 0.6) / 0.4), 1, cv2.LINE_AA)
    g = lay + cv2.GaussianBlur(lay, (0, 0), 8) * 1.2
    fr[:] = np.minimum(1.0, fr + g[..., None] * np.asarray(color, np.float32) * op)
