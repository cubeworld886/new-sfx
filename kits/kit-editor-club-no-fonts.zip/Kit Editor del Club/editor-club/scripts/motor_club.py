#!/usr/bin/env python
"""motor_club — el MOTOR del estilo «Club de Monetización» (vertical 1080×1920 u horizontal 1920×1080, 30 fps).

Lee una carpeta preparada por preparar_toma.py (toma-limpia.mp4, palabras.json, caras.json, info.json) y un plan.json
con la lista de planos, y dibuja cada cuadro: su cara con subtítulos BAJO LA BARBILLA, tarjetas claras/azules/oscuras,
stock, videos flotantes, prompt de vidrio, comparativas, pasos, contador, chat… Nada de rutas fijas: todo sale del plan.

    python motor_club.py render  plan.json [--procesos 4]       → <salida>/video.mp4 (sin audio)
    python motor_club.py prueba  plan.json 0.5 3.2 12.9 …       → <salida>/prueba/*.jpg (+ «-zona» con la zona segura)
    python motor_club.py qa      plan.json                       → revisa TODO el video (textos, barbilla, zona segura)
    python motor_club.py hoja    plan.json                       → <salida>/hoja.jpg (12 cuadros, para revisar el estilo)
    python motor_club.py info    plan.json                       → planos con su punch-in, tamaño de clave y barbilla

──────────────────────────────── plan.json ────────────────────────────────
{
  "material": "../mi-toma",              carpeta de preparar_toma.py (relativa al plan)
  "salida":   "../mi-toma/edicion",      opcional (por defecto <material>/edicion)
  "formato":  "vertical" | "horizontal", opcional (por defecto el de info.json)
  "fin":      34.67,                     opcional (por defecto: última palabra + 0.03 s → termina con su voz)
  "marca":    {"avatar": "marca/avatar.png", "nombre": "Tu Nombre", "usuario": "@tu_usuario", "logos": "marca/logos"},
  "planos": [ {"t0": 0.0, "t1": 1.4, "tipo": "gancho", "texto": "Claude edita mis videos"}, … ]
}
Textos de cualquier plano: "contexto" (línea chica) y "clave" (palabra grande azul); "serif": true = clave en itálica
serif. Cada palabra aparece en SU tiempo (se busca sola en palabras.json dentro del plano; o se da a mano como
[["si", 27.5], ["lo", 27.6]] / ["completo", 28.06]). "beats": [{contexto, clave, serif}, …] cambia el texto dentro del
mismo plano (entra el siguiente cuando empieza su primera palabra).

Tipos (todos en estilo p030/p031/p032):
  cara            su toma + contexto/clave bajo la barbilla. "s": punch-in mínimo (se elige solo ≤ 1.10).
  gancho          su toma + píldora blanca bajo la barbilla + acercamiento lento 1.00→1.04. "texto", "pildora_hasta"
                  (la píldora sigue sobre los planos siguientes hasta ese segundo), "logos" (horizontal: logos oficiales
                  de marca/logos que entran con resorte en el espacio libre).
  tarjeta_clara | tarjeta_azul | tarjeta_oscura   fondo + contexto chico + clave grande, con "grafico" opcional:
        {"tipo": "punto"} · {"tipo": "giro"} · {"tipo": "numero", "valor": "20", "unidad": "USD", "en": "veinte"}
        {"tipo": "interruptor", "en": "posibilidad"}
        {"tipo": "perfil", "iniciales": "ED", "nombre": "Editor de video", "detalle": "Entrega en 3 días",
                 "chip": "En el equipo", "tachar_en": "despedir", "chip_tachado": "Contrato terminado"}
        {"tipo": "perfil_nuevo", "nombre": "Claude", "detalle": "Entrega en minutos", "chip": "Editor nuevo"}
        {"tipo": "barras", "filas": [{"etiqueta": "Editor", "valor": "3 días", "lento": true},
                                     {"etiqueta": "Claude", "valor": "12 min"}], "en": "entrega"}
        {"tipo": "lista", "titulo": "Correcciones", "items": ["…", "…"], "en": "correcciones"}
        {"tipo": "vacante", "chip": "Vacante", "titulo": "Editor de video", "items": ["…"], "nuevo": "Inteligencia
                 artificial", "nuevo_en": "hoy"}
        {"tipo": "rejilla", "etiqueta": "Editor", "encender": [0, 2, 4, 5, 7], "insignia": "IA", "en": "utilizar"}
        {"tipo": "abanico", "etiqueta": "SKILL", "tarjetas": [{"titulo": "…", "detalle": "…", "icono": "play|curva|onda"}],
                 "abrir_en": "skills", "insignia": "En uso", "insignia_en": "utilizando"}
        {"tipo": "logos", "logos": ["youtube", "facebook"]}       (PNG oficiales en marca/logos/, los pone el alumno)
        {"tipo": "celular", "fuente": "stock/app.mp4"}             (sin fuente: marcador generado)
  stock           video o foto a pantalla completa, oscurecido (cinematográfico) + texto. "fuente", "desde".
  video_flotante  "fuentes": [..] (1–5) flotando con esquinas redondeadas y sombra; "modo": "fila" | "demo" (cámara
                  2.5D con paralaje sobre rejilla) | "trayectoria" (viaja por una curva con fotogramas clave); "fondo".
  prompt          tarjeta de VIDRIO con el texto del prompt ("texto" o "archivo") y botón Copiar → ✓ Copiado ("copiar_en").
  comparativa     "antes_etiqueta", "antes" (se tacha en azul), "despues_etiqueta", "despues" (grande, azul).
  pasos           "pasos": ["Graba", "Claude edita", "Publica"], "check_en": "bien" → cada número pasa a ✓.
  contador        avatar + nombre + número que sube "desde"→"hasta" ("llega_en") + botón Suscribirse → Suscrito.
  chat            burbuja del usuario ("pregunta") y respuesta ("respuesta") que pasa de «…» a ✓.
  titulo_tecnico  rejilla técnica oscura + "titulo" que se descifra letra por letra.
  cierre          su cara + CTA bajo la barbilla (sin outro: el video termina con su voz).
"stock"/"fuente" sin archivo → se dibuja un marcador generado (degradado azul) para que el alumno ponga su clip.

Reglas del estilo que el motor garantiza (y la QA revisa):
  · Subtítulos SIEMPRE bajo la barbilla: el plano elige el punch-in mínimo (1.00/1.03/1.05/1.08/1.10, anclado abajo:
    la barbilla SUBE) que deja el texto ≥ 40 px bajo la barbilla más baja del plano. Nada encima de la cara.
  · Zona segura vertical: nada en y < 220, y > 1500, ni x > 930 entre y 900–1600. Horizontal: 96 px a los lados,
    80 px arriba y abajo. Textos centrados.
  · Paleta: azul #2F6BFF sobre claro, #5C96FF sobre oscuro, blanco y negro. Nada gris.
  · Sin filtros de piel. Avatar SIEMPRE desde el PNG del alumno, nunca un cuadro del video.
"""
from __future__ import annotations

import glob
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

cv2.setNumThreads(2)
AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import motion_ae as ae  # noqa: E402
from comun import ffmpeg, procesos_render  # noqa: E402

# ══════════════════════════════════════════ configuración y geometría ══════════════════════════════════════════
W, H, FPS = 1080, 1920, 30
VERTICAL = True
G: dict = {}
_yy = _xx = DITHER = None


def configurar(vertical: bool = True):
    """Fija el formato. Vertical 1080×1920 (zona segura de Reels/TikTok/Shorts) u horizontal 1920×1080 (YouTube)."""
    global W, H, VERTICAL, G, _yy, _xx, DITHER
    VERTICAL = vertical
    W, H = (1080, 1920) if vertical else (1920, 1080)
    if vertical:
        G = dict(cx=540, key_base=1472, ink_max=1496, small=46, big=128, maxw=780, area=(150, 300, 930, 1300),
                 anchor=(540.0, 1920.0), chin_margin=15, safe=dict(top=220, bottom=1500, right=930, band=(900, 1600),
                                                                  left=150))
    else:
        G = dict(cx=960, key_base=958, ink_max=996, small=46, big=120, maxw=1300, area=(330, 110, 1590, 780),
                 anchor=(960.0, 1080.0), chin_margin=10, safe=dict(top=80, bottom=1000, right=1824, band=(0, 1080),
                                                                  left=96))
    _yy, _xx = np.mgrid[0:H // 4, 0:W // 4].astype(np.float32)
    DITHER = (np.random.default_rng(7).random((H, W, 1), np.float32) - 0.5) / 255


configurar(True)


def area():
    x0, y0, x1, y1 = G["area"]
    return x0, y0, x1, y1, (x0 + x1) / 2, (y0 + y1) / 2


# ══════════════════════════════════════════ color ══════════════════════════════════════════
def c(*v): return np.array(v, np.float32) / 255


WHITE = c(255, 255, 255); BLACK = c(10, 12, 18)
BLUE = c(47, 107, 255)           # #2F6BFF sobre claro
BLUE_D = c(92, 150, 255)         # #5C96FF sobre oscuro


# ══════════════════════════════════════════ curvas ══════════════════════════════════════════
def clamp(x, a=0., b=1.): return max(a, min(b, x))
def ramp(t, a, b): return clamp((t - a) / (b - a)) if b > a else float(t >= a)
def eo(u): u = clamp(u); return 1.0 if u >= 1 else 1 - (1 - u) ** 3
def eio(u): u = clamp(u); return 4 * u ** 3 if u < .5 else 1 - (-2 * u + 2) ** 3 / 2
def lerp(a, b, u): return a + (b - a) * u


back = ae.ease_out_back; spring = ae.spring; expo = ae.ease_in_out_expo

# ══════════════════════════════════════════ fuentes portátiles ══════════════════════════════════════════
FUENTES = AQUI / "fuentes"
MAC = Path("/System/Library/Fonts")
WINF = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
WGT_SF = dict(Regular=400, Medium=510, Semibold=590, Bold=700, Heavy=860)      # ejes de SF Pro / New York (Mac)
WGT = dict(Regular=400, Medium=500, Semibold=600, Bold=700, Heavy=800)         # Inter / Playfair (OFL)
_fc: dict = {}


def _candidatas(fam, weight):
    """Cascada: fuentes del sistema Mac (SF Pro / New York) → libres del kit (Inter / Playfair / Instrument Serif /
    JetBrains Mono, OFL) → Windows (Segoe UI / Georgia / Consolas). KIT_FUENTES=libres salta las de Mac."""
    libres = os.environ.get("KIT_FUENTES") == "libres"
    if fam == "sf":
        mac = [("mac_sf", MAC / "SFNS.ttf")]
        kit = [("var", FUENTES / "Inter-Variable.ttf")]
        win = [("st", WINF / {"Bold": "segoeuib.ttf", "Heavy": "seguibl.ttf", "Semibold": "seguisb.ttf"}.get(weight, "segoeui.ttf")),
               ("st", WINF / "arial.ttf")]
    elif fam == "ny":
        mac = [("mac_ny", MAC / "NewYorkItalic.ttf")]
        kit = [("var", FUENTES / "PlayfairDisplay-Italic-Variable.ttf"), ("st", FUENTES / "InstrumentSerif-Italic.ttf")]
        win = [("st", WINF / ("georgiaz.ttf" if weight in ("Bold", "Heavy") else "georgiai.ttf"))]
    else:
        mac = [("mac_mono", MAC / "SFNSMono.ttf")]
        kit = [("var", FUENTES / "JetBrainsMono-Variable.ttf")]
        win = [("st", WINF / "consola.ttf")]
    return (kit + win) if libres else (mac + kit + win)


def font(fam, weight, size):
    """font('sf'|'ny'|'mono', 'Regular'|'Medium'|'Semibold'|'Bold', tamaño) con la cascada de arriba."""
    k = (fam, weight, size)
    if k in _fc:
        return _fc[k]
    f = None
    for tipo, p in _candidatas(fam, weight):
        if not p.exists():
            continue
        try:
            f = ImageFont.truetype(str(p), size)
            if tipo == "mac_sf":
                f.set_variation_by_axes([100, min(96, max(17, size)), 400, WGT_SF[weight]])
            elif tipo == "mac_ny":
                f.set_variation_by_axes([min(256, size), WGT_SF[weight], 0])
            elif tipo == "var":
                vals = []
                for ax in f.get_variation_axes():
                    nm = ax.get("name", b"")
                    nm = (nm.decode("latin-1") if isinstance(nm, bytes) else str(nm)).lower()
                    if "weight" in nm or nm == "wght":
                        vals.append(clamp(WGT[weight], ax["minimum"], ax["maximum"]))
                    elif "optical" in nm or nm == "opsz":
                        vals.append(clamp(size, ax["minimum"], ax["maximum"]))
                    else:
                        vals.append(ax["default"])
                f.set_variation_by_axes(vals)
            break
        except Exception:
            f = None
    if f is None:
        f = ImageFont.load_default(size=size)
    _fc[k] = f
    return f


def fuentes_usadas():
    out = {}
    for fam in ("sf", "ny", "mono"):
        p = next((str(p) for _, p in _candidatas(fam, "Bold") if p.exists()), "PIL por defecto")
        out[fam] = Path(p).name
    return out


# ══════════════════════════════════════════ texto (sprites) + registro para la QA ══════════════════════════════════════
_tc: dict = {}
REG: list | None = None          # cuando no es None, cada texto/elemento dibujado se anota aquí (para la QA)


def sprite(txt, fam, weight, size, color):
    """RGBA premultiplicado; devuelve (img, x_origen, y_baseline, avance, caja_tinta)."""
    k = (txt, fam, weight, size, tuple(np.round(color, 3)))
    if k in _tc:
        return _tc[k]
    f = font(fam, weight, size); asc, desc = f.getmetrics(); adv = f.getlength(txt); pad = int(size * 0.3)
    im = Image.new("L", (int(adv) + 2 * pad + int(size * .3), asc + desc + 2 * pad), 0)
    ImageDraw.Draw(im).text((pad, pad + asc), txt, font=f, fill=255, anchor="ls")
    a = np.asarray(im, np.float32) / 255
    ys, xs = np.where(a > 0.1)
    ink = (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1) if len(xs) else (pad, pad, pad, pad)
    if len(_tc) > 6000:
        _tc.clear()
    _tc[k] = (np.dstack([a[..., None] * color[None, None, :], a]), pad, pad + asc, adv, ink)
    return _tc[k]


def blit(fr, rgba, x, y, op=1.0): ae.over(fr, rgba, x, y, op)


def registrar(rol, box, **kw):
    if REG is not None:
        REG.append(dict(rol=rol, box=tuple(float(v) for v in box), **kw))


_sh: dict = {}


def soft_shadow(rgba):
    k = id(rgba)
    if k not in _sh:
        a = cv2.GaussianBlur(rgba[..., 3], (0, 0), 7); _sh[k] = np.dstack([np.zeros(a.shape + (3,), np.float32), a])
        if len(_sh) > 3000: _sh.clear()
    return _sh[k]


def text_at(fr, txt, fam, weight, size, color, cx, base, op=1.0, dy=0.0, shadow=0.0, rol="ui"):
    rgba, ox, oy, adv, ink = sprite(txt, fam, weight, size, color)
    x = cx - adv / 2 - ox; y = base - oy + dy
    if shadow > 0: blit(fr, soft_shadow(rgba), x, y + 4, shadow * op)
    blit(fr, rgba, x, y, op)
    if op > 0.25 and fr.shape[0] == H and fr.shape[1] == W:
        registrar(rol, (x + ink[0], y + ink[1], x + ink[2], y + ink[3]), cx=cx, txt=txt)
    return adv


def text_left(fr, txt, fam, weight, size, color, x0, base, op=1.0, dy=0.0):
    f = font(fam, weight, size); return text_at(fr, txt, fam, weight, size, color, x0 + f.getlength(txt) / 2, base, op, dy)


def fit(txt, fam, weight, size, maxw, minimo=40):
    while size > minimo and font(fam, weight, size).getlength(txt) > maxw: size -= 4
    return size


def ink_desc(txt, fam, weight, size):
    """px de tinta por debajo de la línea base (descendentes de g, j, p, q, y, coma)."""
    _, ox, oy, adv, ink = sprite(txt, fam, weight, size, WHITE)
    return max(0, ink[3] - oy)


APP = 4 / FPS                        # cada palabra entra en 4 cuadros y sube 20–26 px


def wanim(t, ts, dist=20):
    u = eo(ramp(t, ts - 1 / FPS, ts - 1 / FPS + APP)); return u, (1 - u) * dist


def fade_out(t, tout): return 1 - (eo(ramp(t, tout, tout + 3 / FPS)) if tout else 0)


def line_words(fr, words, t, fam, weight, size, color, cx, base, shadow=0.0, tout=None, rol="contexto"):
    """palabra por palabra, cada una en su tiempo, en su lugar definitivo (línea centrada sobre el texto completo)."""
    if not words: return
    f = font(fam, weight, size); sp = f.getlength(" ")
    full = sum(f.getlength(w) for w, _ in words) + sp * (len(words) - 1); x = cx - full / 2
    for w, ts in words:
        u, dy = wanim(t, ts); op = u * fade_out(t, tout); adv = f.getlength(w)
        if op > 0: text_at(fr, w, fam, weight, size, color, x + adv / 2, base, op, dy, shadow, rol=rol)
        x += adv + sp
    if REG is not None and any(t >= ts for _, ts in words) and fade_out(t, tout) > 0.25:
        registrar(rol + "_linea", (cx - full / 2, base - size * 0.75, cx + full / 2, base), cx=cx)


def big_word(fr, w, ts, t, fam, weight, size, color, cx, base, shadow=0.0, tout=None):
    u, dy = wanim(t, ts, 26); op = u * fade_out(t, tout)
    # la subida de entrada nunca saca la tinta de la zona segura de abajo
    dy = min(dy, max(0.0, G["ink_max"] + 3 - (base + ink_desc(w, fam, weight, size))))
    if op > 0: text_at(fr, w, fam, weight, size, color, cx, base, op, dy, shadow, rol="clave")


def wrap(txt, f, maxw):
    out = []
    for par in str(txt).split("\n"):
        cur = ""
        for w in par.split():
            tst = (cur + " " + w).strip()
            if f.getlength(tst) <= maxw: cur = tst
            else:
                if cur: out.append(cur)
                cur = w
        out.append(cur)
    return [l for l in out if l is not None]


# ══════════════════════════════════════════ formas ══════════════════════════════════════════
_rm: dict = {}


def rmask(w, h, r):
    k = (int(w), int(h), int(r))
    if k not in _rm:
        _rm[k] = ae.rrect_mask(k[0], k[1], max(1, min(k[2], k[0] // 2, k[1] // 2)), 0.6)
        if len(_rm) > 2000: _rm.clear()
    return _rm[k]


def rrect(fr, x0, y0, x1, y1, r, color, op=1.0, border=None):
    w, h = int(round(x1 - x0)), int(round(y1 - y0))
    if w < 2 or h < 2: return
    m = rmask(w, h, min(r, w // 2, h // 2)); blit(fr, np.dstack([m[..., None] * color[None, None, :], m]), x0, y0, op)
    if border is not None and w > 6 and h > 6:
        inner = np.zeros_like(m); inner[2:-2, 2:-2] = rmask(w - 4, h - 4, max(1, min(r, w // 2, h // 2) - 2))
        mm = np.clip(m - inner, 0, 1); blit(fr, np.dstack([mm[..., None] * border[None, None, :], mm]), x0, y0, op)


_shc: dict = {}


def shadow_rect(fr, x0, y0, x1, y1, r, op, strength=0.18, blur=30, dy=22):
    k = (int(x1 - x0), int(y1 - y0), int(r), blur)
    if k[0] < 2 or k[1] < 2: return
    if k not in _shc:
        w, h = k[0], k[1]; pad = blur * 3
        m = np.zeros((h + 2 * pad, w + 2 * pad), np.float32); m[pad:pad + h, pad:pad + w] = rmask(w, h, r)
        m = cv2.GaussianBlur(m, (0, 0), blur); _shc[k] = (np.dstack([m[..., None] * c(25, 40, 110)[None, None, :], m]), pad)
        if len(_shc) > 500: _shc.clear()
    rgba, pad = _shc[k]; blit(fr, rgba, x0 - pad, y0 - pad + dy, strength * op)


def check_mark(fr, cx, cy, r, col, op, u=1.0):
    """palomita que se dibuja (u 0→1)."""
    if op <= 0 or u <= 0: return
    m = np.zeros((int(r * 2.4), int(r * 2.4)), np.float32); o = r * 1.2
    p = [(o - r * .45, o + r * .02), (o - r * .1, o + r * .38), (o + r * .5, o - r * .35)]
    L1 = math.dist(p[0], p[1]); L2 = math.dist(p[1], p[2]); d = u * (L1 + L2)
    th = max(3, int(r * .2))
    q = lambda a, b, k: (int((a[0] + (b[0] - a[0]) * k) * 4), int((a[1] + (b[1] - a[1]) * k) * 4))
    cv2.line(m, q(p[0], p[0], 0), q(p[0], p[1], min(1, d / L1)), 1.0, th, cv2.LINE_AA, 2)
    if d > L1: cv2.line(m, q(p[1], p[1], 0), q(p[1], p[2], (d - L1) / L2), 1.0, th, cv2.LINE_AA, 2)
    blit(fr, np.dstack([m[..., None] * col[None, None, :], m]), cx - o, cy - o, op)


def disc(fr, cx, cy, r, col, op=1.0):
    if r < 1: return
    d = int(r * 2 + 4); m = np.zeros((d, d), np.float32)
    cv2.circle(m, (int(d / 2 * 4), int(d / 2 * 4)), int(r * 4), 1.0, -1, cv2.LINE_AA, 2)
    blit(fr, np.dstack([m[..., None] * col[None, None, :], m]), cx - d / 2, cy - d / 2, op)


def ring(fr, cx, cy, r, th, col, op=1.0):
    if r < 1 or op <= 0.002: return
    d = int(2 * r + 2 * th + 6); m = np.zeros((d, d), np.float32)
    cv2.circle(m, (int(d / 2 * 4), int(d / 2 * 4)), int(r * 4), 1.0, max(1, int(th)), cv2.LINE_AA, 2)
    blit(fr, np.dstack([m[..., None] * col[None, None, :], m]), cx - d / 2, cy - d / 2, op)


def img_card(img, w, h, r):
    """imagen → capa RGBA premultiplicada con esquinas redondeadas."""
    w, h = max(2, int(w)), max(2, int(h))
    im = cv2.resize(cover(img, w, h), (w, h), interpolation=cv2.INTER_AREA); m = rmask(w, h, r)
    return np.dstack([im * m[..., None], m])


def cover(img, w, h):
    """recorta la imagen al aspecto w:h (centrado) para que llene sin deformarse."""
    ih, iw = img.shape[:2]; ar, iar = w / h, iw / ih
    if abs(ar - iar) < 1e-3: return img
    if iar > ar:
        nw = int(ih * ar); x0 = (iw - nw) // 2; return img[:, x0:x0 + nw]
    nh = int(iw / ar); y0 = (ih - nh) // 2; return img[y0:y0 + nh]


def put_layer(fr, rgba, cx, cy, scale=1.0, rot=0.0, op=1.0, shadow=0.28, sh_dy=26):
    """capa centrada en (cx, cy) con escala/giro y sombra suave azulada."""
    if op <= 0.002: return
    h, w = rgba.shape[:2]
    if abs(scale - 1) > 1e-3 or abs(rot) > 0.05:
        nw, nh = int(w * scale * 1.2 + 8), int(h * scale * 1.2 + 8)
        M = cv2.getRotationMatrix2D((w / 2, h / 2), rot, scale); M[0, 2] += nw / 2 - w / 2; M[1, 2] += nh / 2 - h / 2
        rgba = cv2.warpAffine(rgba, M, (nw, nh), flags=cv2.INTER_LINEAR)
    h, w = rgba.shape[:2]; x, y = cx - w / 2, cy - h / 2
    if shadow > 0:
        pad = 60; a = cv2.GaussianBlur(np.pad(rgba[..., 3], pad), (0, 0), 24)
        sh = np.dstack([a[..., None] * c(20, 30, 70)[None, None, :], a]); blit(fr, sh, x - pad, y - pad + sh_dy * scale, shadow * op)
    blit(fr, rgba, x, y, op)


def float_card(fr, img, cx, cy, w, h, op=1.0, rot=0.0, shadow=0.25, r=34, scale=1.0):
    """video o imagen flotante: esquinas redondeadas + sombra azulada (p030/p031)."""
    if op <= 0.002: return
    w2, h2 = max(2, int(w * scale)), max(2, int(h * scale))
    im = cv2.resize(cover(img, w2, h2), (w2, h2), interpolation=cv2.INTER_AREA)
    m = rmask(w2, h2, int(r * scale)); pad = 90
    canvas = np.zeros((h2 + 2 * pad, w2 + 2 * pad, 4), np.float32)
    canvas[pad:pad + h2, pad:pad + w2, :3] = im * m[..., None]; canvas[pad:pad + h2, pad:pad + w2, 3] = m
    if rot:
        M = cv2.getRotationMatrix2D((canvas.shape[1] / 2, canvas.shape[0] / 2), rot, 1.0)
        canvas = cv2.warpAffine(canvas, M, (canvas.shape[1], canvas.shape[0]), flags=cv2.INTER_LINEAR)
    sa = cv2.GaussianBlur(canvas[..., 3], (0, 0), 26)
    sh = np.dstack([np.zeros(sa.shape + (3,), np.float32) + c(20, 30, 70), sa]); sh[..., :3] *= sa[..., None]
    x = cx - canvas.shape[1] / 2; y = cy - canvas.shape[0] / 2
    blit(fr, sh, x, y + 26 * scale, shadow * op)
    blit(fr, canvas, x, y, op)
    registrar("grafico", (cx - w2 / 2, cy - h2 / 2, cx + w2 / 2, cy + h2 / 2))


def glass_card(fr, x, y, w, h, r=44, op=1.0, **kw):
    registrar("grafico", (x, y, x + w, y + h))
    return ae.glass_card(fr, x, y, w, h, r, op, **kw)


def card_block(fr, x0, y0, x1, y1, r, op, color=WHITE, sombra=0.20):
    """tarjeta blanca con sombra azulada (la base de casi todos los gráficos)."""
    shadow_rect(fr, x0, y0, x1, y1, r, op, sombra)
    rrect(fr, x0, y0, x1, y1, r, color, op)
    registrar("grafico", (x0, y0, x1, y1))


# ══════════════════════════════════════════ fondos (a 1/4 de resolución, con dither) ══════════════════════════════
def blob(cx, cy, r): d = np.sqrt((_xx - cx / 4) ** 2 + (_yy - cy / 4) ** 2) / (r / 4); return np.exp(-d * d)
def up(small): return cv2.resize(small, (W, H), interpolation=cv2.INTER_CUBIC) + DITHER


def bg_light(t, seed=0):
    if VERTICAL:
        k = math.sin(t * 0.9 + seed) * 60
        a = 0.55 * blob(1150 + k, 1650, 760) + 0.45 * blob(-120, 1900 - k, 640) + 0.35 * blob(1100, -80 + k, 520)
    else:
        k = math.sin(t * 0.9 + seed) * 70
        a = 0.55 * blob(1800 + k, 1000, 760) + 0.45 * blob(-150, 1150 - k, 640) + 0.30 * blob(1700, -120 + k, 560)
    base = np.ones((H // 4, W // 4, 3), np.float32) * c(248, 249, 253)
    a = np.clip(a, 0, 0.85)[..., None]
    return up(base * (1 - a) + c(150, 175, 255) * a)


def bg_blue(t, seed=0):
    if VERTICAL:
        k = math.sin(t * 0.8 + seed) * 50; g = (_yy / (H / 4))[..., None]
        a1 = (0.45 * blob(80 + k, 120, 700))[..., None]; a2 = (0.55 * blob(540, 2150 - k, 820))[..., None]
    else:
        k = math.sin(t * 0.8 + seed) * 60; g = (_xx / (W / 4) * 0.5 + _yy / (H / 4) * 0.5)[..., None]
        a1 = (0.45 * blob(120 + k, 80, 760))[..., None]; a2 = (0.55 * blob(960, 1350 - k, 900))[..., None]
    base = c(24, 74, 240) * (1 - g) + c(40, 100, 255) * g
    out = base * (1 - a1) + c(90, 140, 255) * a1
    return up(out * (1 - a2) + c(205, 220, 255) * a2)


def bg_dark(t, seed=0):
    base = np.ones((H // 4, W // 4, 3), np.float32) * c(5, 7, 13)
    if VERTICAL:
        k = math.sin(t * 0.7 + seed) * 40
        a = (0.35 * blob(540, 1250 + k, 700))[..., None]; b = (0.30 * blob(900 - k, 300, 520))[..., None]
    else:
        k = math.sin(t * 0.7 + seed) * 50
        a = (0.35 * blob(960 + k, 640, 820))[..., None]; b = (0.25 * blob(1500 - k, 200, 520))[..., None]
    out = base * (1 - a) + c(30, 60, 150) * a
    return up(out * (1 - b) + c(25, 50, 130) * b)


def fondo(nombre, t, seed=0):
    """fondo por nombre con su detalle vivo: clara (bruma azul), azul (degradado), oscura (+ rejilla y partículas)."""
    if nombre in ("azul", "blue"): return bg_blue(t, seed)
    if nombre in ("oscura", "oscuro", "dark"):
        fr = bg_dark(t, seed)
        ae.grid_floor(fr, t, horizonte=0.74 if VERTICAL else 0.70, op=0.16, vel=0.3)
        ae.particles(fr, t, n=55 if VERTICAL else 70, seed=3 + seed, op=0.40, vel=18)
        return fr
    fr = bg_light(t, seed)
    return fr


def colores(nombre):
    """(color del contexto, color de la clave) según el fondo."""
    if nombre in ("azul", "blue"): return WHITE, WHITE
    if nombre in ("oscura", "oscuro", "dark", "stock"): return WHITE, BLUE_D
    return BLACK, BLUE


def tech_grid(t, t0):
    """rejilla técnica en perspectiva (piso y techo que avanzan) — p030/p031."""
    fr = bg_dark(t, 3) * 0.7
    g = np.zeros((H, W), np.float32)
    hz, f, camy, sep, xs = (1000, 700.0, 330.0, 380, 2400) if VERTICAL else (560, 700.0, 230.0, 300, 4800)
    cxm = W / 2
    zoff = ((t - t0) * 260) % 120
    for i in range(1, 46):
        z = i * 120 - zoff
        if z < 40: continue
        y = hz + f * camy / z
        if y < H: cv2.line(g, (0, int(y)), (W, int(y)), 1.0 * min(1, 900 / z), 2, cv2.LINE_AA)
        y2 = hz - sep - f * camy / z
        if y2 > 0: cv2.line(g, (0, int(y2)), (W, int(y2)), 0.6 * min(1, 900 / z), 2, cv2.LINE_AA)
    for xw in range(-xs, xs + 1, 160 if VERTICAL else 200):
        x_far = cxm + f * xw / 9000; x_near = cxm + f * xw / 60
        cv2.line(g, (int(x_far), hz), (int(x_near), int(hz + f * camy / 60)), 0.55, 2, cv2.LINE_AA)
        cv2.line(g, (int(x_far), hz - sep), (int(x_near), int(hz - sep - f * camy / 60)), 0.35, 2, cv2.LINE_AA)
    yy = np.arange(H, dtype=np.float32)[:, None]
    g *= np.clip(np.abs(yy - (hz - sep / 2)) / (650 if VERTICAL else 420), 0, 1) ** 1.3
    glow = cv2.GaussianBlur(g, (0, 0), 6)
    fr += (g * 0.35 + glow * 0.9)[..., None] * BLUE_D[None, None, :] * 0.55
    return np.clip(fr, 0, 1)


GLYPHS = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789#%&<>/"


def decode_text(fr, txt, t, t0, dur, size, cx, base, col):
    """texto que se «descifra» letra por letra, con brillo — p030/p031."""
    f = font("sf", "Bold", size); full = f.getlength(txt); x = cx - full / 2
    layer = np.zeros((H, W, 4), np.float32)
    n = len(txt); rng = np.random.default_rng(int(t * FPS))
    for i, ch in enumerate(txt):
        adv = f.getlength(ch)
        if ch != " " and t >= t0 + 0.04 * i - 0.1:
            ti = t0 + dur * i / max(1, n - 1) * 0.85
            if t >= ti + 0.08:
                rgba, ox, oy, _, _ = sprite(ch, "sf", "Bold", size, col); op = 1; xx = int(round(x - ox))
            else:
                g = GLYPHS[rng.integers(len(GLYPHS))]
                rgba, ox, oy, _, _ = sprite(g, "mono", "Regular", int(size * .8), col * 0.75); op = 0.85
                xx = int(round(x + adv / 2 - rgba.shape[1] / 2))
            yy = int(round(base - oy)); h_, w_ = rgba.shape[:2]
            x0, y0 = max(0, xx), max(0, yy); x1, y1 = min(W, xx + w_), min(H, yy + h_)
            if x1 > x0 and y1 > y0:
                s = rgba[y0 - yy:y1 - yy, x0 - xx:x1 - xx]
                layer[y0:y1, x0:x1] = layer[y0:y1, x0:x1] * (1 - s[..., 3:4] * op) + s * op
        x += adv
    glow = cv2.GaussianBlur(layer[..., 3], (0, 0), 18)
    fr += glow[..., None] * col[None, None, :] * 0.55
    a = layer[..., 3:4]
    fr[:] = fr * (1 - a) + layer[..., :3]
    np.clip(fr, 0, 1, out=fr)
    if t >= t0: registrar("titulo", (cx - full / 2, base - size * 0.74, cx + full / 2, base), cx=cx)


def cine(im):
    """B-roll cinematográfico (γ 1.25 × 0.72) + franja baja oscurecida para el texto."""
    yy = np.linspace(0, 1, H, dtype=np.float32)[:, None, None]
    im = np.clip(im, 0, 1) ** 1.25 * 0.72
    lo = 0.62 if VERTICAL else 0.55
    im = im * (1 - 0.55 * np.clip((yy - lo) / 0.16, 0, 1))
    return np.ascontiguousarray(im, dtype=np.float32)


# ══════════════════════════════════════════ plan, material y tiempos de palabra ══════════════════════════════════════
P: dict = {}            # plan cargado (global en cada proceso)
PAL: list = []          # palabras.json
NF = 0


def norm(t):
    t = unicodedata.normalize("NFD", str(t).lower())
    t = "".join(ch for ch in t if unicodedata.category(ch) != "Mn")
    return re.sub(r"[^a-z0-9ñ]+", "", t)


def _ruta(base: Path, p):
    if not p: return None
    q = Path(p)
    return q if q.is_absolute() else (base / q)


def _sim(a, b):
    a, b = norm(a), norm(b)
    if not a or not b: return 0.0
    return 1.0 if a == b else SequenceMatcher(None, a, b).ratio()


def tiempos(texto, t0, t1, holgura=0.25):
    """'si lo quieres ver' → [('si', 27.50), …] buscando cada palabra en palabras.json dentro del plano.
    Si una palabra no aparece igual (p. ej. Whisper escribió «Cloud» y tú «Claude») se usa la que va en su posición."""
    if texto is None: return []
    if isinstance(texto, list):
        if texto and isinstance(texto[0], (list, tuple)):
            return [(str(w), max(float(ts), t0)) for w, ts in texto]
        texto = " ".join(map(str, texto))
    toks = str(texto).split()
    win = [w for w in PAL if t0 - holgura <= w["s"] < t1 - 0.02]
    if not win:
        return [(tok, t0 + 0.12 * k) for k, tok in enumerate(toks)]
    # 1) dónde empieza la frase dentro del plano: la posición que más se parece (tolera «Cloud» por «Claude»)
    def puntaje(j):
        return sum(_sim(tok, win[j + k]["w"]) for k, tok in enumerate(toks) if j + k < len(win))
    p = max(range(len(win)), key=lambda j: (round(puntaje(j), 3), -j))
    # 2) cada palabra: la más parecida entre las 3 siguientes; si ninguna se parece, la que va en su posición
    out = []
    for tok in toks:
        cand = [(q, _sim(tok, win[q]["w"])) for q in range(p, min(len(win), p + 3))]
        q, sc = max(cand, key=lambda x: (x[1], -x[0])) if cand else (None, 0)
        if q is not None and sc >= 0.75:
            ts = win[q]["s"]; p = q + 1
        elif p < len(win):
            ts = win[p]["s"]; p += 1
        else:
            ts = (out[-1][1] + 0.12) if out else t0
        out.append((tok, max(ts, t0)))
    for k in range(1, len(out)):                    # nunca antes que la anterior
        if out[k][1] < out[k - 1][1]: out[k] = (out[k][0], out[k - 1][1])
    return out


def clave_t(clave, t0, t1, despues=None):
    """('completo', 28.06): la clave entra con su primera palabra."""
    if clave is None: return None
    if isinstance(clave, (list, tuple)) and len(clave) == 2 and isinstance(clave[1], (int, float)):
        return (str(clave[0]), max(float(clave[1]), t0))
    txt = str(clave)
    a = t0 if despues is None else despues
    ts = tiempos(txt, a, t1, 0.25 if despues is None else 0.0)
    return (txt, ts[0][1] if ts else t0)


def t_de(valor, t0, t1, defecto):
    """tiempo de un evento: número (segundos) o palabra («despedir») → su inicio dentro del plano."""
    if valor is None: return t0 + defecto
    if isinstance(valor, (int, float)): return float(valor)
    ts = tiempos(str(valor).split()[0], t0, t1)
    win = [w for w in PAL if t0 - 0.25 <= w["s"] < t1 and norm(w["w"]) == norm(str(valor).split()[0])]
    return win[0]["s"] if win else (t0 + defecto)


def textos(sh):
    """beats del plano: [(contexto[(w,t)], clave(w,t), serif, tout)]."""
    t0, t1 = sh["t0"], sh["t1"]
    beats = sh.get("beats") or ([{"contexto": sh.get("contexto"), "clave": sh.get("clave"), "serif": sh.get("serif")}]
                                if (sh.get("contexto") or sh.get("clave")) else [])
    out = []
    cur = t0
    for k, b in enumerate(beats):
        hol = 0.25 if k == 0 else 0.0              # el beat siguiente se busca DESPUÉS del anterior
        sm = tiempos(b.get("contexto"), cur, t1, hol)
        bg = clave_t(b.get("clave"), t0, t1, (sm[-1][1] + 0.01) if sm else cur)
        out.append([sm, bg, bool(b.get("serif")), None])
        firsts = [x[1] for x in sm] + ([bg[1]] if bg else [])
        cur = (max(firsts) + 0.01) if firsts else cur
    for k in range(len(out) - 1):                  # el beat k se va 3 cuadros antes de que entre el siguiente
        nxt = out[k + 1]
        start = min([x[1] for x in nxt[0]] + ([nxt[1][1]] if nxt[1] else []))
        out[k][3] = start - 3 / FPS
    return out


# ══════════════════════════════════════════ su cara y la barbilla ══════════════════════════════════════════
CH = FX0 = FX1 = FY0 = None


def cargar_caras(path):
    """caras.json → por cuadro: barbilla (px, + margen), x izq/der y arriba de la cara (px)."""
    global CH, FX0, FX1, FY0
    cj = json.loads(Path(path).read_text(encoding="utf-8"))
    rows = cj["caras"]
    n = max(NF + 2, len(rows))
    ch = np.full(n, np.nan, np.float32); x0 = ch.copy(); x1 = ch.copy(); y0 = ch.copy()
    for r in rows:
        i = int(round(r[0] * FPS))
        if 0 <= i < n and r[1] >= 0:
            ch[i] = (r[2] + r[4]) * H + G["chin_margin"]; x0[i] = r[1] * W; x1[i] = (r[1] + r[3]) * W; y0[i] = r[2] * H
    for arr in (ch, x0, x1, y0):                    # cuadros sin cara: se copia la más cercana
        ok = np.where(~np.isnan(arr))[0]
        if len(ok) == 0:
            arr[:] = {id(ch): H * 0.62, id(x0): W * 0.3, id(x1): W * 0.7, id(y0): H * 0.3}[id(arr)]
        else:
            idx = np.interp(np.arange(n), ok, ok).round().astype(int); arr[:] = arr[idx]
    CH, FX0, FX1, FY0 = ch, x0, x1, y0


def chin(i):
    i = int(min(len(CH) - 1, max(0, i))); return float(np.max(CH[max(0, i - 3):i + 4]))


def xf(v, s, a): return a + (v - a) * s          # coordenada tras el punch-in anclado en a


def toma_xf(img, s, anchor=None):
    """punch-in anclado abajo (la barbilla SUBE y deja pecho libre), Lanczos, sin ningún filtro."""
    if abs(s - 1) < 1e-4: return img
    ax, ay = anchor or G["anchor"]
    M = np.float32([[s, 0, ax * (1 - s)], [0, s, ay * (1 - s)]])
    return cv2.warpAffine(img, M, (W, H), flags=cv2.INTER_LANCZOS4, borderMode=cv2.BORDER_REFLECT)


SCALES = [1.00, 1.03, 1.05, 1.08, 1.10]
KEY_MIN = 112


def key_geom(bw, serif, bsize, base=None):
    """(familia, peso, tamaño ajustado, base de la clave) sin pasar de la zona segura de abajo."""
    fam, wt = ("ny", "Semibold") if serif else ("sf", "Bold")
    size = fit(bw, fam, wt, bsize + (8 if serif else 0), G["maxw"], 56)
    kb = G["key_base"] if base is None else base
    kb = min(kb, G["ink_max"] - ink_desc(bw, fam, wt, size))
    return fam, wt, size, kb


def small_size(words):
    txt = " ".join(w for w, _ in words)
    return fit(txt, "sf", "Semibold", G["small"], G["maxw"], 34) if txt else G["small"]


def ajustar_cara(sh):
    """elige el punch-in más chico que deja el texto ≥ 40 px bajo la barbilla más baja del plano (regla dura)."""
    beats = sh["_beats"]; t0, t1 = sh["t0"], sh["t1"]
    i0, i1 = int(round(t0 * FPS)), max(int(round(t0 * FPS)) + 1, min(int(round(t1 * FPS)), NF))
    ax, ay = G["anchor"]
    smin = float(sh.get("s", 1.0))
    tries = [x for x in SCALES if x >= smin - 1e-6] or [1.10]
    best = None
    # ventana de cada beat: desde que entra (o el inicio del plano) hasta que se va (o el final del plano)
    vent = []
    for k, (sm, bg, serif, tout) in enumerate(beats):
        a = i0 if k == 0 else int((beats[k - 1][3] + 3 / FPS) * FPS)
        b = i1 if tout is None else min(i1, int(math.ceil((tout + 4 / FPS) * FPS)))
        vent.append((max(i0, a), max(max(i0, a) + 1, b)))
    for s in tries:
        ch_plano = max(xf(chin(i), s, ay) for i in range(i0, i1))
        lay = []
        okall = True
        for (sm, bg, serif, tout), (va, vb) in zip(beats, vent):
            ch = max(xf(chin(i), s, ay) for i in range(va, vb))
            cxs = [xf((FX0[i] + FX1[i]) / 2, s, ax) for i in range(va, vb)]
            ss = small_size(sm)
            if not bg:
                lay.append(dict(ss=ss, bsize=0)); continue
            fam, wt, size, kb = key_geom(bg[0], serif, G["big"])
            if VERTICAL:   # franja baja (p032): la clave se achica para que el contexto quede ≥ 40 px bajo la barbilla
                top = ch + 40
                room = kb - 24 - int(ss * 0.74) - top
                size = min(size, int(room / 0.74)) if sm else min(size, int((kb - top) / 0.74))
                fam, wt, size, kb = key_geom(bg[0], serif, max(40, size - (8 if serif else 0)))
                okb = size >= KEY_MIN or s >= tries[-1]
                lay.append(dict(ss=ss, bsize=size, kb=kb, cx=G["cx"]))
            else:          # horizontal (p031): contexto 40 px bajo la barbilla, clave debajo, centrado en su cara
                base_small = ch + 40 + int(ss * 0.74)
                kb = base_small + 26 + int(size * 0.74) if sm else ch + 40 + int(size * 0.74)
                while kb + ink_desc(bg[0], fam, wt, size) > G["ink_max"] and size > 64:
                    size -= 4
                    kb = base_small + 26 + int(size * 0.74) if sm else ch + 40 + int(size * 0.74)
                cx = float(np.median(cxs))
                half = max(font(fam, wt, size).getlength(bg[0]), font("sf", "Semibold", ss).getlength(
                    " ".join(w for w, _ in sm))) / 2 + 10
                cx = clamp(cx, G["safe"]["left"] + half, G["safe"]["right"] - half)
                okb = (size >= 96 and kb + ink_desc(bg[0], fam, wt, size) <= G["ink_max"]) or s >= tries[-1]
                lay.append(dict(ss=ss, bsize=size, kb=kb, base_small=base_small, cx=cx))
            okall &= okb
        best = dict(s=s, chin=ch_plano, lay=lay)
        if okall: break
    sh["_s"] = best["s"]; sh["_chin"] = best["chin"]; sh["_lay"] = best["lay"]


def face_text(fr, t, sh, op_extra=1.0):
    """dibuja los beats de un plano de cara con la geometría ya resuelta."""
    for (sm, bg, serif, tout), L in zip(sh["_beats"], sh["_lay"]):
        prev_out = None
        k = sh["_beats"].index([sm, bg, serif, tout])
        if k > 0: prev_out = sh["_beats"][k - 1][3]
        if prev_out is not None and t < prev_out + 3 / FPS: continue
        if tout is not None and t >= tout + 4 / FPS: continue
        cx = L.get("cx", G["cx"])
        if not bg:
            line_words(fr, sm, t, "sf", "Semibold", L["ss"], WHITE, cx, G["key_base"], 0.45, tout); continue
        fam, wt = ("ny", "Semibold") if serif else ("sf", "Bold")
        size, kb = L["bsize"], L["kb"]
        sb = L.get("base_small") or (kb - int(size * 0.74) - 24)
        if sm: line_words(fr, sm, t, "sf", "Semibold", L["ss"], WHITE, cx, sb, shadow=0.45, tout=tout)
        big_word(fr, bg[0], bg[1], t, fam, wt, size, BLUE_D, cx, kb, shadow=0.45, tout=tout)


def band(fr, t, sh, col_s, col_b, bsize=None, beats=None):
    """franja baja de tarjetas/stock: la MISMA altura que en su cara (clave en key_base), contexto encima."""
    for k, (sm, bg, serif, tout) in enumerate(beats if beats is not None else sh["_beats"]):
        allb = beats if beats is not None else sh["_beats"]
        if k > 0 and t < allb[k - 1][3] + 3 / FPS: continue
        if tout is not None and t >= tout + 4 / FPS: continue
        ss = small_size(sm)
        if not bg:
            line_words(fr, sm, t, "sf", "Semibold", ss, col_s, G["cx"], G["key_base"], tout=tout); continue
        fam, wt, size, kb = key_geom(bg[0], serif, bsize or sh.get("tam_clave", G["big"]))
        sb = kb - int(size * 0.74) - 30
        if sm: line_words(fr, sm, t, "sf", "Semibold", ss, col_s, G["cx"], sb, tout=tout)
        big_word(fr, bg[0], bg[1], t, fam, wt, size, col_b, G["cx"], kb, tout=tout)


# ══════════════════════════════════════════ marca del alumno: avatar y logos ══════════════════════════════════════════
_avatar = {}


def avatar(fr, cx, cy, r, op=1.0):
    """avatar circular desde el PNG del alumno (marca.avatar). NUNCA un cuadro del video. Sin PNG: iniciales."""
    if op <= 0.002: return
    path = P.get("_avatar")
    if path and path.exists():
        if "img" not in _avatar:
            im = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
            if im is not None and im.ndim == 2: im = cv2.cvtColor(im, cv2.COLOR_GRAY2BGR)
            _avatar["img"] = im
        src = _avatar["img"]
    else:
        src = None
    d = int(2 * r)
    m = np.zeros((d * 4, d * 4), np.uint8); cv2.circle(m, (2 * d, 2 * d), 2 * d - 2, 255, -1, cv2.LINE_AA)
    m = cv2.resize(m, (d, d), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
    if src is None:
        disc(fr, cx, cy, r, BLUE, op)
        ini = "".join(p[0] for p in str(P.get("_nombre", "Tú")).split()[:2]).upper() or "TÚ"
        text_at(fr, ini, "sf", "Bold", int(r * 0.8), WHITE, cx, cy + r * 0.28, op)
        return
    s0 = min(src.shape[:2]); y0 = (src.shape[0] - s0) // 2; x0 = (src.shape[1] - s0) // 2
    sq = src[y0:y0 + s0, x0:x0 + s0]
    im = cv2.resize(sq, (d, d), interpolation=cv2.INTER_AREA if d < s0 else cv2.INTER_LANCZOS4).astype(np.float32) / 255
    rgb = im[..., 2::-1] if im.shape[2] >= 3 else np.repeat(im, 3, 2)
    al = im[..., 3] if im.shape[2] == 4 else np.ones((d, d), np.float32)
    m = m * al
    blit(fr, np.dstack([rgb * m[..., None], m]), cx - r, cy - r, op)


_lg = {}


def _logo_png(name):
    if name not in _lg:
        p = (P["_logos"] / f"{name}.png") if P.get("_logos") else None
        im = cv2.imread(str(p), cv2.IMREAD_UNCHANGED) if p and p.exists() else None
        if im is None:
            print(f"⚠️  falta el logo oficial marca/logos/{name}.png (pon el PNG con fondo transparente)", file=sys.stderr)
            _lg[name] = None
        else:
            if im.shape[2] == 3: im = np.dstack([im, np.full(im.shape[:2], 255, im.dtype)])
            im = im.astype(np.float32) / 255
            ys, xs = np.where(im[..., 3] > 0.02)
            _lg[name] = im[ys.min():ys.max() + 1, xs.min():xs.max() + 1] if len(xs) else im
    return _lg[name]


def logo_img(fr, name, cx, cy, h, op=1.0, ang=0.0, shadow=0.35):
    """logo OFICIAL (PNG del alumno) centrado en (cx, cy), alto h, giro y sombra suave."""
    src = _logo_png(name)
    if src is None or h < 4 or op <= 0.002: return
    sh_, sw_ = src.shape[:2]; w = h * sw_ / sh_; pad = int(h * 0.35)
    big = cv2.resize(src, (max(1, int(w)), max(1, int(h))), interpolation=cv2.INTER_AREA if h < sh_ else cv2.INTER_CUBIC)
    can = np.zeros((int(h) + 2 * pad, int(w) + 2 * pad, 4), np.float32)
    can[pad:pad + big.shape[0], pad:pad + big.shape[1]] = big
    if abs(ang) > 0.05:
        M = cv2.getRotationMatrix2D((can.shape[1] / 2, can.shape[0] / 2), ang, 1.0)
        can = cv2.warpAffine(can, M, (can.shape[1], can.shape[0]), flags=cv2.INTER_CUBIC)
    a = np.clip(can[..., 3], 0, 1); rgb = np.clip(can[..., 2::-1], 0, 1)
    if shadow > 0:
        sd = cv2.GaussianBlur(a, (0, 0), h * 0.08) * shadow
        s_ = np.zeros_like(can); s_[..., 3] = sd
        blit(fr, s_, cx - can.shape[1] / 2, cy - can.shape[0] / 2 + h * 0.08, op)
    blit(fr, np.dstack([rgb * a[..., None], a]), cx - can.shape[1] / 2, cy - can.shape[0] / 2, op)
    registrar("grafico", (cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2))


def logo_pop(fr, name, cx, cy, h, t, t_in, ang0=-14):
    """logo que entra con resorte + onda (p031)."""
    if t < t_in: return
    u = back(ramp(t, t_in, t_in + 0.42)); rr = eo(ramp(t, t_in + 0.10, t_in + 0.9))
    ring(fr, cx, cy, h * 0.62 + h * 0.62 * rr, 4, BLUE_D, (1 - rr) * 0.9)
    logo_img(fr, name, cx, cy + 40 * (1 - clamp(u)), h * max(0.05, u), clamp(ramp(t, t_in, t_in + 0.12)), ang0 * (1 - clamp(u)))


# ══════════════════════════════════════════ recursos: stock, videos y marcador ══════════════════════════════════════════
_fr_cache: dict = {}


def _clave_recurso(path, desde, dur):
    return hashlib.md5(f"{path}|{desde:.3f}|{dur:.3f}|{W}x{H}".encode()).hexdigest()[:12]


def preparar_recursos():
    """extrae a JPG (30 fps) los videos que usan los planos, una sola vez, antes de repartir el render."""
    for sh in P["planos"]:
        for f in _fuentes(sh):
            if f["video"] and not (f["dir"] / "listo").exists():
                f["dir"].mkdir(parents=True, exist_ok=True)
                vf = f"fps={FPS},scale='if(gt(a,{W}/{H}),-2,{W})':'if(gt(a,{W}/{H}),{H},-2)'"
                subprocess.run([ffmpeg(), "-v", "error", "-y", "-ss", f"{f['desde']:.3f}", "-i", str(f["path"]),
                                "-t", f"{f['dur']:.3f}", "-vf", vf, "-q:v", "3", str(f["dir"] / "%04d.jpg")], check=True)
                (f["dir"] / "listo").write_text("ok")


def _fuentes(sh):
    lst = []
    raw = sh.get("fuentes") or ([sh.get("fuente")] if "fuente" in sh else [])
    g = sh.get("grafico") or {}
    if g.get("tipo") == "celular": raw = [g.get("fuente")]
    for k, x in enumerate(raw):
        p = _ruta(P["_base"], x) if x and x != "placeholder" else None
        if p is not None and not p.exists():
            print(f"⚠️  no encuentro «{x}»: uso un marcador generado", file=sys.stderr); p = None
        video = bool(p) and p.suffix.lower() in (".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi")
        desde = float(sh.get("desde", 0)); dur = sh["t1"] - sh["t0"] + 1.0
        lst.append(dict(path=p, video=video, desde=desde, dur=dur, k=k,
                        dir=P["_trabajo"] / "recursos" / (_clave_recurso(p, desde, dur) if p else "x")))
    return lst


def placeholder(i, seed=0, w=None, h=None):
    """marcador elegante (degradado azul con luz que se mueve y un ▶) para el clip que el alumno pondrá."""
    w = w or W; h = h or H
    t = i / FPS
    yy, xx = np.mgrid[0:h // 8, 0:w // 8].astype(np.float32)
    g = (yy / max(1, h // 8))[..., None]
    base = c(14, 30, 90) * (1 - g) + c(40, 100, 255) * g
    d = np.sqrt((xx - (w / 16 + math.sin(t * 0.8 + seed) * w / 40)) ** 2 + (yy - h / 24) ** 2) / (max(w, h) / 16)
    a = np.exp(-d * d)[..., None] * 0.6
    im = cv2.resize(base * (1 - a) + c(205, 220, 255) * a, (w, h), interpolation=cv2.INTER_CUBIC)
    r = int(min(w, h) * 0.07); cx, cy = w // 2, h // 2
    m = np.zeros((h, w), np.float32)
    cv2.circle(m, (cx, cy), int(r * 1.6), 0.22, -1, cv2.LINE_AA)
    pts = np.array([[cx - r * 0.45, cy - r * 0.7], [cx - r * 0.45, cy + r * 0.7], [cx + r * 0.75, cy]], np.int32)
    cv2.fillPoly(m, [pts], 0.85, cv2.LINE_AA)
    return np.clip(im * (1 - m[..., None]) + m[..., None], 0, 1).astype(np.float32)


def recurso(sh, k, lt):
    """cuadro de la fuente k del plano en el tiempo local lt (video, foto o marcador)."""
    fs = _fuentes(sh)
    if k >= len(fs) or fs[k]["path"] is None:
        return placeholder(int(lt * FPS), seed=k + int(sh["t0"]))
    f = fs[k]
    if not f["video"]:
        key = str(f["path"])
        if key not in _fr_cache:
            im = cv2.imread(key, cv2.IMREAD_COLOR)
            _fr_cache[key] = im[..., ::-1].astype(np.float32) / 255 if im is not None else placeholder(0)
        return _fr_cache[key]
    lst = _fr_cache.setdefault(str(f["dir"]), sorted(glob.glob(str(f["dir"] / "[0-9]*.jpg"))))
    if not lst: return placeholder(int(lt * FPS), seed=k)
    im = cv2.imread(lst[min(len(lst) - 1, max(0, int(lt * FPS)))])
    return im[..., ::-1].astype(np.float32) / 255


# ══════════════════════════════════════════ píldora del gancho ══════════════════════════════════════════
def pill(fr, txt, cx, cy, op=1.0):
    """píldora blanca con texto negro (gancho), siempre bajo la barbilla."""
    size = 46; f = font("sf", "Semibold", size); adv = f.getlength(txt)
    pw, ph = int(adv + 64), 88; x0 = int(cx - pw / 2); y0 = int(cy - ph / 2)
    shadow_rect(fr, x0, y0, x0 + pw, y0 + ph, 20, op, 0.22, 18, 10)
    rrect(fr, x0, y0, x0 + pw, y0 + ph, 20, WHITE, op)
    text_at(fr, txt, "sf", "Semibold", size, BLACK, cx, y0 + ph / 2 + 16, op, rol="pildora")
    registrar("pildora", (x0, y0, x0 + pw, y0 + ph), cx=cx)


def ajustar_gancho(sh):
    """zoom inicial mínimo para que la píldora quede ≥ 40 px bajo la barbilla y dentro de la zona segura."""
    t0, t1 = sh["t0"], sh["t1"]; ax, ay = G["anchor"]
    i0, i1 = int(round(t0 * FPS)), max(int(round(t0 * FPS)) + 1, int(round(t1 * FPS)))
    for s0 in (1.00, 1.02, 1.04, 1.06):
        sfun = lambda t, s0=s0: lerp(s0, s0 + 0.04, eio((t - t0) / 2.0))
        ch = max(xf(chin(i), sfun(i / FPS), ay) for i in range(i0, i1))
        y = int(ch + 40 + 44)
        if y + 44 <= G["safe"]["bottom"] - 4: break
    cx = G["cx"] if VERTICAL else float(np.median([xf((FX0[i] + FX1[i]) / 2, s0, ax) for i in range(i0, i1)]))
    sh["_s0"], sh["_pill_y"], sh["_pill_cx"] = s0, y, cx
    sh["_chin"] = ch


# ══════════════════════════════════════════ gráficos de tarjeta ══════════════════════════════════════════
def gr_punto(fr, t, lt, sh, g):
    x0, y0, x1, y1, cx, cy = area(); u = eo(ramp(lt, 0, 0.35)); r = 14 + 4 * math.sin(lt * 9)
    y = (780 if VERTICAL else cy) - 30 * (1 - u)
    disc(fr, cx, y, r * u + 1, BLUE if sh["_fondo"] == "clara" else WHITE)


def gr_giro(fr, t, lt, sh, g):
    x0, y0, x1, y1, cx, cy = area(); u = eo(ramp(lt, 0, 0.3))
    m = np.zeros((H, W), np.uint8); y = 760 if VERTICAL else int(cy)
    cv2.ellipse(m, (int(cx), y), (46, 46), lt * 110, 0, 250, 255, 7, cv2.LINE_AA)
    a = m.astype(np.float32)[..., None] / 255 * u * 0.95
    col = WHITE if sh["_fondo"] != "clara" else BLUE
    fr[:] = fr * (1 - a) + col * a


def gr_numero(fr, t, lt, sh, g):
    x0, y0, x1, y1, cx, cy = area()
    tn = t_de(g.get("en"), sh["t0"], sh["t1"], 0.15)
    u, dy = wanim(t, tn, 30)
    col = BLUE if sh["_fondo"] == "clara" else WHITE
    val, uni = str(g.get("valor", "20")), str(g.get("unidad", ""))
    sz = 300 if VERTICAL else 260
    fb = font("sf", "Bold", sz); fu = font("sf", "Bold", int(sz * 0.32))
    tw = fb.getlength(val) + (24 + fu.getlength(uni) if uni else 0); x = cx - tw / 2
    base = (1000 if VERTICAL else cy + sz * 0.37)
    text_at(fr, val, "sf", "Bold", sz, col, x + fb.getlength(val) / 2, base, u, dy)
    if uni: text_at(fr, uni, "sf", "Bold", int(sz * 0.32), col, x + fb.getlength(val) + 24 + fu.getlength(uni) / 2, base, u, dy)


def gr_interruptor(fr, t, lt, sh, g):
    """interruptor que se enciende (✓ + onda) — p031 «posibilidad»."""
    x0, y0, x1, y1, cx, cy = area()
    cy = 760 if VERTICAL else 430
    te = t_de(g.get("en"), sh["t0"], sh["t1"], 0.6)
    u = eo(ramp(lt, 0, 0.25)); on = eio(ramp(t, te, te + 0.22))
    tw_, th_ = 300, 150; dy = 30 * (1 - u)
    oscuro = c(18, 58, 200) if sh["_fondo"] != "clara" else c(214, 224, 250)
    rrect(fr, cx - tw_ / 2, cy - th_ / 2 + dy, cx + tw_ / 2, cy + th_ / 2 + dy, 75, oscuro * (1 - on) + WHITE * on, u,
          border=WHITE if sh["_fondo"] != "clara" else BLUE)
    kx = lerp(cx - tw_ / 2 + 75, cx + tw_ / 2 - 75, on)
    disc(fr, kx, cy + dy, 58, (WHITE if sh["_fondo"] != "clara" else BLUE) * (1 - on) + BLUE * on, u)
    if on > 0.6: check_mark(fr, kx, cy + dy, 30, WHITE, ramp(on, 0.6, 1.0) * u)
    if t > te:
        rr = eo(ramp(t, te + 0.10, te + 0.65)); ring(fr, kx, cy, 60 + 90 * rr, 4, WHITE if sh["_fondo"] != "clara" else BLUE, (1 - rr) * 0.9)
    registrar("grafico", (cx - tw_ / 2, cy - th_ / 2, cx + tw_ / 2, cy + th_ / 2))


def _perfil(fr, x0, y0, op, g, u_state=0.0, nuevo=False, sweep=None):
    """tarjeta de perfil tipográfica (sin dibujos de personas): círculo con iniciales/palomita, nombre, detalle, chip."""
    x1, y1 = x0 + 780, y0 + 300
    card_block(fr, x0, y0, x1, y1, 40, op)
    cx, cy = x0 + 130, y0 + 150
    nombre = str(g.get("nombre", "Claude" if nuevo else "Editor de video"))
    detalle = str(g.get("detalle", ""))
    nsz = fit(nombre, "sf", "Semibold", 60 if nuevo else 54, 500)
    if not nuevo:
        disc(fr, cx, cy, 78, c(228, 232, 241), op)
        text_at(fr, str(g.get("iniciales", "".join(p[0] for p in nombre.split()[:2]).upper())), "sf", "Semibold", 56, BLACK, cx, cy + 20, op)
        text_left(fr, nombre, "sf", "Semibold", nsz, BLACK, x0 + 250, y0 + 118, op)
        if detalle: text_left(fr, detalle, "sf", "Regular", 38, BLACK, x0 + 250, y0 + 176, op)
        chip = str(g.get("chip_tachado", "")) if (u_state > 0.5 and g.get("chip_tachado")) else str(g.get("chip", ""))
        if chip:
            cw = font("sf", "Semibold", 32).getlength(chip) + 44
            rrect(fr, x0 + 250, y0 + 206, x0 + 250 + cw, y0 + 258, 26, c(232, 235, 242), op)
            text_left(fr, chip, "sf", "Semibold", 32, BLACK, x0 + 272, y0 + 243, op)
        if u_state > 0:                                    # se apaga con elegancia: velo blanco + tachado azul
            rrect(fr, x0, y0, x1, y1, 40, WHITE, op * 0.45 * u_state)
            fw = font("sf", "Semibold", nsz).getlength(nombre); ws = eio(u_state)
            cv2.line(fr, (int(x0 + 244), int(y0 + 100)), (int(x0 + 244 + (fw + 12) * ws), int(y0 + 100)),
                     tuple(float(v) for v in BLUE), 7, cv2.LINE_AA)
    else:
        disc(fr, cx, cy, 78, BLUE, op); check_mark(fr, cx, cy, 46, WHITE, op)
        text_left(fr, nombre, "sf", "Bold", nsz, BLACK, x0 + 250, y0 + 118, op)
        if detalle: text_left(fr, detalle, "sf", "Regular", 38, BLACK, x0 + 250, y0 + 176, op)
        chip = str(g.get("chip", ""))
        if chip:
            cw = font("sf", "Semibold", 32).getlength(chip) + 44
            rrect(fr, x0 + 250, y0 + 206, x0 + 250 + cw, y0 + 258, 26, BLUE, op)
            text_left(fr, chip, "sf", "Semibold", 32, WHITE, x0 + 272, y0 + 243, op)
        if sweep is not None and 0 < sweep < 1:
            lay = np.zeros((300, 780, 4), np.float32); lay[..., 3] = rmask(780, 300, 40)
            ae.add(fr, ae.light_sweep(lay, sweep, 0.22, 0.30), x0, y0, op)


def _perfil_y():
    return 560 if VERTICAL else 260


def gr_perfil(fr, t, lt, sh, g):
    _, _, _, _, cx, _ = area()
    u = back(ramp(lt, 0.0, 0.40))
    tt = t_de(g.get("tachar_en"), sh["t0"], sh["t1"], 99) if g.get("tachar_en") else 99
    st = ramp(t, tt, tt + 0.43)
    _perfil(fr, cx - 390, _perfil_y() + 50 * (1 - u) - 20 * eio(st), clamp(u * 1.5), g, st)


def gr_perfil_nuevo(fr, t, lt, sh, g):
    """la tarjeta nueva entra con resorte a la MISMA ranura (match con «perfil» del plano anterior) + destello."""
    _, _, _, _, cx, _ = area()
    prev = g.get("sale")                       # opcional: datos de la tarjeta que sale a la izquierda
    if prev:
        uo = expo(ramp(lt, 0.0, 0.32))
        if uo < 1: _perfil(fr, cx - 390 - 900 * uo, _perfil_y() - 20, 1 - uo, prev, 1.0)
    ui = spring(lt - 0.10, 3.2, 7.0)
    if lt > 0.10:
        _perfil(fr, cx - 390 + 900 * (1 - ui), _perfil_y() - 20, clamp((lt - 0.1) * 6), g, nuevo=True,
                sweep=ramp(lt, 0.55, 1.25))


def gr_barras(fr, t, lt, sh, g):
    """dos barras: una avanza lento, la otra se llena en un parpadeo con ✓ — p032 «más rápido»."""
    x0, y0, x1, y1, cx, cy = area()
    filas = g.get("filas") or [{"etiqueta": "Antes", "valor": "3 días", "lento": True}, {"etiqueta": "Ahora", "valor": "12 min"}]
    te = t_de(g.get("en"), sh["t0"], sh["t1"], 0.4)
    ys = [y0 + 220, y0 + 500] if VERTICAL else [y0 + 170, y0 + 420]
    col_b = WHITE if sh["_fondo"] != "clara" else BLUE
    col_t = WHITE if sh["_fondo"] != "clara" else BLACK
    for j, fila in enumerate(filas[:3]):
        y = ys[j] if j < len(ys) else ys[-1] + 280 * (j - 1)
        u = back(ramp(lt, 0.05 + j * 0.08, 0.45 + j * 0.08)); op = clamp(u * 1.5); dy = 40 * (1 - u)
        text_left(fr, str(fila.get("etiqueta", "")), "sf", "Bold", 64, col_t, x0, y + dy, op)
        rrect(fr, x0, y + 50 + dy, x1, y + 120 + dy, 35, col_b, op * 0.22)
        lento = bool(fila.get("lento"))
        p = 0.30 * ramp(t, te - 0.36, sh["t1"]) ** 0.8 if lento else expo(ramp(t, te, te + 0.44))
        if p > 0.01: rrect(fr, x0, y + 50 + dy, x0 + max(70, (x1 - x0) * p), y + 120 + dy, 35, col_b, op)
        val = str(fila.get("valor", ""))
        if val and (lento or t >= te + 0.44):
            uu = back(ramp(t, te + 0.44, te + 0.74)) if not lento else op
            vx = x1 - font("sf", "Semibold", 50).getlength(val)
            text_left(fr, val, "sf", "Semibold", 50, col_t, vx, y + dy, clamp(uu * 1.4) if not lento else op)
            if not lento: check_mark(fr, vx - 46, y - 16 + dy, 26, col_t, clamp(uu * 1.4), ramp(t, te + 0.49, te + 0.74))
        registrar("grafico", (x0, y - 50, x1, y + 120))


def gr_lista(fr, t, lt, sh, g):
    """tarjeta blanca con título y renglones que reciben palomita azul con resorte — p032 «correcciones»."""
    x0, y0, x1, y1, cx, cy = area()
    items = [str(x) for x in (g.get("items") or [])][:4]
    paso = 150 if VERTICAL else 130
    hgt = 230 + len(items) * paso - 40
    top = (y0 + 100) if VERTICAL else max(y0, cy - hgt / 2)
    if not VERTICAL: x0, x1 = cx - 480, cx + 480
    u = back(ramp(lt, 0, 0.30)); oy = 40 * (1 - u); op = clamp(u * 1.5)
    card_block(fr, x0, top + oy, x1, top + hgt + oy, 44, op)
    disc(fr, x0 + 64, top + 74 + oy, 11, BLUE, op)
    text_left(fr, str(g.get("titulo", "Lista")), "sf", "Semibold", 42, BLACK, x0 + 92, top + 89 + oy, op)
    cv2.line(fr, (int(x0 + 40), int(top + 140 + oy)), (int(x1 - 40), int(top + 140 + oy)), tuple(float(v) for v in c(226, 230, 240)), 2, cv2.LINE_AA)
    te = t_de(g.get("en"), sh["t0"], sh["t1"], 0.06)
    for j, txt in enumerate(items):
        tj = te + j * 0.17
        ur = back(ramp(t, tj, tj + 0.28)); opj = clamp(ur * 1.6) * op
        y = top + 230 + j * paso + oy; dx = 60 * (1 - ur)
        uc = spring(t - tj - 0.20, 4.0, 7.0)
        if t > tj + 0.20:
            disc(fr, x0 + 82 + dx, y, 34 * uc, BLUE, opj)
            check_mark(fr, x0 + 82 + dx, y, 20, WHITE, opj, ramp(t, tj + 0.24, tj + 0.40))
        else:
            disc(fr, x0 + 82 + dx, y, 34, c(232, 235, 242), opj)
        sz = fit(txt, "sf", "Medium", 42, (x1 - x0) - 180, 30)
        text_left(fr, txt, "sf", "Medium", sz, BLACK, x0 + 140 + dx, y + 15, opj)


def gr_vacante(fr, t, lt, sh, g):
    """vacante de VIDRIO con requisitos ✓ escalonados y uno nuevo que entra con resorte y brillo — p032 «mercado»."""
    x0, y0, x1, y1, cx, cy = area()
    items = [str(x) for x in (g.get("items") or [])][:4]
    k = 1.0 if VERTICAL else 0.74
    w = 780 if VERTICAL else 1000
    n = len(items) + (1 if g.get("nuevo") else 0)
    h = int((390 + n * 110 + 40) * k)
    X0 = cx - w / 2; Y0 = (y0 + 30) if VERTICAL else max(y0, cy - h / 2)
    u = back(ramp(lt, 0, 0.35)); oy = 50 * (1 - u); op = clamp(u * 1.5)
    glass_card(fr, X0, Y0 + oy, w, h, 44, op, tinte=(0.55, 0.65, 1.0), tinte_op=0.10, blur=26, borde=0.6, sombra=0.4)
    chip = str(g.get("chip", "Vacante")); cw = font("sf", "Semibold", 32).getlength(chip) + 44
    rrect(fr, X0 + 56, Y0 + 56 * k + oy, X0 + 56 + cw, Y0 + 56 * k + 52 + oy, 26, WHITE, op)
    text_left(fr, chip, "sf", "Semibold", 32, BLACK, X0 + 78, Y0 + 56 * k + 37 + oy, op)
    tit = str(g.get("titulo", "Editor de video"))
    text_left(fr, tit, "sf", "Bold", fit(tit, "sf", "Bold", int(72 * max(k, 0.85)), w - 112), WHITE, X0 + 56, Y0 + 200 * k + oy, op)
    text_left(fr, str(g.get("subtitulo", "Requisitos")), "sf", "Semibold", 40, WHITE, X0 + 56, Y0 + 290 * k + oy, op)
    te = sh["t0"] + 0.14
    for j, r_ in enumerate(items):
        ur = ae.stagger(t, j, te, 0.10, 0.35); y = Y0 + (390 + j * 110) * k + oy
        check_mark(fr, X0 + 84, y - 14, 24, WHITE, clamp(ur * 1.5) * op, clamp(ur))
        text_left(fr, r_, "sf", "Medium", 44, WHITE, X0 + 130, y, clamp(ur * 1.5) * op, 20 * (1 - clamp(ur)))
    if g.get("nuevo"):
        tn = t_de(g.get("nuevo_en"), sh["t0"], sh["t1"], 0.9); un = spring(t - tn, 3.0, 6.5)
        if t > tn:
            y = Y0 + (390 + len(items) * 110) * k + oy; opn = clamp((t - tn) * 6) * op
            hb = int(130 * k); top_ = y - 82 * k
            gg = np.zeros((hb, int(w - 60), 4), np.float32); gg[..., 3] = rmask(int(w - 60), hb, 30) * 0.9
            gl, pad = ae.glow(gg, 20, 0.35, BLUE_D); ae.add(fr, gl, X0 + 30 - pad, top_ - pad, opn * 0.8)
            rrect(fr, X0 + 30, top_, X0 + w - 30, top_ + hb, 30, BLUE, opn)
            check_mark(fr, X0 + 84, y - 14, 24, WHITE, opn, ramp(t, tn + 0.1, tn + 0.3))
            sc = 0.6 + 0.4 * un
            text_left(fr, str(g["nuevo"]), "sf", "Semibold", 44, WHITE, X0 + 130, y, opn)
            et = str(g.get("etiqueta_nuevo", "Nuevo")); bw = font("sf", "Semibold", 30).getlength(et) + 36
            bx = X0 + w - 60 - bw
            rrect(fr, bx + bw * (1 - sc) / 2, y - 50 + 24 * (1 - sc), bx + bw * (1 + sc) / 2, y + 2 - 24 * (1 - sc), 22, WHITE, opn)
            if sc > 0.85: text_left(fr, et, "sf", "Semibold", 30, BLUE, bx + 18, y - 13, opn)


def gr_rejilla(fr, t, lt, sh, g):
    """9 tarjetas: las elegidas se encienden en azul con insignia (escalonado + resorte + brillo) — p032 «IA»."""
    x0, y0, x1, y1, cx, cy = area()
    lit = list(g.get("encender", [0, 2, 4, 5, 7])); lab = str(g.get("etiqueta", "Editor")); ins = str(g.get("insignia", "IA"))
    tw, th, gx, gy = (236, 170, 36, 36) if VERTICAL else (300, 160, 40, 34)
    X0 = cx - (3 * tw + 2 * gx) / 2; Y0 = (y0 + 100) if VERTICAL else cy - (3 * th + 2 * gy) / 2
    te = t_de(g.get("en"), sh["t0"], sh["t1"], 0.7)
    if not lit_dark(sh): ae.particles(fr, t, n=45, seed=9, op=0.35, vel=16)
    for j in range(9):
        r_, q = divmod(j, 3); x = X0 + q * (tw + gx); y = Y0 + r_ * (th + gy)
        u = ae.stagger(t, j, sh["t0"] - 0.12, 0.035, 0.32); op = clamp(u * 1.5); oy = 30 * (1 - clamp(u))
        on = j in lit; tl = te + lit.index(j) * 0.11 if on else 99
        ul = spring(t - tl, 3.5, 7.0) if t > tl else 0.0
        base = c(18, 26, 48) * (1 - clamp(ul)) + BLUE * clamp(ul)
        if ul > 0:
            gg = np.zeros((th, tw, 4), np.float32); gg[..., 3] = rmask(tw, th, 24)
            gl, pad = ae.glow(gg, 22, 0.35, BLUE_D); ae.add(fr, gl, x - pad, y + oy - pad, clamp(ul) * op * 0.9)
        rrect(fr, x, y + oy, x + tw, y + th + oy, 24, base, op)
        rrect(fr, x, y + oy, x + tw, y + th + oy, 24, c(70, 95, 160), op * 0.25 * (1 - clamp(ul)))
        text_left(fr, lab, "sf", "Semibold", 34, WHITE, x + 22, y + 52 + oy, op)
        for b, (a_, b_) in enumerate(((0.0, 0.55), (0.2, 0.85), (0.05, 0.4))):
            bc = WHITE if ul > 0.5 else c(70, 90, 140)
            rrect(fr, x + 22 + a_ * (tw - 44), y + 78 + b * 26 + oy, x + 22 + b_ * (tw - 44), y + 94 + b * 26 + oy, 8, bc, op * (0.9 if ul > 0.5 else 1))
        if ul > 0:
            sc = 0.5 + 0.5 * ul; bw_, bh_ = 64 * sc, 40 * sc; bx, by = x + tw - 22 - 64, y + 20 + oy
            rrect(fr, bx + (64 - bw_) / 2, by + (40 - bh_) / 2, bx + (64 + bw_) / 2, by + (40 + bh_) / 2, 20, WHITE, op)
            if sc > 0.85: text_at(fr, ins, "sf", "Bold", 26, BLUE, bx + 32, by + 30, op)
    registrar("grafico", (X0, Y0, X0 + 3 * tw + 2 * gx, Y0 + 3 * th + 2 * gy))


def lit_dark(sh): return sh["_fondo"] != "oscura"


ICONOS = ("play", "curva", "onda")
_skc: dict = {}


def skill_card(item, etiqueta, insignia, used=0.0):
    key = (json.dumps(item, sort_keys=True), etiqueta, insignia, round(used, 1))
    if key in _skc: return _skc[key]
    w, h = 300, 480
    lay = np.zeros((h, w, 4), np.float32); m = rmask(w, h, 36)
    lay[..., :3] = m[..., None] * WHITE; lay[..., 3] = m
    rgb = lay[..., :3]
    rrect(rgb, 34, 34, 130, 130, 26, BLUE)
    gm = np.zeros((96, 96), np.float32); kind = item.get("icono", "play")
    if kind == "play":
        cv2.fillPoly(gm, [np.int32(np.array([[36, 28], [36, 68], [70, 48]]) * 4)], 1.0, cv2.LINE_AA, 2)
    elif kind in ("curva", "curve"):
        pts = [(24 + 48 * u, 70 - 44 * (3 * u * u - 2 * u ** 3)) for u in np.linspace(0, 1, 30)]
        cv2.polylines(gm, [np.int32(np.array(pts) * 4)], False, 1.0, 5, cv2.LINE_AA, 2)
        for px, py in (pts[0], pts[-1]): cv2.circle(gm, (int(px * 4), int(py * 4)), 7 * 4, 1.0, -1, cv2.LINE_AA, 2)
    else:
        for i, hh in enumerate((14, 30, 44, 26, 38, 18)):
            x = 22 + i * 10.5; cv2.line(gm, (int(x * 4), int((48 - hh / 2) * 4)), (int(x * 4), int((48 + hh / 2) * 4)), 1.0, 5, cv2.LINE_AA, 2)
    rgb[34:130, 34:130] = rgb[34:130, 34:130] * (1 - gm[..., None]) + WHITE * gm[..., None]
    text_left(rgb, etiqueta, "mono", "Regular", 26, BLUE, 34, 186)
    yb = 246
    tit = str(item.get("titulo", ""))
    lines = wrap(tit.replace("-", "- ").replace("- ", "-\n", 1) if font("sf", "Bold", 40).getlength(tit) > w - 64 else tit,
                 font("sf", "Bold", 40), w - 64)
    for ln in lines[:2]:
        sz = 40
        while font("sf", "Bold", sz).getlength(ln) > w - 64 and sz > 24: sz -= 2
        text_left(rgb, ln, "sf", "Bold", sz, BLACK, 34, yb); yb += 48
    text_left(rgb, str(item.get("detalle", "")), "sf", "Regular", 30, BLACK, 34, yb + 10)
    if used > 0:
        sc = 0.6 + 0.4 * used; bw = font("sf", "Semibold", 28).getlength(insignia) + 70
        bx, by = 34, h - 30 - 52
        rrect(rgb, bx, by + 26 * (1 - sc), bx + bw * sc, by + 52 - 26 * (1 - sc), 26, BLUE)
        if used > 0.8:
            check_mark(rgb, bx + 30, by + 26, 15, WHITE, 1.0)
            text_left(rgb, insignia, "sf", "Semibold", 28, WHITE, bx + 52, by + 36)
    if len(_skc) > 200: _skc.clear()
    _skc[key] = lay
    return lay


def gr_abanico(fr, t, lt, sh, g):
    """3 tarjetas apiladas que se abren en abanico con rebote y reciben «✓ En uso» — p032 «skills»."""
    x0, y0, x1, y1, cx, cy = area()
    items = (g.get("tarjetas") or [{"titulo": "Uno", "icono": "play"}, {"titulo": "Dos", "icono": "curva"},
                                   {"titulo": "Tres", "icono": "onda"}])[:3]
    while len(items) < 3: items.append(items[-1])
    ae.particles(fr, t, n=35, seed=5, color=(0.18, 0.42, 1.0), op=0.30, vel=14)
    k = 1.0 if VERTICAL else 0.95
    cyb = 650 if VERTICAL else cy
    fan = [(cx - 308, cyb, 8.0), (cx + 308, cyb, -8.0), (cx, cyb - 50, 0.0)] if VERTICAL else \
          [(cx - 360, cyb + 20, 8.0), (cx + 360, cyb + 20, -8.0), (cx, cyb - 10, 0.0)]
    order = [0, 2, 1]
    tf = t_de(g.get("abrir_en"), sh["t0"], sh["t1"], 0.9); uf = spring(t - tf, 2.2, 6.0) if t > tf else 0.0
    tu0 = t_de(g.get("insignia_en"), sh["t0"], sh["t1"], 99) if g.get("insignia_en") else 99
    for slot in (0, 1, 2):
        j = order[slot]
        ui = ae.stagger(t, slot, sh["t0"] + 0.05, 0.10, 0.50)
        fx, fy, rot = fan[slot]
        sx0, sy0, r0 = cx + (slot - 1) * 14, cyb + 40 + (slot - 1) * -6, (slot - 1) * 3.0
        x = lerp(sx0, fx, uf); y = lerp(sy0, fy, uf) + 160 * (1 - ui); r = lerp(r0, rot, uf)
        tu = tu0 + slot * 0.09; used = clamp(back(ramp(t, tu, tu + 0.30))) if t > tu else 0.0
        put_layer(fr, skill_card(items[j], str(g.get("etiqueta", "SKILL")), str(g.get("insignia", "En uso")),
                                 round(used * 10) / 10), x, y, (0.92 + 0.08 * clamp(ui)) * k, r, clamp(ui * 1.6), 0.30)
    registrar("grafico", (cx - 480, cyb - 290, cx + 480, cyb + 290))


def gr_logos(fr, t, lt, sh, g):
    x0, y0, x1, y1, cx, cy = area()
    names = list(g.get("logos") or [])
    n = len(names)
    for j, nm in enumerate(names):
        x = cx + (j - (n - 1) / 2) * (300 if VERTICAL else 360)
        logo_pop(fr, nm, x, (760 if VERTICAL else cy), 190, t, sh["t0"] + 0.05 + j * 0.18)


PH = None


def phone_layer(img):
    w, h, b, r = (470, 836, 16, 64) if VERTICAL else (300, 534, 12, 46)
    W2, H2 = w + 2 * b, h + 2 * b
    lay = np.zeros((H2, W2, 4), np.float32); m = rmask(W2, H2, r)
    lay[..., :3] = c(14, 16, 22) * m[..., None]; lay[..., 3] = m
    scr = img_card(img, w, h, r - b); a = scr[..., 3:4]
    lay[b:b + h, b:b + w] = lay[b:b + h, b:b + w] * (1 - a) + scr
    nb = np.zeros((26, 120, 4), np.float32); nm = rmask(120, 26, 13); nb[..., :3] = c(14, 16, 22) * nm[..., None]; nb[..., 3] = nm
    ae.over(lay[..., :3], nb, W2 / 2 - 60, b + 14)
    return lay


def gr_celular(fr, t, lt, sh, g):
    """celular limpio que entra con resorte y se endereza; adentro, el clip — p032 «celular»."""
    x0, y0, x1, y1, cx, cy = area()
    u = spring(lt, 2.6, 6.5); op = clamp(lt * 7)
    lay = phone_layer(recurso(sh, 0, lt))
    py = 760 if VERTICAL else cy
    put_layer(fr, lay, cx, py + 220 * (1 - u), 0.92 + 0.08 * clamp(u), -8 * (1 - clamp(u)), op, 0.35)
    registrar("grafico", (cx - lay.shape[1] / 2, py - lay.shape[0] / 2, cx + lay.shape[1] / 2, py + lay.shape[0] / 2))


GRAFICOS = dict(punto=gr_punto, giro=gr_giro, numero=gr_numero, interruptor=gr_interruptor, perfil=gr_perfil,
                perfil_nuevo=gr_perfil_nuevo, barras=gr_barras, lista=gr_lista, vacante=gr_vacante, rejilla=gr_rejilla,
                abanico=gr_abanico, logos=gr_logos, celular=gr_celular)


# ══════════════════════════════════════════ escenas ══════════════════════════════════════════
def sc_tarjeta(t, lt, sh, toma):
    fr = fondo(sh["_fondo"], t, sh["_seed"])
    g = sh.get("grafico")
    if g and g.get("tipo") in GRAFICOS: GRAFICOS[g["tipo"]](fr, t, lt, sh, g)
    cs, cb = colores(sh["_fondo"])
    band(fr, t, sh, cs, cb)
    return fr


def sc_stock(t, lt, sh, toma):
    im = recurso(sh, 0, lt)
    im = cv2.resize(cover(im, W, H), (W, H), interpolation=cv2.INTER_AREA if im.shape[1] > W else cv2.INTER_CUBIC)
    s = lerp(1.0, float(sh.get("zoom", 1.05)), eio(lt / max(0.5, sh["t1"] - sh["t0"])))
    im = toma_xf(im, s, (W / 2, H * 0.43))
    fr = cine(im)
    band(fr, t, sh, WHITE, BLUE_D)
    return fr


def sc_flotante(t, lt, sh, toma):
    modo = sh.get("modo", "fila"); n = max(1, len(sh.get("fuentes") or [sh.get("fuente")] if (sh.get("fuentes") or sh.get("fuente")) else [None]))
    fnd = sh.get("fondo", "oscura" if modo == "demo" else ("azul" if modo == "trayectoria" else "clara"))
    sh["_fondo"] = fnd
    x0, y0, x1, y1, cx, cy = area()
    if modo == "demo":                                         # p032: dos pantallas en cámara 2.5D con paralaje
        fr = bg_dark(t, 1)
        ae.grid_floor(fr, t, horizonte=0.70, op=0.22, vel=0.35); ae.particles(fr, t, n=55, seed=3, op=0.45, vel=22)
        cam = ae.Camera(W, H, zoom=lerp(1.0, 1.05, eio(lt / max(0.5, sh["t1"] - sh["t0"]))))
        u = back(ramp(lt, 0.0, 0.40))
        if VERTICAL:
            lay = img_card(recurso(sh, 0, lt), 900, 506, 28)
            sx, sy, kk = cam.to_screen(540, 470 + 50 * (1 - u), 1.35)
        else:
            lay = img_card(recurso(sh, 0, lt), 960, 540, 28)
            sx, sy, kk = cam.to_screen(800, 420 + 50 * (1 - u), 1.35)
        put_layer(fr, lay, sx, sy, kk * (0.86 + 0.14 * u), -2.5, clamp(u * 1.4), 0.40)
        u2 = back(ramp(lt, 0.10, 0.52))
        lay2 = img_card(recurso(sh, min(1, n - 1) if n > 1 else 0, lt), 372 if VERTICAL else 300, 661 if VERTICAL else 533, 32)
        sw = ae.light_sweep(lay2, ramp(lt, 0.55, 1.25), 0.16, 0.45)
        lay2 = lay2.copy(); lay2[..., :3] = np.minimum(1, lay2[..., :3] + sw)
        sx, sy, kk = cam.to_screen(560 if VERTICAL else 1320, (900 if VERTICAL else 470) + 80 * (1 - u2), 1.0)
        put_layer(fr, lay2, sx, sy, kk * (0.88 + 0.12 * u2), 2.0, clamp(u2 * 1.4), 0.55)
        registrar("grafico", (sx - lay2.shape[1] / 2, sy - lay2.shape[0] / 2, sx + lay2.shape[1] / 2, sy + lay2.shape[0] / 2))
    elif modo == "trayectoria":                                # p032: viaja por una curva con fotogramas clave ◆
        fr = fondo(fnd, t, sh["_seed"])
        if VERTICAL: P0, P1, P2, P3 = (300, 1010), (300, 560), (760, 1010), (760, 560)
        else: P0, P1, P2, P3 = (620, 640), (620, 200), (1300, 640), (1300, 200)

        def bez(p):
            q = 1 - p
            return (q ** 3 * P0[0] + 3 * q * q * p * P1[0] + 3 * q * p * p * P2[0] + p ** 3 * P3[0],
                    q ** 3 * P0[1] + 3 * q * q * p * P1[1] + 3 * q * p * p * P2[1] + p ** 3 * P3[1])
        up_ = eo(ramp(lt, 0, 0.30))
        m = np.zeros((H, W), np.float32); nn = 60
        for i in range(int(nn * up_)):
            if i % 2: continue
            a, b = bez(i / nn), bez((i + 1) / nn)
            cv2.line(m, (int(a[0] * 4), int(a[1] * 4)), (int(b[0] * 4), int(b[1] * 4)), 1.0, 4, cv2.LINE_AA, 2)
        lc = WHITE if fnd != "clara" else BLUE
        fr[:] = fr * (1 - m[..., None] * 0.75) + lc * m[..., None] * 0.75
        p = ae.ease_in_out_expo(ramp(lt, 0.22, 1.05))
        for kp in (0.0, 0.5, 1.0):
            kx, ky = bez(kp); on = p >= kp - 1e-3
            pts = np.array([[kx, ky - 18], [kx + 18, ky], [kx, ky + 18], [kx - 18, ky]], np.float32)
            mm = np.zeros((H, W), np.float32); cv2.fillPoly(mm, [np.int32(pts * 4)], 1.0, cv2.LINE_AA, 2)
            col = (WHITE if on else c(150, 180, 255)) if fnd != "clara" else (BLUE if on else c(150, 175, 255))
            fr[:] = fr * (1 - mm[..., None] * up_) + col * mm[..., None] * up_
        cw_, chh = (288, 512) if VERTICAL else (240, 427)
        card = img_card(recurso(sh, 0, lt), cw_, chh, 28)
        for gg, dp in ((0.10, 0.12), (0.18, 0.07)):
            if 0.02 < p < 0.98:
                gx, gy = bez(max(0, p - dp)); put_layer(fr, card, gx, gy, 0.96, 0, gg * up_, 0)
        ccx, ccy = bez(p); dx, dy = bez(min(1, p + 0.01)); ang = -math.degrees(math.atan2(dy - ccy, dx - ccx + 1e-6)) * 0.08
        settle = spring(lt - 1.05, 3.0, 6.0) if lt > 1.05 else 0
        put_layer(fr, card, ccx, ccy, 1.0 + 0.03 * math.sin(math.pi * clamp(settle)), ang * (1 - clamp(settle)), up_, 0.45)
        registrar("grafico", (ccx - cw_ / 2, ccy - chh / 2, ccx + cw_ / 2, ccy + chh / 2))
    else:                                                       # fila: 1, 2, 3 o 4–5 tarjetas flotando (p030/p031)
        fr = fondo(fnd, t, sh["_seed"])
        k = int(lt * FPS)
        if n == 1:
            u = eo(ramp(lt, 0, 0.28)); bob = math.sin(t * 2.2) * 8
            w_, h_ = (400, 711) if VERTICAL else (360, 640)
            if sh.get("horizontal_clip"): w_, h_ = (780, 439) if VERTICAL else (900, 506)
            float_card(fr, recurso(sh, 0, lt), cx, (690 if VERTICAL else cy) + bob + 40 * (1 - u), w_, h_, u, 0,
                       0.9 if fnd == "oscura" else 0.30, 34, 0.95 + 0.05 * u)
        elif n == 2:
            pos = ((cx - 175, -4, 0.0), (cx + 175, 4, 0.08)) if VERTICAL else ((cx - 250, -4, 0.0), (cx + 250, 4, 0.08))
            for j, (px, rot, d) in enumerate(pos):
                u = eo(ramp(lt, d, d + 0.28)); bob = math.sin((t + d * 7) * 2.4) * 9
                w_, h_ = (320, 569) if VERTICAL else (300, 533)
                float_card(fr, recurso(sh, j, lt), px, (640 if VERTICAL else cy) + bob + 50 * (1 - u), w_, h_, u, rot, 0.30, 30, 0.94 + 0.06 * u)
        elif n == 3 or VERTICAL:
            sp = 240 if VERTICAL else 330
            for j, (dxs, rot, d, sc, dyy) in enumerate(((-1, -7, 0.06, 0.82, 40), (1, 7, 0.12, 0.82, 40), (0, 0, 0.0, 1.0, 0))):
                u = eo(ramp(lt, d, d + 0.28)); bob = math.sin((t + d * 9) * 2.3) * 8
                w_, h_ = (330, 587) if VERTICAL else (300, 533)
                float_card(fr, recurso(sh, [1, 2, 0][j] if n >= 3 else 0, lt), cx + dxs * sp,
                           (660 if VERTICAL else cy - 10) + dyy + bob + 50 * (1 - u), w_ * sc, h_ * sc, u, rot, 0.28, 30, 0.94 + 0.06 * u)
        else:
            for i in range(min(5, n)):
                d = 0.04 * abs(i - 2); ui = eo(ramp(lt, d, d + 0.26)); bob = math.sin((t + i * 0.9) * 2.3) * 7
                float_card(fr, recurso(sh, i, lt), 960 + (i - 2) * 318, cy - 20 + bob + 60 * (1 - ui) + abs(i - 2) * 14,
                           270, 480, ui, (i - 2) * -1.6, 0.30, 26, 0.92 + 0.08 * ui)
    cs, cb = colores(fnd)
    band(fr, t, sh, cs, cb)
    return fr


def sc_prompt(t, lt, sh, toma):
    """tarjeta de VIDRIO con el prompt + botón Copiar → ✓ Copiado con onda + destello — p032."""
    fr = bg_dark(t, 5)
    ae.particles(fr, t, n=90 if VERTICAL else 110, seed=21, op=0.55, vel=20, tam=(1.4, 3.6))
    x0, y0, x1, y1, cx, cy = area()
    txt = sh.get("texto")
    if not txt and sh.get("archivo"):
        txt = _ruta(P["_base"], sh["archivo"]).read_text(encoding="utf-8").strip()
    txt = txt or "Escribe aquí tu prompt."
    w = 780 if VERTICAL else 1060
    X0 = cx - w / 2
    fsz = 37 if VERTICAL else 34; lh = 54 if VERTICAL else 46
    f = font("sf", "Regular", fsz); lines = wrap(txt, f, w - 104)
    maxl = 13 if VERTICAL else 8
    if len(lines) > maxl:
        lines = lines[:maxl]; lines[-1] = lines[-1].rstrip(".,; ") + "…"
    h = 70 + 50 + len(lines) * lh + 40 + 96 + 56
    Y0 = (y0) if VERTICAL else max(y0 - 10, cy - h / 2)
    u = back(ramp(lt, 0, 0.30)); op = clamp(u * 1.6); oy = 40 * (1 - u); yc = Y0 + oy
    glass_card(fr, X0, yc, w, h, 44, op, tinte=(0.6, 0.7, 1.0), tinte_op=0.12, blur=28, borde=0.65, sombra=0.45)
    disc(fr, X0 + 62, yc + 70, 11, BLUE_D, op)
    text_left(fr, str(sh.get("titulo", "Prompt")), "sf", "Semibold", 42, WHITE, X0 + 88, yc + 85, op)
    etq = str(sh.get("etiqueta", "Claude"))
    text_left(fr, etq, "mono", "Regular", 30, BLUE_D, X0 + w - 52 - font("mono", "Regular", 30).getlength(etq), yc + 83, op)
    y = yc + 70 + 50 + 40
    for j, ln in enumerate(lines):
        ul = eo(ramp(lt, 0.06 + j * 0.025, 0.22 + j * 0.025))
        text_left(fr, ln, "sf", "Regular", fsz, WHITE, X0 + 52, y + 8 * (1 - ul), op * ul); y += lh
    by = y + 22; tp = t_de(sh.get("copiar_en"), sh["t0"], sh["t1"], 0.25)
    press = ramp(t, tp, tp + 0.14); s_ = 1 - 0.07 * math.sin(math.pi * press); copied = t >= tp + 0.14
    lab = str(sh.get("copiado", "Copiado")) if copied else str(sh.get("copiar", "Copiar")); fb = font("sf", "Semibold", 40)
    bw = (fb.getlength(lab) + (150 if copied else 110)) * s_; bh = 92 * s_
    bx0 = cx - bw / 2; by0 = by + (92 - bh) / 2
    if copied:
        ur = ramp(t, tp + 0.14, tp + 0.60)
        if ur < 1:
            m = np.zeros((H, W), np.float32)
            cv2.ellipse(m, (int(cx), int(by0 + bh / 2)), (int(bw / 2 + 120 * ur), int(bh / 2 + 60 * ur)), 0, 0, 360, 1.0, 3, cv2.LINE_AA)
            fr[:] = np.minimum(1, fr + m[..., None] * BLUE_D * (1 - ur) * op)
    rrect(fr, bx0, by0, bx0 + bw, by0 + bh, int(bh / 2), BLUE if copied else WHITE, op)
    if copied:
        check_mark(fr, bx0 + 52 * s_, by0 + bh / 2, 22, WHITE, op, ramp(t, tp + 0.14, tp + 0.32))
        text_at(fr, lab, "sf", "Semibold", int(40 * s_), WHITE, cx + 22, by0 + bh / 2 + 14, op)
    else:
        text_at(fr, lab, "sf", "Semibold", int(40 * s_), BLACK, cx, by0 + bh / 2 + 14, op)
    sw = ramp(t, tp + 0.68, tp + 1.48)
    if 0 < sw < 1:
        lay = np.zeros((int(h), int(w), 4), np.float32); lay[..., 3] = rmask(int(w), int(h), 44)
        ae.add(fr, ae.light_sweep(lay, sw, 0.18, 0.16), X0, yc, op)
    band(fr, t, sh, WHITE, BLUE_D)
    return fr


def sc_comparativa(t, lt, sh, toma):
    """antes (se tacha en azul) contra después (grande, azul) — p030 «versus»."""
    fr = bg_light(t, sh["_seed"])
    x0, y0, x1, y1, cx, cy = area()
    t0, t1 = sh["t0"], sh["t1"]
    la, a_, ld, d_ = (str(sh.get(k, "")) for k in ("antes_etiqueta", "antes", "despues_etiqueta", "despues"))
    te = t0 + 0.02; tt = t_de(sh.get("tachar_en"), t0, t1, 0.18); td = t_de(sh.get("despues_en"), t0, t1, 0.6)
    if VERTICAL: yl1, ya, yl2, yd = 560, 700, 900, 1200
    else: yl1, ya, yl2, yd = 210, 340, 480, 720
    if la: line_words(fr, [(w, te) for w in la.split()], t, "sf", "Semibold", 46, BLACK, cx, yl1, rol="ui")
    u, dy = wanim(t, te)
    sa = fit(a_, "sf", "Bold", 130, G["maxw"]); fa = font("sf", "Bold", sa); w1 = fa.getlength(a_)
    text_at(fr, a_, "sf", "Bold", sa, BLACK, cx, ya, u, dy)
    st = eio(ramp(t, tt, tt + 0.3))
    if st > 0:
        ys = int(ya - sa * 0.35)
        cv2.line(fr, (int(cx - w1 / 2 - 14), ys), (int(cx - w1 / 2 - 14 + (w1 + 28) * st), ys), tuple(float(v) for v in BLUE), 10, cv2.LINE_AA)
    if ld: line_words(fr, [(w, max(te, td - 0.3)) for w in ld.split()], t, "sf", "Semibold", 46, BLACK, cx, yl2, rol="ui")
    u2, dy2 = wanim(t, td, 34)
    m = re.match(r"^\s*([\d.,$€%+]+)\s*(.*)$", d_)
    big = 300 if VERTICAL else 260
    if m and m.group(2):
        num, uni = m.group(1), m.group(2)
        fb = font("sf", "Bold", big); fu = font("sf", "Bold", int(big * 0.32))
        tw = fb.getlength(num) + 24 + fu.getlength(uni); x = cx - tw / 2
        text_at(fr, num, "sf", "Bold", big, BLUE, x + fb.getlength(num) / 2, yd, u2, dy2)
        text_at(fr, uni, "sf", "Bold", int(big * 0.32), BLUE, x + fb.getlength(num) + 24 + fu.getlength(uni) / 2, yd, u2, dy2)
    else:
        sz = fit(d_, "sf", "Bold", 180 if VERTICAL else 160, G["maxw"])
        text_at(fr, d_, "sf", "Bold", sz, BLUE, cx, yd, u2, dy2)
    return fr


def sc_pasos(t, lt, sh, toma):
    """Paso 1 → 2 → 3 con flechas que se dibujan, barra que se llena y ✓ — p031 «pasos»."""
    fr = bg_light(t, sh["_seed"])
    x0, y0, x1, y1, cx, cy = area()
    labs = [str(x) for x in (sh.get("pasos") or ["Graba", "Edita", "Publica"])][:4]
    n = len(labs); t0, t1 = sh["t0"], sh["t1"]
    starts = [t0 + 0.05 + 0.2 * j for j in range(n)]
    tc = t_de(sh.get("check_en"), t0, t1, max(0.8, (t1 - t0) * 0.7))
    checks = [tc + 0.14 * j for j in range(n)]
    pref = str(sh.get("prefijo", "Paso"))
    if VERTICAL:
        ch_, gap = 190, 50
        tot = n * ch_ + (n - 1) * gap; top = y0 + max(0, (1000 - 80 - tot) / 2)
        for j in range(n):
            u = eo(ramp(t, starts[j], starts[j] + 0.25))
            if u <= 0: continue
            yy0 = top + j * (ch_ + gap) + 40 * (1 - u); yy1 = yy0 + ch_
            card_block(fr, x0, yy0, x1, yy1, 32, u)
            ck = eio(ramp(t, checks[j], checks[j] + 0.16))
            disc(fr, x0 + 110, yy0 + ch_ / 2, 58, BLUE, u)
            if ck < 1: text_at(fr, str(j + 1), "sf", "Bold", 64, WHITE, x0 + 110, yy0 + ch_ / 2 + 23, u * (1 - ck))
            if ck > 0: check_mark(fr, x0 + 110, yy0 + ch_ / 2, 30, WHITE, u * ck)
            text_left(fr, f"{pref} {j + 1}", "sf", "Semibold", 32, BLUE, x0 + 210, yy0 + 78, u)
            text_left(fr, labs[j], "sf", "Bold", fit(labs[j], "sf", "Bold", 52, x1 - x0 - 260), BLACK, x0 + 210, yy0 + 140, u)
            if j < n - 1:
                ua = eio(ramp(t, starts[j + 1] - 0.05, starts[j + 1] + 0.2))
                if ua > 0:
                    ya_ = yy1 + 8; yb_ = ya_ + (gap - 16) * ua
                    cv2.line(fr, (int(x0 + 110), int(ya_)), (int(x0 + 110), int(yb_)), tuple(float(v) for v in BLUE), 5, cv2.LINE_AA)
        ybar = top + tot + 60
    else:
        cw, gap = 360, 80
        tot = n * cw + (n - 1) * gap; left = cx - tot / 2
        for j in range(n):
            ccx = left + cw / 2 + j * (cw + gap); u = eo(ramp(t, starts[j], starts[j] + 0.25))
            if u <= 0: continue
            yy0, yy1 = 220 + 40 * (1 - u), 560 + 40 * (1 - u)
            card_block(fr, ccx - cw / 2, yy0, ccx + cw / 2, yy1, 32, u)
            text_at(fr, f"{pref} {j + 1}", "sf", "Semibold", 32, BLUE, ccx, yy0 + 72, u)
            ck = eio(ramp(t, checks[j], checks[j] + 0.16))
            disc(fr, ccx, yy0 + 170, 58, BLUE, u)
            if ck < 1: text_at(fr, str(j + 1), "sf", "Bold", 64, WHITE, ccx, yy0 + 193, u * (1 - ck))
            if ck > 0: check_mark(fr, ccx, yy0 + 170, 30, WHITE, u * ck)
            text_at(fr, labs[j], "sf", "Bold", fit(labs[j], "sf", "Bold", 42, cw - 40), BLACK, ccx, yy0 + 290, u)
            if j < n - 1:
                ua = eio(ramp(t, starts[j + 1] - 0.05, starts[j + 1] + 0.2))
                if ua > 0:
                    xa = ccx + cw / 2 + 16; xb = xa + (gap - 32) * ua
                    cv2.line(fr, (int(xa), 390), (int(xb), 390), tuple(float(v) for v in BLUE), 5, cv2.LINE_AA)
                    if ua > 0.95:
                        cv2.fillPoly(fr, [np.array([[xb + 10, 390], [xb - 6, 380], [xb - 6, 400]], np.int32)], tuple(float(v) for v in BLUE), cv2.LINE_AA)
        ybar = 640
    pu = eo(ramp(t, t0 + 0.15, t0 + 0.45)); pf = eio(ramp(t, t0 + 0.55, tc))
    if pu > 0:
        bw_ = 720 if not VERTICAL else 560
        rrect(fr, cx - bw_ / 2, ybar, cx + bw_ / 2, ybar + 16, 8, c(214, 224, 250), pu)
        if pf > 0.02: rrect(fr, cx - bw_ / 2, ybar, cx - bw_ / 2 + bw_ * pf, ybar + 16, 8, BLUE, pu)
    band(fr, t, sh, BLACK, BLUE)
    return fr


def sc_contador(t, lt, sh, toma):
    """tarjeta del canal: avatar, nombre, número que sube con pulso + onda y botón Suscribirse → Suscrito — p031."""
    fr = bg_light(t, sh["_seed"])
    x0, y0, x1, y1, cx, cy = area()
    t0, t1 = sh["t0"], sh["t1"]
    u = eo(ramp(lt, 0, 0.28)); dy = 40 * (1 - u)
    cw, chh = (780, 760) if VERTICAL else (880, 640)
    X0, Y0 = cx - cw / 2, (y0 + 60 if VERTICAL else 100) + dy
    card_block(fr, X0, Y0, X0 + cw, Y0 + chh, 40, u, sombra=0.22)
    ya, yn_, yu, yn0, ylab, ybt = (120, 250, 298, 470, 534, chh - 90) if VERTICAL else (105, 222, 264, 400, 452, chh - 72)
    avatar(fr, cx, Y0 + ya, 70 if VERTICAL else 62, u)
    text_at(fr, str(P.get("_nombre", "Tu Nombre")), "sf", "Bold", 44, BLACK, cx, Y0 + yn_, u)
    text_at(fr, str(P.get("_usuario", "@tu_usuario")), "sf", "Medium", 30, BLACK, cx, Y0 + yu, u)
    a, b = int(sh.get("desde", 186240)), int(sh.get("hasta", 200000))
    tl = t_de(sh.get("llega_en"), t0, t1, max(0.6, (t1 - t0) * 0.6))
    v = int(round(lerp(a, b, eio(ramp(t, t0 + 0.08, tl))))); hit = t >= tl
    pop = 1 + 0.10 * math.sin(math.pi * ramp(t, tl, tl + 0.24)) if hit else 1
    txt = f"{v:,}"; size = int(150 * pop)
    yn = Y0 + yn0
    text_at(fr, txt, "sf", "Bold", size, BLUE, cx, yn + (size - 150) * 0.37, u)
    if hit:
        rr = eo(ramp(t, tl, tl + 0.62)); ring(fr, cx, yn - 50, 200 + 260 * rr, 5, BLUE, (1 - rr) * 0.8)
    lbl = str(sh.get("etiqueta", "suscriptores"))
    text_at(fr, lbl, "sf", "Semibold", 36, BLACK, cx, Y0 + ylab, u)
    if sh.get("boton", True):
        tp = t_de(sh.get("presionar_en"), t0, t1, max(0.4, (t1 - t0) * 0.5))
        ub = back(ramp(t, t0 + 0.30, t0 + 0.60)); pressed = t >= tp
        dip = 1 - 0.08 * math.sin(math.pi * ramp(t, tp - 0.12, tp + 0.04))
        sc = clamp(ub, 0.05, 1.2) * dip
        lab = str(sh.get("suscrito", "Suscrito")) if pressed else str(sh.get("suscribirse", "Suscribirse"))
        f = font("sf", "Semibold", 40)
        pw = (f.getlength(lab) + (150 if pressed else 96)) * sc; ph = 96 * sc
        bcx, bcy = cx, Y0 + ybt
        bx0, by0 = bcx - pw / 2, bcy - ph / 2; op = clamp(ramp(t, t0 + 0.30, t0 + 0.38)) * u
        shadow_rect(fr, int(bx0), int(by0), int(bx0 + pw), int(by0 + ph), int(ph / 2), op, 0.35)
        rrect(fr, bx0, by0, bx0 + pw, by0 + ph, int(ph / 2), BLUE if pressed else BLACK, op)
        if pressed:
            check_mark(fr, bx0 + 52 * sc, bcy, 20 * sc, WHITE, op, ramp(t, tp, tp + 0.18))
            text_at(fr, lab, "sf", "Semibold", max(8, int(40 * sc)), WHITE, bcx + 22 * sc, bcy + 14 * sc, op)
        else:
            text_at(fr, lab, "sf", "Semibold", max(8, int(40 * sc)), WHITE, bcx, bcy + 14 * sc, op)
        if tp - 0.3 <= t < tp + 0.4:
            rr = eo(ramp(t, tp - 0.12, tp + 0.30)); ring(fr, bcx + 40, bcy + 12, 40 + 20 * rr, 3, BLUE_D, 0.9 * (1 - rr))
    band(fr, t, sh, BLACK, BLUE)
    return fr


def sc_chat(t, lt, sh, toma):
    """burbuja del usuario (azul) y respuesta (blanca) que pasa de «…» a ✓ — p030 «chat»."""
    fr = bg_light(t, sh["_seed"])
    x0, y0, x1, y1, cx, cy = area()
    t0, t1 = sh["t0"], sh["t1"]
    q = str(sh.get("pregunta", "Edita mis videos")); r_ = str(sh.get("respuesta", "Listo. Tu video ya está editado"))
    tq = t_de(sh.get("pregunta_en"), t0, t1, 0.15); tr_ = tq + 0.32; td = t_de(sh.get("listo_en"), t0, t1, 0.0)
    td = max(td, tr_ + 0.4)
    f = font("sf", "Medium", 44)
    ybase = (640 if VERTICAL else 250)
    if not VERTICAL: x0, x1 = cx - 520, cx + 520
    u = eo(ramp(t, tq, tq + 0.2))
    if u > 0:
        bw = min(f.getlength(q) + 80, x1 - x0); X1 = x1 - 30; X0 = X1 - bw; Y0 = ybase + 30 * (1 - u)
        rrect(fr, X0, Y0, X1, Y0 + 104, 46, BLUE, u)
        text_at(fr, q, "sf", "Medium", fit(q, "sf", "Medium", 44, bw - 60, 28), WHITE, (X0 + X1) / 2, Y0 + 67, u)
        registrar("grafico", (X0, Y0, X1, Y0 + 104))
    u2 = eo(ramp(t, tr_, tr_ + 0.2))
    if u2 > 0:
        done = t >= td
        sz = fit(r_, "sf", "Medium", 44, (x1 - x0) - 180, 28); fr_ = font("sf", "Medium", sz)
        bw = (fr_.getlength(r_) + 80 + 64) if done else 190
        X0 = x0 + 30; Y0 = ybase + 160 + 30 * (1 - u2)
        card_block(fr, X0, Y0, X0 + bw, Y0 + 104, 46, u2, sombra=0.14)
        if done:
            ud = eo(ramp(t, td, td + 0.14))
            disc(fr, X0 + 62, Y0 + 52, 26 * ud, BLUE, u2)
            check_mark(fr, X0 + 62, Y0 + 52, 16, WHITE, ud * u2)
            text_at(fr, r_, "sf", "Medium", sz, BLACK, X0 + 102 + fr_.getlength(r_) / 2, Y0 + 67, ud * u2)
        else:
            for j in range(3):
                ph = 0.5 + 0.5 * math.sin(t * 12 - j * 0.9)
                disc(fr, X0 + 58 + j * 38, Y0 + 52, 10, BLACK * (0.35 + 0.5 * ph) + WHITE * (0.65 - 0.5 * ph), u2)
    band(fr, t, sh, BLACK, BLUE)
    return fr


def sc_titulo(t, lt, sh, toma):
    """rejilla técnica + título que se descifra (p030/p031 «Claude»)."""
    fr = tech_grid(t, sh["t0"])
    x0, y0, x1, y1, cx, cy = area()
    tit = str(sh.get("titulo", "Claude")); tt = t_de(sh.get("titulo_en"), sh["t0"], sh["t1"], 0.05)
    sz = fit(tit, "sf", "Bold", 190 if VERTICAL else 220, G["maxw"])
    base = (900 if VERTICAL else 600)
    sm = tiempos(sh.get("contexto"), sh["t0"], sh["t1"])
    if sm: line_words(fr, sm, t, "sf", "Semibold", small_size(sm), WHITE, cx, base - sz * 0.74 - 50 if not VERTICAL else base + 110)
    if t >= tt - 0.1: decode_text(fr, tit, t, tt, 0.45, sz, cx, base, BLUE_D * 0.35 + WHITE * 0.65)
    return fr


ESCENAS = dict(tarjeta_clara=sc_tarjeta, tarjeta_azul=sc_tarjeta, tarjeta_oscura=sc_tarjeta, stock=sc_stock,
               video_flotante=sc_flotante, prompt=sc_prompt, comparativa=sc_comparativa, pasos=sc_pasos,
               contador=sc_contador, chat=sc_chat, titulo_tecnico=sc_titulo)
CARA = ("cara", "cierre")


# ══════════════════════════════════════════ cuadro ══════════════════════════════════════════
def shot_at(t):
    for s in P["planos"]:
        if s["t0"] - 1e-6 <= t < s["t1"] - 1e-6: return s
    return P["planos"][-1]


def frame(i, toma):
    t = i / FPS
    sh = shot_at(t)
    lt = t - sh["t0"]; kind = sh["tipo"]
    if kind in CARA:
        fr = toma_xf(toma, sh["_s"])
        face_text(fr, t, sh)
    elif kind == "gancho":
        s = lerp(sh["_s0"], sh["_s0"] + 0.04, eio(lt / 2.0))
        fr = toma_xf(toma, s)
        if sh.get("logos") and not VERTICAL:
            side = 1590 if sh["_pill_cx"] < 960 else 330
            for j, nm in enumerate(sh["logos"][:2]):
                logo_pop(fr, nm, side, 300 + j * 280, 190 if j == 0 else 150, t, sh["t0"] + j * 0.75)
        face_text(fr, t, sh)
    else:
        fr = ESCENAS.get(kind, sc_tarjeta)(t, lt, sh, toma)
    g = P.get("_gancho")
    if g and g.get("texto") and t < g["_pill_hasta"]:
        pill(fr, str(g["texto"]), g["_pill_cx"], g["_pill_y"])
    return np.clip(fr, 0, 1)


# ══════════════════════════════════════════ carga del plan ══════════════════════════════════════════
def cargar_plan(plan_path, quiet=False):
    global P, PAL, NF
    plan_path = Path(plan_path).resolve()
    P = json.loads(plan_path.read_text(encoding="utf-8"))
    base = Path(P["base"]) if P.get("base") else plan_path.parent      # «base»: copia del plan hecha por editar.py
    mat = _ruta(base, P.get("material", "."))
    info = json.loads((mat / "info.json").read_text(encoding="utf-8")) if (mat / "info.json").exists() else {}
    formato = P.get("formato") or ("vertical" if info.get("alto", 1920) > info.get("ancho", 1080) else "horizontal")
    configurar(formato == "vertical")
    PAL = json.loads((mat / "palabras.json").read_text(encoding="utf-8"))
    total = info.get("cuadros") or int(_dur_video(mat / "toma-limpia.mp4") * FPS)
    fin = float(P.get("fin") or min(total / FPS, (PAL[-1]["e"] + 0.03) if PAL else total / FPS))
    NF = min(total, int(math.ceil(fin * FPS - 1e-6)))
    marca = P.get("marca") or {}
    P.update(_base=base, _mat=mat, _formato=formato,
             _salida=_ruta(base, P.get("salida")) or (mat / "edicion"),
             _avatar=_marca(base, marca.get("avatar"), "avatar.png"), _logos=_marca(base, marca.get("logos"), "logos"),
             _nombre=marca.get("nombre", "Tu Nombre"), _usuario=marca.get("usuario", "@tu_usuario"))
    P["_trabajo"] = P["_salida"] / "_trabajo"
    cargar_caras(mat / "caras.json")
    planos = sorted(P["planos"], key=lambda s: s["t0"])
    for k, sh in enumerate(planos):
        sh["t0"] = float(sh["t0"]); sh["t1"] = float(sh.get("t1", planos[k + 1]["t0"] if k + 1 < len(planos) else NF / FPS))
        sh["_seed"] = k
        sh["_fondo"] = {"tarjeta_azul": "azul", "tarjeta_oscura": "oscura"}.get(sh["tipo"], sh.get("fondo", "clara"))
        if sh["tipo"] not in ESCENAS and sh["tipo"] not in CARA + ("gancho",):
            print(f"⚠️  tipo desconocido «{sh['tipo']}» en {sh['t0']}: se dibuja como tarjeta_clara", file=sys.stderr)
    planos[-1]["t1"] = max(planos[-1]["t1"], NF / FPS + 0.01)
    P["planos"] = planos
    P["_gancho"] = None
    for sh in planos:
        sh["_beats"] = textos(sh)
        if sh["tipo"] in CARA or sh["tipo"] == "gancho":
            ajustar_cara(sh)
        if sh["tipo"] == "gancho":
            ajustar_gancho(sh)
            sh["_pill_hasta"] = float(sh.get("pildora_hasta", sh["t1"]))
            # si además lleva contexto/clave, que vaya bajo la píldora
            P["_gancho"] = dict(texto=sh.get("texto"), _pill_cx=sh["_pill_cx"], _pill_y=sh["_pill_y"],
                                _pill_hasta=sh["_pill_hasta"])
    if not quiet:
        print(f"plan: {plan_path.name} · {formato} {W}×{H} · {NF} cuadros ({NF / FPS:.2f} s) · {len(planos)} planos · "
              f"fuentes {fuentes_usadas()}")
    return P


def _marca(base, valor, nombre):
    """ruta de la marca: la del plan; si no, <plan>/marca/…; si no, la carpeta marca/ del kit."""
    for c_ in ([_ruta(base, valor)] if valor else []) + [base / "marca" / nombre, AQUI.parent / "marca" / nombre]:
        if c_ is not None and c_.exists(): return c_
    return _ruta(base, valor) if valor else None


def _dur_video(p):
    from comun import probe
    return probe(p)["duracion"]


# ══════════════════════════════════════════ lectura de la toma ══════════════════════════════════════════
def toma_reader(a, b):
    cmd = [ffmpeg(), "-v", "error", "-ss", f"{a / FPS:.4f}", "-i", str(P["_mat"] / "toma-limpia.mp4"), "-frames:v", str(b - a),
           "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE); n = W * H * 3
    last = None
    try:
        for _ in range(a, b):
            buf = p.stdout.read(n)
            if len(buf) == n:
                last = np.frombuffer(buf, np.uint8).reshape(H, W, 3).astype(np.float32) / 255
            yield last if last is not None else np.zeros((H, W, 3), np.float32)
    finally:
        p.stdout.close(); p.kill(); p.wait()


def toma_one(i):
    b = subprocess.run([ffmpeg(), "-v", "error", "-ss", f"{i / FPS:.4f}", "-i", str(P["_mat"] / "toma-limpia.mp4"), "-frames:v", "1",
                        "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True, check=True).stdout
    if len(b) < W * H * 3: return np.zeros((H, W, 3), np.float32)
    return np.frombuffer(b[:W * H * 3], np.uint8).reshape(H, W, 3).astype(np.float32) / 255


# ══════════════════════════════════════════ QA automática ══════════════════════════════════════════
def qa_cuadro(i, regs):
    """reglas: texto centrado, nada sobre la cara, texto ≥ 40 px bajo la barbilla, zona segura."""
    t = i / FPS; sh = shot_at(t); errs = []
    sf = G["safe"]
    cara = sh["tipo"] in CARA + ("gancho",)
    s = sh.get("_s", 1.0)
    if sh["tipo"] == "gancho": s = lerp(sh["_s0"], sh["_s0"] + 0.04, eio((t - sh["t0"]) / 2.0))
    ax, ay = G["anchor"]
    ch = xf(chin(i), s, ay); fbox = (xf(FX0[min(i, len(FX0) - 1)], s, ax), xf(FY0[min(i, len(FY0) - 1)], s, ay),
                                    xf(FX1[min(i, len(FX1) - 1)], s, ax), ch)
    for r in regs:
        x0, y0, x1, y1 = r["box"]; rol = r["rol"]; etq = r.get("txt", rol)
        if rol in ("grafico",):
            continue
        # zona segura
        if y0 < sf["top"] - 0.5: errs.append(f"«{etq}» invade arriba (y={y0:.0f} < {sf['top']})")
        if y1 > sf["bottom"] + 0.5: errs.append(f"«{etq}» invade abajo (y={y1:.0f} > {sf['bottom']})")
        if x0 < sf["left"] - 0.5 and rol in ("clave", "contexto", "contexto_linea", "pildora"):
            errs.append(f"«{etq}» se sale a la izquierda (x={x0:.0f})")
        b0, b1 = sf["band"]
        if x1 > sf["right"] + 0.5 and y1 > b0 and y0 < b1: errs.append(f"«{etq}» invade la derecha (x={x1:.0f} > {sf['right']})")
        # centrado (la clave y las líneas de contexto se centran en su columna)
        if rol in ("clave", "contexto_linea", "pildora") and "cx" in r:
            mid = (x0 + x1) / 2
            if abs(mid - r["cx"]) > 14: errs.append(f"«{etq}» no está centrado ({mid:.0f} vs {r['cx']:.0f})")
            if not cara and abs(r["cx"] - G["cx"]) > 1: errs.append(f"«{etq}» fuera del eje central")
        # su cara
        if cara and rol in ("clave", "contexto", "contexto_linea", "pildora", "ui"):
            if y0 < ch + 40 - 1.5: errs.append(f"«{etq}» a {y0 - ch:.0f} px de la barbilla (mín. 40)")
            if not (x1 < fbox[0] or x0 > fbox[2] or y1 < fbox[1] or y0 > fbox[3]):
                errs.append(f"«{etq}» encima de la cara")
    return errs


def zona_overlay(fr, i):
    """dibuja la zona segura (rojo), la barbilla + 40 px (verde) y la caja de la cara (amarillo)."""
    o = fr.copy(); sf = G["safe"]; red = np.array([1.0, 0.15, 0.15], np.float32)
    def tint(y0, y1, x0, x1):
        y0, y1, x0, x1 = map(lambda v: int(max(0, v)), (y0, y1, x0, x1))
        o[y0:y1, x0:x1] = o[y0:y1, x0:x1] * 0.65 + red * 0.35
    tint(0, sf["top"], 0, W); tint(sf["bottom"], H, 0, W)
    b0, b1 = sf["band"]; tint(b0, min(b1, sf["bottom"]), sf["right"], W)
    if not VERTICAL: tint(sf["top"], sf["bottom"], 0, sf["left"])
    else: tint(b0, min(b1, sf["bottom"]), 0, sf["left"])
    sh = shot_at(i / FPS)
    if sh["tipo"] in CARA + ("gancho",):
        s = sh.get("_s", 1.0)
        if sh["tipo"] == "gancho": s = lerp(sh["_s0"], sh["_s0"] + 0.04, eio((i / FPS - sh["t0"]) / 2.0))
        ax, ay = G["anchor"]; ch = xf(chin(i), s, ay)
        cv2.line(o, (0, int(ch)), (W, int(ch)), (1.0, 1.0, 0.2), 2)
        cv2.line(o, (0, int(ch + 40)), (W, int(ch + 40)), (0.2, 1.0, 0.3), 2)
        cv2.rectangle(o, (int(xf(FX0[i], s, ax)), int(xf(FY0[i], s, ay))), (int(xf(FX1[i], s, ax)), int(ch)), (1.0, 0.85, 0.1), 2)
    return o


# ══════════════════════════════════════════ render ══════════════════════════════════════════
def _guardar(path, fr):
    ok, buf = cv2.imencode(".jpg", (np.clip(fr, 0, 1)[..., ::-1] * 255 + .5).astype(np.uint8), [cv2.IMWRITE_JPEG_QUALITY, 90])
    Path(path).write_bytes(buf.tobytes())


def prueba(plan, tiempos_):
    global REG
    cargar_plan(plan)
    preparar_recursos()
    out = P["_salida"] / "prueba"; out.mkdir(parents=True, exist_ok=True)
    for ts in tiempos_:
        i = min(NF - 1, int(round(float(ts) * FPS)))
        REG = []
        fr = frame(i, toma_one(i))
        errs = qa_cuadro(i, REG); REG = None
        sh = shot_at(i / FPS)
        _guardar(out / f"{float(ts):06.2f}.jpg", fr)
        _guardar(out / f"{float(ts):06.2f}-zona.jpg", zona_overlay(fr, i))
        print(f"{float(ts):6.2f} s · {sh['tipo']:<14} · {'OK' if not errs else 'QA: ' + ' | '.join(errs)}")
    print("cuadros en", out)


def qa(plan, paso=3):
    """revisa el video entero (cada `paso` cuadros) sin codificar nada."""
    global REG
    cargar_plan(plan); preparar_recursos()
    malos = {}
    rd = toma_reader(0, NF)
    for i in range(NF):
        toma = next(rd)
        if i % paso: continue
        REG = []
        frame(i, toma)
        errs = qa_cuadro(i, REG); REG = None
        for e in errs: malos.setdefault(e, []).append(round(i / FPS, 2))
    rd.close()
    if not malos:
        print(f"QA OK · {NF} cuadros revisados (cada {paso}): textos centrados, bajo la barbilla, fuera de la cara y "
              f"dentro de la zona segura")
        return True
    print("QA con avisos:")
    for e, ts in malos.items(): print(f"  {e}  → en {ts[0]}–{ts[-1]} s ({len(ts)} cuadros)")
    return False


def hoja(plan, n=12):
    cargar_plan(plan); preparar_recursos()
    out = P["_salida"]; out.mkdir(parents=True, exist_ok=True)
    centros = [(s["t0"] + s["t1"]) / 2 + 0.25 * (s["t1"] - s["t0"]) for s in P["planos"]]
    if len(centros) > n: centros = [centros[int(k * len(centros) / n)] for k in range(n)]
    cols = 6 if VERTICAL else 3
    tw = 360 if VERTICAL else 640; th = int(tw * H / W)
    rows = math.ceil(len(centros) / cols)
    sheet = np.zeros((rows * th, cols * tw, 3), np.float32)
    for k, ts in enumerate(centros):
        i = min(NF - 1, int(round(ts * FPS)))
        fr = cv2.resize(frame(i, toma_one(i)), (tw, th), interpolation=cv2.INTER_AREA)
        cv2.putText(fr, f"{ts:.1f}s", (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (1.0, 0.95, 0.1), 3, cv2.LINE_AA)
        r, q = divmod(k, cols); sheet[r * th:(r + 1) * th, q * tw:(q + 1) * tw] = fr
    _guardar(out / "hoja.jpg", sheet)
    print("hoja:", out / "hoja.jpg")


def _trozo(plan, a, b, salida):
    """un proceso de render: cuadros [a, b) → MP4 (x264, CRF 14)."""
    cargar_plan(plan, quiet=True)
    enc = subprocess.Popen([ffmpeg(), "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS),
                            "-i", "-", "-c:v", "libx264", "-threads", "3", "-preset", "slow", "-crf", "14", "-pix_fmt", "yuv420p",
                            "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709", str(salida)],
                           stdin=subprocess.PIPE)
    rd = toma_reader(a, b)
    try:
        for i in range(a, b):
            fr = frame(i, next(rd))
            enc.stdin.write((fr * 255 + .5).astype(np.uint8).tobytes())
            if (i - a) % 60 == 0: print(f"  cuadro {i}", flush=True)
    finally:
        rd.close(); enc.stdin.close(); enc.wait()


def render(plan, procesos=None):
    """reparte el video en trozos (máx. 4 procesos en paralelo) y los une sin recodificar → <salida>/video.mp4."""
    cargar_plan(plan)
    preparar_recursos()
    n = procesos or procesos_render()
    n = max(1, min(4, n))
    ch = P["_trabajo"] / "trozos"
    if ch.exists(): shutil.rmtree(ch)
    ch.mkdir(parents=True)
    cortes = [round(k * NF / n) for k in range(n + 1)]
    print(f"render: {NF} cuadros en {n} procesos…", flush=True)
    procs = []
    try:
        for k in range(n):
            out = ch / f"c_{k:02d}.mp4"
            log = open(ch / f"log_{k}.txt", "w", encoding="utf-8")
            procs.append((subprocess.Popen([sys.executable, str(Path(__file__).resolve()), "_trozo", str(Path(plan).resolve()),
                                            str(cortes[k]), str(cortes[k + 1]), str(out)], stdout=log, stderr=subprocess.STDOUT), log, out))
        fallos = []
        for p, log, out in procs:
            p.wait(); log.close()
            if p.returncode != 0: fallos.append(out.name)
        if fallos:
            raise RuntimeError(f"falló el render de {fallos}; mira {ch}/log_*.txt")
    finally:
        for p, log, _ in procs:                     # nunca dejar procesos huérfanos
            if p.poll() is None: p.kill(); p.wait()
            if not log.closed: log.close()
    lista = ch / "lista.txt"
    esc = lambda p: p.as_posix().replace("'", "'\\''")          # comillas simples en la ruta (concat de ffmpeg)
    lista.write_text("".join(f"file '{esc(ch / f'c_{k:02d}.mp4')}'\n" for k in range(n)), encoding="utf-8")
    dst = P["_salida"] / "video.mp4"; dst.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([ffmpeg(), "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(lista), "-c", "copy", str(dst)], check=True)
    shutil.rmtree(ch, ignore_errors=True)            # los trozos ya están unidos
    print("video (sin audio):", dst)
    return dst


def info_plan(plan):
    cargar_plan(plan)
    for s in P["planos"]:
        extra = ""
        if s["tipo"] in CARA + ("gancho",):
            extra = f"s={s['_s']:.2f} barbilla={s['_chin']:.0f} clave={[L.get('bsize') for L in s['_lay']]}"
            if s["tipo"] == "gancho": extra += f" píldora y={s['_pill_y']} zoom {s['_s0']:.2f}→{s['_s0'] + 0.04:.2f}"
        txt = " / ".join(" ".join(w for w, _ in b[0]) + (" · " + b[1][0] if b[1] else "") for b in s["_beats"])
        print(f"{s['t0']:6.2f}–{s['t1']:6.2f}  {s['tipo']:<15} {extra}  {txt}")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    cmd, plan = sys.argv[1], sys.argv[2]
    if cmd == "render":
        np_ = None
        if "--procesos" in sys.argv: np_ = int(sys.argv[sys.argv.index("--procesos") + 1])
        render(plan, np_)
    elif cmd == "prueba": prueba(plan, sys.argv[3:])
    elif cmd == "qa": sys.exit(0 if qa(plan) else 1)
    elif cmd == "hoja": hoja(plan)
    elif cmd == "info": info_plan(plan)
    elif cmd == "_trozo": _trozo(plan, int(sys.argv[3]), int(sys.argv[4]), sys.argv[5])
    else: raise SystemExit(__doc__)
