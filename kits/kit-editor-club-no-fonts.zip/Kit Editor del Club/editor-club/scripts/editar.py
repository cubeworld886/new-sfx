"""editar — de punta a punta: carpeta preparada + plan.json → final.mp4 en estilo «Club de Monetización».

    python editar.py <carpeta_preparada> <plan.json> [--musica cancion.mp3] [--musica-db 15] [--inicio-musica 2]
                     [--procesos 4] [--salida final.mp4] [--sin-qa]

1. QA rápida del plan (cada 6 cuadros): textos centrados, bajo la barbilla, fuera de la cara, dentro de la zona segura.
2. motor_club: dibuja el video en trozos paralelos (máx. 4 procesos) → video.mp4 sin audio.
3. mezcla: voz-limpia.wav + música opcional a −15 dB bajo la voz (ducking) + whooshes sintetizados en los cortes
   a tarjeta que caen en un hueco de voz (o los tiempos que pongas en "whooshes" del plan).
4. master: −11 LUFS, pico ≤ −1 dBTP medido DESPUÉS del AAC 320k → final.mp4 (dura lo mismo que su voz, sin outro).
La carpeta que pasas manda sobre "material" del plan. Música: "musica" del plan o --musica (solo con derechos de uso).
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import motor_club as M  # noqa: E402
from master import masterizar  # noqa: E402
from mezcla import mezclar  # noqa: E402

CARAS = ("cara", "cierre", "gancho")


def whooshes_auto(planos):
    """candidatos: cada cambio cara ↔ gráfico. mezcla.py mete cada uno en el hueco REAL de voz más cercano, descarta
    los que caerían encima de una palabra y deja ≥ 2 s entre uno y otro (máx. 6: sutiles, no en cada corte)."""
    return [round(b["t0"], 3) for a, b in zip(planos, planos[1:]) if (a["tipo"] in CARAS) != (b["tipo"] in CARAS)]


def main():
    ap = argparse.ArgumentParser(description="carpeta preparada + plan.json → final.mp4")
    ap.add_argument("carpeta"); ap.add_argument("plan")
    ap.add_argument("--musica"); ap.add_argument("--musica-db", type=float); ap.add_argument("--inicio-musica", type=float)
    ap.add_argument("--procesos", type=int); ap.add_argument("--salida"); ap.add_argument("--sin-qa", action="store_true")
    a = ap.parse_args()
    t_ini = time.time()
    plan_path = Path(a.plan).resolve(); mat = Path(a.carpeta).resolve()
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    base = Path(plan["base"]) if plan.get("base") else plan_path.parent
    plan["base"] = str(base)
    plan["material"] = str(mat)
    if not plan.get("salida"): plan["salida"] = str(mat / "edicion")
    salida_dir = M._ruta(base, plan["salida"]); trabajo = salida_dir / "_trabajo"; trabajo.mkdir(parents=True, exist_ok=True)
    efectivo = trabajo / "plan-efectivo.json"
    efectivo.write_text(json.dumps(plan, ensure_ascii=False, indent=1), encoding="utf-8")

    if not a.sin_qa:
        print("── QA del plan ──")
        M.qa(str(efectivo), paso=6)
    print("── render ──")
    video = M.render(str(efectivo), a.procesos)
    P = M.cargar_plan(str(efectivo), quiet=True)
    dur = M.NF / M.FPS
    pal = M.PAL

    print("── mezcla ──")
    wh = plan.get("whooshes", "auto")
    wh = whooshes_auto(P["planos"]) if wh in ("auto", None) else [float(x) for x in wh]
    musica = str(Path(a.musica).resolve()) if a.musica else (str(M._ruta(base, plan["musica"])) if plan.get("musica") else None)
    mez = trabajo / "mezcla.wav"
    info = mezclar(mat / "voz-limpia.wav", musica or "-", mez,
                   a.musica_db if a.musica_db is not None else float(plan.get("musica_db", 15)),
                   a.inicio_musica if a.inicio_musica is not None else float(plan.get("inicio_musica", 2)),
                   wh, pal, dur)

    print("── master ──")
    final = Path(a.salida).resolve() if a.salida else salida_dir / "final.mp4"
    lu, pk = masterizar(video, mez, final, duracion=dur)
    print(f"\nLISTO: {final}\n  duración {dur:.3f} s ({M.NF} cuadros, termina con su voz) · {lu} LUFS · pico real {pk} dBTP"
          f" · whooshes {info.get('efectos')} · {time.time() - t_ini:.0f} s")


if __name__ == "__main__":
    main()
