"""voz_pro — voz a nivel profesional, sincronizada cuadro a cuadro con la toma limpia.

Uso como módulo (lo llama preparar_toma.py):
    import voz_pro
    voz_pro.procesar("voz-cruda.wav", tramos, "voz-limpia.wav")

Uso suelto (rehace voz-limpia.wav de una carpeta ya preparada):
    python voz_pro.py <carpeta_preparada>        # usa voz-cruda.wav + tramos.json

Cadena (todo local, sin APIs):
  1. Pasa-altos 70 Hz (golpes, aire acondicionado, retumbe).
  2. DeepFilterNet 3 (IA): quita ruido de fondo y reverberación, con tope de 28 dB para que la voz siga natural.
     (Si DeepFilterNet no está instalado, usa el reductor de ruido de ffmpeg y lo avisa.)
  3. EQ de locutor: +1.5 dB en 120 Hz (cuerpo), −3 dB en 250 Hz (lodo), −1.5 dB en 600 Hz (caja),
     +3.5 dB en 3.5 kHz (presencia), estante +3 dB desde 9 kHz (aire).
  4. De-esser.
  5. Compresión en dos etapas: lenta (nivela frases) + rápida (densidad, «voz de radio»).
  6. Normalizada a −16 LUFS, pico ≤ −1.5 dBTP (el master final la sube a −11 LUFS).
  7. Corte: cada tramo dura EXACTAMENTE lo que sus cuadros de video a 30 fps, con fundidos de 12 ms → la voz no se
     despega de los labios aunque haya 80 cortes.
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

import numpy as np
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parent))
from comun import ffmpeg, run  # noqa: E402

FPS = 30
FADE = 0.012
CADENA_EQ = (
    "equalizer=f=120:t=q:w=0.9:g=1.5,"
    "equalizer=f=250:t=q:w=1.1:g=-3,"
    "equalizer=f=600:t=q:w=1.4:g=-1.5,"
    "equalizer=f=3500:t=q:w=1.0:g=3.5,"
    "highshelf=f=9000:g=3,"
    "deesser=i=0.45:m=0.5:f=0.5,"
    "acompressor=threshold=-26dB:ratio=2.5:attack=25:release=250:makeup=2dB,"   # nivelador lento
    "acompressor=threshold=-18dB:ratio=4:attack=3:release=60:makeup=3dB,"        # densidad
    "alimiter=limit=0.89:attack=2:release=40,"
    "loudnorm=I=-16:TP=-1.5:LRA=6"
)
# respaldo si DeepFilterNet no está: reductor FFT de ffmpeg, suave
RESPALDO_RUIDO = "afftdn=nf=-50:nr=10:tn=1"


def denoise(src, dst) -> bool:
    """DeepFilterNet 3 a 48 kHz sobre todo el audio crudo (más contexto = mejor limpieza). True si se usó."""
    try:
        import warnings
        warnings.filterwarnings("ignore")
        import torch
        from df.enhance import enhance, init_df
    except Exception as e:  # noqa: BLE001
        print(f"⚠️  DeepFilterNet no disponible ({e.__class__.__name__}): uso el reductor de ffmpeg. "
              "Revisa INSTALAR.md (torch 2.1.2 + deepfilternet 0.5.6).")
        run([ffmpeg(), "-v", "error", "-y", "-i", str(src), "-af", RESPALDO_RUIDO, "-c:a", "pcm_s24le", str(dst)])
        return False
    model, state, _ = init_df(log_level="ERROR", log_file=None)
    x, sr = sf.read(str(src), dtype="float32", always_2d=True)
    x = x.mean(1)
    assert sr == state.sr(), f"se esperaba {state.sr()} Hz, llegó {sr}"
    out = []
    paso = sr * 60                                   # por minutos para no llenar la RAM
    with torch.no_grad():
        for i in range(0, len(x), paso):
            trozo = torch.from_numpy(x[i:i + paso + sr // 2].copy())[None]
            y = enhance(model, state, trozo, atten_lim_db=28).squeeze(0).numpy()
            out.append(y[: min(paso, len(x) - i)])
    sf.write(str(dst), np.concatenate(out), sr, subtype="PCM_24")
    return True


def cuadros(s: float, e: float, fps: int = FPS) -> int:
    """Cuadros de video que da trim=s:e a `fps` (los de pts en [s, e))."""
    return int(np.ceil(e * fps - 1e-6)) - int(np.ceil(s * fps - 1e-6))


def cortar(x: np.ndarray, sr: int, tramos, fps: int = FPS) -> np.ndarray:
    """Igual que el concat de video: cada tramo dura lo que sus cuadros (relleno con silencio o recorte de < 1 cuadro)."""
    fade = int(FADE * sr)
    partes = []
    for s, e in tramos:
        seg = x[int(round(s * sr)):int(round(e * sr))].copy()
        if len(seg) > 2 * fade:
            seg[:fade] *= np.linspace(0, 1, fade, dtype=seg.dtype)
            seg[-fade:] *= np.linspace(1, 0, fade, dtype=seg.dtype)
        L = int(round(cuadros(s, e, fps) / fps * sr))
        seg = np.pad(seg, (0, max(0, L - len(seg))))[:L]
        partes.append(seg)
    return np.concatenate(partes) if partes else np.zeros(0, np.float32)


def procesar(voz_cruda, tramos, salida, fps: int = FPS) -> dict:
    """voz-cruda.wav (48 kHz) + tramos [(s, e)] del original → voz-limpia.wav sincronizada con la toma limpia."""
    salida = Path(salida)
    with tempfile.TemporaryDirectory(prefix="voz_pro_") as tmp:
        tmp = Path(tmp)
        run([ffmpeg(), "-v", "error", "-y", "-i", str(voz_cruda), "-af", "highpass=f=70", "-ac", "1", "-ar", "48000",
             "-c:a", "pcm_s24le", str(tmp / "voz-hp.wav")])
        ia = denoise(tmp / "voz-hp.wav", tmp / "voz-dfn.wav")
        run([ffmpeg(), "-v", "error", "-y", "-i", str(tmp / "voz-dfn.wav"), "-af", CADENA_EQ, "-ar", "48000",
             "-c:a", "pcm_s24le", str(tmp / "voz-eq.wav")])
        x, sr = sf.read(str(tmp / "voz-eq.wav"), dtype="float32")
    if x.ndim > 1:
        x = x.mean(1)
    y = cortar(x, sr, tramos, fps)
    sf.write(str(salida), y, sr, subtype="PCM_24")
    esperado = sum(cuadros(s, e, fps) for s, e in tramos) / fps
    info = {"deepfilternet": ia, "duracion": round(len(y) / sr, 3), "duracion_video": round(esperado, 3)}
    print(f"voz pro lista: {info['duracion']} s (video {info['duracion_video']} s) · "
          f"{'DeepFilterNet' if ia else 'reductor ffmpeg'}")
    return info


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    mat = Path(sys.argv[1]).resolve()
    tr = json.loads((mat / "tramos.json").read_text(encoding="utf-8"))
    procesar(mat / "voz-cruda.wav", tr, mat / "voz-limpia.wav")
