"""preparar_toma — deja lista una toma a cámara para editarla en el estilo «Club de Monetización».

    python preparar_toma.py <video> <carpeta_salida> [--horizontal] [--idioma es] [--whisper auto|mlx|faster]

Todo local y gratis (sin APIs de pago). En orden:
  1. Transcribe con marcas por palabra → palabras-original.json  [{w, s, e}]
     · Mac con chip Apple: mlx-whisper (large-v3-turbo, en la GPU).
     · Mac Intel / Windows: faster-whisper (large-v3-turbo; CUDA si hay tarjeta NVIDIA, si no CPU int8).
  2. Detecta y quita: muletillas («eh», «mmm»…), repeticiones inmediatas, trabadas, tomas fallidas y señales habladas
     («corta», «otra vez»…) + TODOS los silencios y respiraciones (corte apretado por energía del audio).
     Imprime cada corte para que la IA del alumno lo revise. Ajustes por variables de entorno:
        QUITAR="12.4-13.1,20-21.5"   tramos del ORIGINAL a eliminar (falsos arranques que el detector no vio)
        INICIO=1.2  FIN=38.5         descarta todo antes / después (en segundos del original)
        SIN_GRUPOS=1                 no quita muletillas/repeticiones (solo silencios y respiraciones)
  3. Video: HDR de iPhone (HLG/PQ) → SDR con tonemap; escala y recorta a 1080×1920 (o 1920×1080 con --horizontal),
     30 fps. SIN filtros de piel (se ven de baja calidad).
  4. Voz pro (voz_pro.py): DeepFilterNet + EQ de locutor + de-esser + compresión en 2 etapas + −16 LUFS, cortada
     cuadro a cuadro para que no se despegue de los labios.
  5. Monta toma-limpia.mp4 (video + voz pro) y voz-limpia.wav; remapea palabras.json y caras.json al tiempo de la
     toma limpia; jumpcuts.json con cada salto.
  6. Caras cuadro a cuadro (cada 2 cuadros + relleno): mediapipe → OpenCV YuNet → OpenCV Haar. La caja sirve para
     saber dónde está la BARBILLA (los subtítulos van siempre debajo).

Salida en <carpeta_salida>: toma-limpia.mp4, voz-limpia.wav, palabras.json, caras.json, jumpcuts.json, cortes.json,
tramos.json, palabras-original.json, info.json (+ audio16k.wav y voz-cruda.wav de trabajo).
"""
from __future__ import annotations

import argparse
import json
import math
import os
import platform
import re
import subprocess
import sys
import unicodedata
import wave
from difflib import SequenceMatcher
from pathlib import Path

import numpy as np

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
from comun import ffmpeg, probe, run  # noqa: E402
import voz_pro  # noqa: E402

FPS = 30

# ═══════════════════════════════ 1. Transcripción ═══════════════════════════════
# El prompt con muletillas hace que Whisper las transcriba en vez de «limpiarlas» (así se pueden cortar).
PROMPT_WHISPER = "Eh... este, mmm, bueno. Vamos a ver, vamos a ver cómo, eh, cómo lo hacemos. Em, no, perdón."
MLX_MODEL = "mlx-community/whisper-large-v3-turbo"
FW_MODEL = "large-v3-turbo"


def cargar_16k(wav: Path) -> np.ndarray:
    with wave.open(str(wav), "rb") as f:
        return np.frombuffer(f.readframes(f.getnframes()), dtype=np.int16).astype(np.float32) / 32768


def motor_whisper(pedido: str) -> str:
    if pedido in ("mlx", "faster"):
        return pedido
    if sys.platform == "darwin" and platform.machine() == "arm64":
        try:
            import mlx_whisper  # noqa: F401
            return "mlx"
        except Exception:
            pass
    return "faster"


def transcribir(wav: Path, idioma: str = "es", motor: str = "auto") -> list[dict]:
    audio = cargar_16k(wav)                     # se pasa el audio ya cargado: no depende de un `ffmpeg` en el PATH
    prompt = PROMPT_WHISPER if idioma == "es" else None
    motor = motor_whisper(motor)
    palabras = []
    if motor == "mlx":
        import mlx_whisper
        print("transcribiendo con mlx-whisper (GPU de Apple)…", flush=True)
        res = mlx_whisper.transcribe(audio, path_or_hf_repo=MLX_MODEL, word_timestamps=True, language=idioma,
                                     condition_on_previous_text=False, initial_prompt=prompt, verbose=None,
                                     hallucination_silence_threshold=2.0)
        for seg in res.get("segments", []):
            for w in seg.get("words") or []:
                t = (w.get("word") or "").strip()
                if t:
                    palabras.append({"w": t, "s": round(float(w["start"]), 3), "e": round(float(w["end"]), 3)})
    else:
        from faster_whisper import WhisperModel
        dev, ct = "cpu", "int8"
        try:
            import ctranslate2
            if ctranslate2.get_cuda_device_count() > 0:
                dev, ct = "cuda", "float16"
        except Exception:
            pass
        print(f"transcribiendo con faster-whisper ({FW_MODEL}, {dev} {ct})… la primera vez baja el modelo (~1.6 GB)", flush=True)
        model = WhisperModel(FW_MODEL, device=dev, compute_type=ct, cpu_threads=max(1, (os.cpu_count() or 4) - 1))
        segs, _ = model.transcribe(audio, language=idioma, word_timestamps=True, condition_on_previous_text=False,
                                   initial_prompt=prompt, beam_size=5, vad_filter=False,
                                   hallucination_silence_threshold=2.0)
        for seg in segs:
            for w in seg.words or []:
                t = (w.word or "").strip()
                if t:
                    palabras.append({"w": t, "s": round(float(w.start), 3), "e": round(float(w.end), 3)})
    return palabras


# ═══════════════════════════════ 2. Detección (muletillas, repeticiones, trabadas, tomas fallidas) ═══════════════════
MULETILLAS = {"eh", "ehh", "ehhh", "ehm", "em", "emm", "mm", "mmm", "mmmm", "hmm", "mmh", "ah", "ahh", "am", "amm", "eeh", "eem",
              "aja", "aha", "uh", "uhm", "um", "hm", "ehhm"}
FUNCIONALES = {"el", "la", "los", "las", "de", "del", "que", "en", "y", "a", "al", "un", "una", "lo", "se", "es",
               "con", "por", "para", "mi", "tu", "te", "me", "su", "le", "les", "o", "yo", "como", "pero", "porque"}
SENALES = re.compile(r"\b(corta|corten|cortale|otra vez|de nuevo|va de nuevo|lo repito|repito|me equivoque|me trabe|"
                     r"me trabo|mal dicho|a ver otra|desde el principio)\b")
FRASE_GAP = 0.5                       # pausa que separa frases


def norm(t: str) -> str:
    t = unicodedata.normalize("NFD", t.lower())
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9ñ]+", "", t)


def frases(palabras: list[dict]) -> list[list[int]]:
    out, cur = [], []
    for i, w in enumerate(palabras):
        cur.append(i)
        gap = palabras[i + 1]["s"] - w["e"] if i + 1 < len(palabras) else 99
        if re.search(r"[.!?…]$", w["w"]) or gap >= FRASE_GAP:
            out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return out


def detectar(palabras: list[dict]) -> list[dict]:
    """Grupos de palabras a quitar: [{id, tipo, i0, i1, motivo, s, e, texto}] (i1 inclusivo)."""
    n = len(palabras)
    N = [norm(w["w"]) for w in palabras]
    marca: list = [None] * n

    def quitar(a: int, b: int, tipo: str, motivo: str) -> None:
        for k in range(a, b + 1):
            if marca[k] is None:
                marca[k] = (tipo, motivo)

    # 1) Muletillas sueltas (eh, mmm…) y «este…» con puntos suspensivos
    for i, t in enumerate(N):
        if "?" in palabras[i]["w"] or "¿" in palabras[i]["w"]:
            continue                              # «¿eh, Marco?» es una pregunta, no una muletilla
        if t in MULETILLAS or (t == "este" and palabras[i]["w"].endswith(("...", "…"))):
            quitar(i, i, "muletilla", f"Muletilla «{palabras[i]['w'].strip('.,…')}»")

    # 2) Repeticiones inmediatas y reinicios dentro de la frase: «vamos a ver cómo, vamos a ver cómo…»
    i = 0
    while i < n:
        hecho = False
        for L in range(6, 0, -1):
            if len(set(N[i:i + L])) == 1 and L > 1:
                continue                          # «tan, tan, tan»: onomatopeya o énfasis
            for k in (0, 1):                      # hasta 1 media palabra entre las copias («vamos a mo-, vamos a…»)
                if L == 1 and k > 0:
                    continue
                j = i + L + k
                if j + L > n or N[i:i + L] != N[j:j + L] or not all(N[i:i + L]):
                    continue
                if palabras[j]["s"] - palabras[i + L - 1]["e"] > 1.5:
                    continue
                if k and (len(N[i + L]) > 3 or N[i + L] in {"y", "o", "e", "u", "ni", "que"}
                          or re.search(r"[.,;!?]$", palabras[i + L]["w"])):
                    continue                      # entre copias solo cabe media palabra
                if L == 1 and N[i] not in FUNCIONALES:
                    continue                      # «no no no», «muy muy» pueden ser énfasis
                texto = " ".join(p["w"] for p in palabras[i:j])
                quitar(i, j - 1, "trabada" if k else "repeticion",
                       ("Se trabó y repitió: " if k else "Repetido: ") + f"«{texto}»")
                i = j
                hecho = True
                break
            if hecho:
                break
        if not hecho:
            i += 1

    # 3) Tomas fallidas entre frases: la frase (o su final) se vuelve a decir justo después
    F = frases(palabras)
    for a in range(len(F)):
        A = F[a]
        cerrada = bool(re.search(r"[.!?…]$", palabras[A[-1]]["w"]))
        for b in range(a + 1, min(a + 3, len(F))):
            B = F[b]
            if palabras[B[0]]["s"] - palabras[A[-1]]["e"] > 12:
                break
            if b == a + 2 and len(F[a + 1]) > 4:
                break                             # entre medias solo cabe un «perdón» / «a ver», no una frase buena
            nb = [N[k] for k in B]
            corte = None
            for p in range(len(A)):
                if cerrada and p > 0:
                    break                         # frase terminada que repite su final al inicio de la otra: es retórica
                suf = [N[k] for k in A[p:]]
                if len(suf) >= 2:
                    if suf[:2] != nb[:2] or len(nb) < len(suf):
                        continue
                    ult = nb[len(suf) - 1]
                    prefijo = suf[:-1] == nb[:len(suf) - 1] and ult.startswith(suf[-1])
                    abierta = not re.search(r"[.,;!?…]$", palabras[A[-1]]["w"])
                    parecida = len(suf) >= 4 and SequenceMatcher(None, suf, nb[:len(suf)]).ratio() >= 0.85
                    if prefijo or (abierta and parecida):
                        corte = p
                        break
                elif len(A) == 1 and suf[0] and suf[0] == nb[0] and len(B) > 1:
                    corte = p                     # arranque en falso: «Hoy… Hoy te voy a enseñar»
                    break
            if corte is not None:
                fin = B[0] - 1                    # también lo que haya entre medias («perdón», «a ver»)
                quitar(A[corte], fin, "toma", "Toma fallida, la repites después: «"
                       + " ".join(palabras[k]["w"] for k in range(A[corte], fin + 1)) + "»")
                break

    # 4) Señales habladas: «corta», «otra vez», «me equivoqué»… → fuera esa frase y la anterior
    for a, A in enumerate(F):
        texto = " ".join(N[k] for k in A)
        if len(A) <= 12 and SENALES.search(texto):
            ini = F[a - 1][0] if a > 0 and palabras[A[0]]["s"] - palabras[F[a - 1][-1]]["e"] < 6 else A[0]
            quitar(ini, A[-1], "senal", "Dijiste «" + " ".join(palabras[k]["w"] for k in A) + "»: se quita esa toma")
        elif len(A) <= 3 and re.fullmatch(r"(no )?perdon( perdon)?", texto.strip()):
            quitar(A[0], A[-1], "senal", "«Perdón» de corrección")

    return agrupar(palabras, marca)


def agrupar(palabras: list[dict], marca: list) -> list[dict]:
    grupos, i, n = [], 0, len(palabras)
    while i < n:
        if marca[i] is None:
            i += 1
            continue
        j = i
        while j + 1 < n and marca[j + 1] == marca[i]:
            j += 1
        tipo, motivo = marca[i]
        grupos.append({"id": f"c{len(grupos)}", "tipo": tipo, "i0": i, "i1": j, "motivo": motivo,
                       "s": palabras[i]["s"], "e": palabras[j]["e"],
                       "texto": " ".join(p["w"] for p in palabras[i:j + 1])})
        i = j + 1
    return grupos


# ═══════════════════════════════ 2b. Corte apretado: cero silencios y cero respiraciones ═══════════════════════════════
# Decide por energía del audio (no por los tiempos de Whisper, que se desfasan ~0.1 s):
# voz sonora = energía total > UMBRAL_VOZ y energía en 100–900 Hz alta (las respiraciones casi no tienen graves);
# cada tramo se extiende mientras la energía siga arriba de UMBRAL_CONSONANTE (no se muerden «s», «f», «t»).
UMBRAL_VOZ = -32.0          # dBFS (rms 10 ms) para voz sonora
UMBRAL_GRAVES = 8.0         # dB en 100–900 Hz (escala relativa del análisis)
UMBRAL_CONSONANTE = -36.0   # mientras la energía siga arriba de esto, sigue siendo palabra
PRE, POST = 0.035, 0.06     # margen antes/después de cada tramo (s)
UNIR = 0.09                 # huecos menores a esto no se cortan
MIN_TRAMO = 0.08


def analizar(path):
    w = wave.open(str(path)); sr = w.getframerate()
    y = np.frombuffer(w.readframes(w.getnframes()), np.int16) / 32768
    hop, win = sr // 100, 512
    n = len(y) // hop
    full = np.zeros(n); low = np.zeros(n)
    f = np.fft.rfftfreq(win, 1 / sr); banda = (f > 100) & (f < 900); han = np.hanning(win)
    for i in range(n):
        a = y[i * hop:i * hop + hop]
        full[i] = 20 * np.log10(np.sqrt((a ** 2).mean()) + 1e-9)
        b = y[i * hop:i * hop + win]
        if len(b) == win:
            low[i] = 10 * np.log10((np.abs(np.fft.rfft(b * han)) ** 2)[banda].sum() + 1e-12)
    return full, low, n / 100


def tramos_apretados(full, low, dur):
    voz = (full > UMBRAL_VOZ) & (low > UMBRAL_GRAVES)
    segs, i, n = [], 0, len(voz)
    while i < n:
        if voz[i]:
            j = i
            while j < n and voz[j]: j += 1
            a, b = i, j
            while a > 0 and full[a - 1] > UMBRAL_CONSONANTE: a -= 1
            while b < n and full[b] > UMBRAL_CONSONANTE: b += 1
            segs.append([max(0, a / 100 - PRE), min(dur, b / 100 + POST)])
            i = j
        else:
            i += 1
    out = []
    for s, e in segs:
        if out and s - out[-1][1] < UNIR: out[-1][1] = max(out[-1][1], e)
        else: out.append([s, e])
    return [(round(s, 3), round(e, 3)) for s, e in out if e - s >= MIN_TRAMO]


def restar(tr, a, b, margen=0.0):
    """Quita [a, b] de la lista de tramos (si lo que sobra de un lado es < margen, se descarta)."""
    nuevo = []
    for s, e in tr:
        if b <= s or a >= e:
            nuevo.append((s, e)); continue
        if a - s > margen: nuevo.append((s, a))
        if e - b > margen: nuevo.append((b, e))
    return nuevo


def cuantizar(tr, fps=FPS):
    """Lleva cada tramo a bordes de cuadro (inicio hacia atrás, fin hacia adelante): video y voz cortan en el MISMO
    instante, así no hay deriva entre labios y voz aunque haya muchos cortes."""
    out = []
    for s, e in tr:
        a = math.floor(s * fps + 1e-6) / fps
        b = math.ceil(e * fps - 1e-6) / fps
        if out and a <= out[-1][1] + 1e-6:
            out[-1] = (out[-1][0], max(out[-1][1], b))
        elif b - a >= 2 / fps:
            out.append((a, b))
    return [(round(s, 4), round(e, 4)) for s, e in out]


# ═══════════════════════════════ 6. Caras ═══════════════════════════════
class DetectorCaras:
    """Caja de la cara (normalizada, origen arriba-izquierda) de la cara más grande. La base de la caja ≈ barbilla."""

    def __init__(self):
        self.nombre = None
        self._mesh = self._fd = self._yn = self._haar = None
        try:
            if os.environ.get("KIT_CARAS") == "opencv":
                raise ImportError("KIT_CARAS=opencv")
            import mediapipe as mp
            self._mesh = mp.solutions.face_mesh.FaceMesh(static_image_mode=False, max_num_faces=2,
                                                         refine_landmarks=False, min_detection_confidence=0.5,
                                                         min_tracking_confidence=0.5)
            self._fd = mp.solutions.face_detection.FaceDetection(model_selection=1, min_detection_confidence=0.5)
            self.nombre = "mediapipe-facemesh"
            return
        except Exception as e:  # noqa: BLE001
            print(f"⚠️  mediapipe no disponible ({e.__class__.__name__}): uso OpenCV")
        import cv2
        yunet = AQUI / "modelos" / "face_detection_yunet_2023mar.onnx"
        if yunet.exists() and hasattr(cv2, "FaceDetectorYN"):
            self._yn = cv2.FaceDetectorYN.create(str(yunet), "", (320, 320), 0.6)
            self.nombre = "opencv-yunet"
        else:
            self._haar = cv2.CascadeClassifier(str(Path(cv2.data.haarcascades) / "haarcascade_frontalface_default.xml"))
            self.nombre = "opencv-haar"

    def __call__(self, rgb: np.ndarray):
        h, w = rgb.shape[:2]
        if self._mesh is not None:
            r = self._mesh.process(rgb)
            if r.multi_face_landmarks:
                best = None
                for lm in r.multi_face_landmarks:
                    xs = [p.x for p in lm.landmark]; ys = [p.y for p in lm.landmark]
                    box = (min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys))
                    if best is None or box[2] > best[2]: best = box
                return best
            r = self._fd.process(rgb)
            if r.detections:
                d = max(r.detections, key=lambda d: d.location_data.relative_bounding_box.width)
                b = d.location_data.relative_bounding_box
                return (b.xmin, b.ymin, b.width, b.height * 1.05)
            return None
        import cv2
        if self._yn is not None:
            self._yn.setInputSize((w, h))
            _, f = self._yn.detect(cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
            if f is None or len(f) == 0: return None
            x, y, bw, bh = max(f, key=lambda r: r[2])[:4]
            return (x / w, y / h, bw / w, bh * 1.05 / h)
        g = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        f = self._haar.detectMultiScale(g, 1.1, 6, minSize=(w // 8, w // 8))
        if len(f) == 0: return None
        x, y, bw, bh = max(f, key=lambda r: r[2])
        return (x / w, y / h, bw / w, bh * 1.12 / h)       # Haar corta arriba del mentón: se alarga 12 %


def detectar_caras(video: Path, W: int, H: int, paso: int = 2) -> dict:
    det = DetectorCaras()
    w2, h2 = W // 2, H // 2                                 # a media resolución (coordenadas normalizadas igual)
    p = subprocess.Popen([ffmpeg(), "-v", "error", "-i", str(video), "-vf", f"scale={w2}:{h2}", "-f", "rawvideo",
                          "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE)
    n = w2 * h2 * 3
    crudos, k = [], 0
    try:
        while True:
            b = p.stdout.read(n)
            if len(b) < n: break
            if k % paso == 0:
                crudos.append(det(np.frombuffer(b, np.uint8).reshape(h2, w2, 3)))
            else:
                crudos.append("relleno")
            k += 1
    finally:
        p.stdout.close(); p.kill(); p.wait()
    # suavizado como el original (0.6 anterior + 0.4 nueva) y relleno de los cuadros salteados (interpolación)
    suav, prev = [], None
    for c in crudos:
        if c is None or c == "relleno":
            suav.append(c); continue
        if prev is not None:
            c = tuple(0.6 * a + 0.4 * b for a, b in zip(prev, c))
        prev = c; suav.append(c)
    caras = []
    for i, c in enumerate(suav):
        if c == "relleno":
            a = suav[i - 1] if i > 0 else None
            b = suav[i + 1] if i + 1 < len(suav) else None
            a = a if isinstance(a, tuple) else None; b = b if isinstance(b, tuple) else None
            c = tuple((x + y) / 2 for x, y in zip(a, b)) if a and b else (a or b)
        t = round(i / FPS, 3)
        caras.append([t] + ([round(float(v), 4) for v in c] if c else [-1, -1, -1, -1]))
    con = sum(1 for c in caras if c[1] >= 0)
    print(f"caras: {con}/{len(caras)} cuadros con cara ({det.nombre})")
    return {"fps": float(FPS), "w": W, "h": H, "detector": det.nombre,
            "nota": "[t, x, y, w, h] normalizados, origen arriba-izquierda; -1 = sin cara; (y + h)·alto ≈ barbilla",
            "caras": caras}


# ═══════════════════════════════ principal ═══════════════════════════════
def tonemap_vf(hdr: bool) -> str:
    # mismo filtro del original: HLG/PQ → lineal → bt709 con tonemap «hable» sin desaturar
    return ("zscale=t=linear:npl=203,format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,"
            "zscale=t=bt709:m=bt709:r=tv,") if hdr else ""


def main():
    ap = argparse.ArgumentParser(description="Prepara una toma a cámara (corte limpio + voz pro + caras + palabras).")
    ap.add_argument("video"); ap.add_argument("salida")
    ap.add_argument("--horizontal", action="store_true", help="1920×1080 en vez de 1080×1920")
    ap.add_argument("--idioma", default="es")
    ap.add_argument("--whisper", default="auto", choices=["auto", "mlx", "faster"])
    ap.add_argument("--crf", type=int, default=15, help="calidad del video intermedio (menor = mejor)")
    a = ap.parse_args()

    src = Path(a.video).resolve(); out = Path(a.salida).resolve(); out.mkdir(parents=True, exist_ok=True)
    W, H = (1920, 1080) if a.horizontal else (1080, 1920)
    FF = ffmpeg()
    info = probe(src)
    if not info["video"] or not info["audio"]:
        raise SystemExit("El video necesita imagen y audio.")
    dur = info["duracion"]
    print(f"original: {info['ancho']}×{info['alto']} · {info['fps']:.2f} fps · {dur:.2f} s · {'HDR' if info['hdr'] else 'SDR'}")

    # 1. palabras
    a16 = out / "audio16k.wav"
    run([FF, "-y", "-v", "error", "-i", str(src), "-map", "0:a:0", "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(a16)])
    po = out / "palabras-original.json"
    if not po.exists():
        pal = transcribir(a16, a.idioma, a.whisper)
        po.write_text(json.dumps(pal, ensure_ascii=False), encoding="utf-8")
    pal = json.loads(po.read_text(encoding="utf-8"))
    print(f"{len(pal)} palabras transcritas")

    # 2. cortes
    grupos = [] if os.environ.get("SIN_GRUPOS") == "1" else detectar(pal)
    (out / "cortes.json").write_text(json.dumps(grupos, ensure_ascii=False, indent=1), encoding="utf-8")
    full, low, _ = analizar(a16)
    tr = tramos_apretados(full, low, dur)
    for g in grupos:                                         # además: muletillas, trabadas y tomas fallidas
        tr = restar(tr, g["s"], g["e"], 0.08)
    ini_m, fin_m = float(os.environ.get("INICIO", 0)), float(os.environ.get("FIN", 1e9))
    tr = [(max(s, ini_m), min(e, fin_m)) for s, e in tr if e > ini_m and s < fin_m]
    for q in filter(None, os.environ.get("QUITAR", "").replace(" ", "").split(",")):
        qa, qb = map(float, q.split("-"))
        tr = restar(tr, qa, qb)
    tr = [(s, e) for s, e in tr if e - s >= 0.08]
    # restos: pedacitos de voz que quedan entre dos cortes sin ninguna palabra que se conserve (p. ej. la cola de una
    # repetición: «comenta la palabra… comenta la pa-»). Se quitan.
    quitar_idx = {i for g in grupos for i in range(g["i0"], g["i1"] + 1)}
    quedan = [w for i, w in enumerate(pal) if i not in quitar_idx]
    restos = [(s, e) for s, e in tr if e - s < 0.35 and not any(min(e, w["e"]) - max(s, w["s"]) > 0.05 for w in quedan)]
    tr = [x for x in tr if x not in restos]
    tr = cuantizar(tr)
    if not tr:
        raise SystemExit("No quedó voz después de los cortes (¿audio muy bajo o INICIO/FIN mal puestos?).")
    (out / "tramos.json").write_text(json.dumps(tr), encoding="utf-8")

    print("\n── CORTES (revísalos; si algo no debía irse, usa SIN_GRUPOS=1 o ajusta QUITAR/INICIO/FIN) ──")
    for g in grupos:
        print(f"  [{g['tipo']:<10}] {g['s']:7.2f}–{g['e']:6.2f}  {g['motivo']}")
    for s, e in restos:
        print(f"  [resto     ] {s:7.2f}–{e:6.2f}  pedacito de voz sin palabra útil entre dos cortes")
    huecos = [(0.0, tr[0][0])] + [(tr[k][1], tr[k + 1][0]) for k in range(len(tr) - 1)] + [(tr[-1][1], dur)]
    tot_sil = 0.0
    for s, e in huecos:
        if e - s <= 0.001: continue
        dentro = [w["w"] for i, w in enumerate(pal) if i not in quitar_idx and w["s"] >= s - 0.02 and w["e"] <= e + 0.02
                  and (w["e"] - w["s"]) > 0.08]
        if dentro:
            print(f"  [⚠ revisar ] {s:7.2f}–{e:6.2f}  se fue con el silencio: «{' '.join(dentro)}» (¿voz muy baja?)")
        tot_sil += e - s
    # palabras que quedaron fuera de los tramos (corte apretado) → aviso
    fuera = []
    for i, w in enumerate(pal):
        if i in quitar_idx: continue
        d = max(1e-3, w["e"] - w["s"])
        cub = sum(max(0, min(e, w["e"]) - max(s, w["s"])) for s, e in tr) / d
        if cub < 0.5: fuera.append(f"{w['w']}@{w['s']:.2f}")
    total = sum(e - s for s, e in tr)
    print(f"  silencios y respiraciones: {len(huecos)} huecos, {tot_sil:.2f} s fuera")
    if fuera:
        print(f"  palabras con < 50 % dentro del corte: {fuera}")
    print(f"tramos: {len(tr)} → {total:.2f} s de {dur:.2f} s\n")

    # 3. video: SDR, tamaño, 30 fps, solo los cuadros de los tramos (bordes de cuadro exactos)
    sel = "+".join(f"between(n,{int(round(s * FPS))},{int(round(e * FPS)) - 1})" for s, e in tr)
    vf = (f"setpts=PTS-STARTPTS,{tonemap_vf(info['hdr'])}scale={W}:{H}:force_original_aspect_ratio=increase:flags=lanczos,"
          f"crop={W}:{H},fps={FPS},select='{sel}',setpts=N/{FPS}/TB,format=yuv420p")
    vtmp = out / "toma-limpia-video.mp4"
    print("video: tonemap + escala + corte limpio (libx264)…", flush=True)
    run([FF, "-v", "error", "-y", "-i", str(src), "-map", "0:v:0", "-vf", vf, "-c:v", "libx264", "-preset", "medium",
         "-crf", str(a.crf), "-pix_fmt", "yuv420p", "-color_primaries", "bt709", "-color_trc", "bt709",
         "-colorspace", "bt709", "-an", str(vtmp)])

    # 4. voz pro (misma sincronía que el video)
    vc = out / "voz-cruda.wav"
    run([FF, "-v", "error", "-y", "-i", str(src), "-map", "0:a:0", "-ac", "1", "-ar", "48000", "-c:a", "pcm_s24le", str(vc)])
    vinfo = voz_pro.procesar(vc, tr, out / "voz-limpia.wav")

    # 5. toma limpia = video + voz pro
    run([FF, "-v", "error", "-y", "-i", str(vtmp), "-i", str(out / "voz-limpia.wav"), "-map", "0:v", "-map", "1:a",
         "-c:v", "copy", "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-movflags", "+faststart", str(out / "toma-limpia.mp4")])
    vtmp.unlink()
    nfr = sum(voz_pro.cuadros(s, e) for s, e in tr)

    def mapt(t):
        off = 0.0
        for s, e in tr:
            if t < s: return off
            if t <= e: return off + t - s
            off += e - s
        return off

    def dentro(w):                       # una palabra se queda si su intervalo toca algún tramo
        return any(w["e"] > s + 0.02 and w["s"] < e - 0.02 for s, e in tr)

    nuevas = []
    for i, w in enumerate(pal):
        if i in quitar_idx or not dentro(w):
            continue
        s0 = next((max(w["s"], s) for s, e in tr if w["e"] > s and w["s"] < e), w["s"])
        e0 = min(w["e"], next((e for s, e in tr if w["e"] > s and w["s"] < e), w["e"]))
        nuevas.append({"w": w["w"], "s": round(mapt(s0), 3), "e": round(max(mapt(e0), mapt(s0) + 0.03), 3)})
    (out / "palabras.json").write_text(json.dumps(nuevas, ensure_ascii=False, indent=0), encoding="utf-8")

    jc, off = [], 0.0
    for k, (s, e) in enumerate(tr):
        off += e - s
        if k + 1 < len(tr):
            jc.append({"t": round(off, 3), "cuadro": int(round(off * FPS)), "quitado_s": round(tr[k + 1][0] - e, 3),
                       "original": [e, tr[k + 1][0]]})
    (out / "jumpcuts.json").write_text(json.dumps(jc, indent=1), encoding="utf-8")

    # 6. caras sobre la toma limpia (ya en su tiempo)
    caras = detectar_caras(out / "toma-limpia.mp4", W, H)
    (out / "caras.json").write_text(json.dumps(caras), encoding="utf-8")

    resumen = {"ancho": W, "alto": H, "fps": FPS, "cuadros": nfr, "duracion": round(nfr / FPS, 3),
               "ultima_palabra_fin": nuevas[-1]["e"] if nuevas else 0, "palabras": len(nuevas), "tramos": len(tr),
               "jumpcuts": len(jc), "voz": vinfo, "detector_caras": caras["detector"],
               "whisper": motor_whisper(a.whisper), "original": str(src.name)}
    (out / "info.json").write_text(json.dumps(resumen, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"\nlisto: {out / 'toma-limpia.mp4'} · {resumen['duracion']} s · {len(nuevas)} palabras · {len(jc)} jumpcuts")
    print("texto:", " ".join(w["w"] for w in nuevas))


if __name__ == "__main__":
    main()
