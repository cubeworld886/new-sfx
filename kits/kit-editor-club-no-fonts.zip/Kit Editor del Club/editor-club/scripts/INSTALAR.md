# Instalar el kit «editor-club» (Mac y Windows)

Todo corre en tu computadora y es gratis: no usa ninguna API de pago. La primera vez se bajan los modelos
(Whisper ~1.6 GB y DeepFilterNet ~10 MB) y después funcionan sin internet.

Requisitos: **Python 3.11** (no 3.12/3.13: DeepFilterNet y torch 2.1 no tienen versión para ellas), **ffmpeg** y
~6 GB libres. Recomendado: 16 GB de RAM.

---

## Mac (Apple Silicon M1/M2/M3/M4 o Intel)

1. **Python 3.11**: bájalo de <https://www.python.org/downloads/macos/> (instalador «macOS 64-bit universal2»
   de la versión 3.11.x) o con Homebrew: `brew install python@3.11`.
2. **ffmpeg**: `brew install ffmpeg`
   (si no tienes Homebrew: <https://brew.sh>. Si no puedes instalar ffmpeg, el kit usa el que trae el paquete
   `imageio-ffmpeg`, que se instala solo en el paso 4).
3. **Entorno virtual** (en el disco interno; un disco externo exFAT rompe pip):
   ```bash
   python3.11 -m venv ~/.venvs/editor-club
   source ~/.venvs/editor-club/bin/activate
   python -m pip install --upgrade pip
   ```
4. **Paquetes** (desde la carpeta del kit, donde está `requirements.txt`):
   ```bash
   pip install -r requirements.txt
   ```
   En Mac con chip Apple se instala además `mlx-whisper` (Whisper en la GPU, mucho más rápido). En Intel se usa
   `faster-whisper` en la CPU.
5. **Fuentes**: ya vienen en `scripts/fuentes/` (Inter, Playfair Display, Instrument Serif, JetBrains Mono — licencia
   OFL). En Mac el motor usa primero SF Pro y New York, que trae macOS. Ver `scripts/fuentes/LEEME.txt`.

## Windows 10/11

1. **Python 3.11**: `winget install Python.Python.3.11`
   (o el instalador de <https://www.python.org/downloads/windows/>, marcando «Add python.exe to PATH»).
2. **ffmpeg**: `winget install Gyan.FFmpeg` y **cierra y vuelve a abrir** la terminal para que aparezca en el PATH.
   (Si no se puede, el kit usa el de `imageio-ffmpeg`.)
3. **Entorno virtual** (PowerShell):
   ```powershell
   py -3.11 -m venv $HOME\.venvs\editor-club
   & $HOME\.venvs\editor-club\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   ```
   Si PowerShell no deja activar: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` (una sola vez).
4. **Paquetes**: `pip install -r requirements.txt`
   - Con tarjeta NVIDIA, faster-whisper usa CUDA solo si tienes CUDA 12 + cuDNN 9; si no, usa la CPU (más lento,
     igual funciona: ~1–2 min por minuto de video).
   - Si `pip` pide «Microsoft Visual C++ Redistributable», instálalo: `winget install Microsoft.VCRedist.2015+.x64`.
5. **Fuentes**: usa las de `scripts\fuentes\` (Inter / Playfair Display). Si faltan, cae a Segoe UI y Georgia Italic.

---

## Nota importante: DeepFilterNet necesita torch 2.1

`deepfilternet==0.5.6` (la limpieza de voz con IA) **se rompe con torch/torchaudio nuevos**: falla al importar
`torchaudio.backend.common`. Por eso `requirements.txt` fija `torch==2.1.2`, `torchaudio==2.1.2` y `numpy<2`.
No los actualices. Si algo instaló otra versión:

```bash
pip install "torch==2.1.2" "torchaudio==2.1.2" "numpy<2" "deepfilternet==0.5.6"
```

Si aun así DeepFilterNet no carga, `preparar_toma.py` sigue funcionando: avisa y usa el reductor de ruido de ffmpeg
(la voz queda bien, solo un poco menos limpia).

Si `mediapipe` no se deja instalar en tu equipo (pasa en algunos Mac Intel viejos), quítalo de `requirements.txt` y
vuelve a correr `pip install -r requirements.txt`: la detección de caras cae sola a OpenCV (YuNet si pones el modelo
`face_detection_yunet_2023mar.onnx` en `scripts/modelos/`, si no Haar). La barbilla sale un poco menos precisa: revisa
los cuadros con `motor_club.py prueba`.

Otros avisos normales que puedes ignorar: `UserWarning: torchaudio.backend.common…`, `fatal: not a git repository`
(lo imprime DeepFilterNet) y las líneas `I0000`/`W0000` de mediapipe.

## Probar que todo quedó bien

```bash
python -c "import mediapipe, cv2, torch, df, faster_whisper, soundfile, scipy; print('ok', torch.__version__)"
python scripts/preparar_toma.py --help
```

## Los 3 comandos

```bash
python scripts/preparar_toma.py MI_VIDEO.MOV mi-toma            # (--horizontal para 16:9)
python scripts/motor_club.py prueba mi-plan.json 0.5 3.2 12.0     # cuadros sueltos para revisar
python scripts/editar.py mi-toma mi-plan.json                     # → mi-toma/edicion/final.mp4
```
