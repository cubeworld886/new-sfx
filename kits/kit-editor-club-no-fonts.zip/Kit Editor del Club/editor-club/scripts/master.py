"""master — audio final a −11 LUFS / ≤ −1 dBTP montado sobre el video (el video se copia, no se recodifica).

    python master.py <video.mp4> <mezcla.wav> <salida.mp4> [--lufs -11] [--duracion 34.667]

1. Master: ganancia hasta −11 LUFS integrados + pasa-bajos 17.5 kHz + limitador sobremuestreado ×4 (a 192 kHz, atrapa
   los picos entre muestras que el AAC después revela). Se ajusta la ganancia en hasta 3 vueltas (±0.2 LU).
2. Monta AAC 320 kbps 48 kHz con el video copiado (si el video traía audio, se reemplaza).
3. Mide el pico real DESPUÉS del AAC: si pasa de −1 dBTP, baja el techo del limitador y repite (hasta 5 vueltas);
   si el AAC movió la sonoridad más de 0.15 LU, corrige la ganancia.
Imprime LUFS y pico real del MP4 final.
"""
from __future__ import annotations

import argparse
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from comun import ffmpeg, medir, probe, run  # noqa: E402

LUFS_FINAL = -11.0


def master_wav(src, dst, techo=0.80, objetivo=LUFS_FINAL):
    g = objetivo - medir(src)[0]
    lu = tp = None
    for _ in range(3):
        run([ffmpeg(), "-v", "error", "-y", "-i", str(src), "-af",
             f"volume={g:.2f}dB,lowpass=f=17500:p=2,aresample=192000,"
             f"alimiter=limit={techo}:attack=0.8:release=80:level=false,aresample=48000",
             "-ar", "48000", "-c:a", "pcm_s24le", str(dst)])
        lu, tp = medir(dst)
        if abs(lu - objetivo) < 0.2: break
        g += objetivo - lu
    return lu, tp


def masterizar(video, mezcla, salida, objetivo=LUFS_FINAL, duracion=None):
    FF = ffmpeg()
    dur = duracion or probe(video)["duracion"]
    techo = 0.80
    lu = pk = None
    with tempfile.TemporaryDirectory(prefix="master_") as tmp:
        tmp = Path(tmp)
        meta = objetivo                                  # se corrige si el AAC mueve la sonoridad
        for intento in range(5):
            master_wav(mezcla, tmp / "m.wav", techo, meta)
            run([FF, "-v", "error", "-y", "-i", str(tmp / "m.wav"), "-t", f"{dur:.3f}", "-af",
                 f"afade=t=out:st={max(0, dur - 0.03):.3f}:d=0.03", "-ar", "48000", "-c:a", "pcm_s24le", str(tmp / "f.wav")])
            run([FF, "-v", "error", "-y", "-i", str(video), "-i", str(tmp / "f.wav"), "-map", "0:v:0", "-map", "1:a:0",
                 "-c:v", "copy", "-c:a", "aac", "-b:a", "320k", "-ar", "48000", "-t", f"{dur:.3f}",
                 "-movflags", "+faststart", str(salida)])
            lu, pk = medir(salida)
            print(f"intento {intento}: techo {techo:.3f} → {lu} LUFS · pico real {pk} dBTP (tras AAC)")
            if pk <= -1.0 and abs(lu - objetivo) <= 0.15: break
            if pk > -1.0: techo *= 10 ** ((-1.2 - pk) / 20)
            if abs(lu - objetivo) > 0.15: meta += objetivo - lu
    print(f"master listo: {salida} · {lu} LUFS · pico {pk} dBTP")
    return lu, pk


def main():
    ap = argparse.ArgumentParser(description="Master −11 LUFS / ≤ −1 dBTP + AAC 320k sobre el video")
    ap.add_argument("video"); ap.add_argument("mezcla"); ap.add_argument("salida")
    ap.add_argument("--lufs", type=float, default=LUFS_FINAL)
    ap.add_argument("--duracion", type=float)
    a = ap.parse_args()
    masterizar(a.video, a.mezcla, a.salida, a.lufs, a.duracion)


if __name__ == "__main__":
    main()
