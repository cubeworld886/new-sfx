"""mezcla — voz + música bajo la voz (con ducking) + whooshes suaves sintetizados.

    python mezcla.py <voz.wav> <musica|-> <salida.wav> [--musica-db 15] [--inicio-musica 2]
                     [--whooshes 2.8,6.9] [--palabras palabras.json] [--duracion 34.667]

- Música (opcional; «-» o «ninguna» = solo voz y efectos): desde --inicio-musica, a --musica-db dB BAJO la voz
  (LUFS contra LUFS), con hueco de 1–4 kHz para que la voz se entienda y ducking por la envolvente de la voz (−4.4 dB
  mientras habla). Entra en 60 ms y se va en 300 ms al final: termina con tu última palabra (sin outro).
- Whooshes: ruido filtrado 300–3000 Hz con envolvente seno^1.5, cortos y sutiles (28 % del pico de la voz), sin
  archivos de audio. Cada uno se mete en el hueco REAL de voz más cercano (envolvente < −34 dB ≥ 50 ms, a ≤ 0.3 s del
  tiempo pedido); con --palabras además se verifica que ninguno caiga encima de una palabra. Si no cabe, se descarta
  y se avisa.
- Mezcla a −14 LUFS con limitador sobremuestreado ×4 (techo −2.2 dBTP). El master final (master.py) la sube a −11.
Salida: WAV 48 kHz estéreo 24 bits.
"""
from __future__ import annotations

import argparse
import json
import sys
import tempfile
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import butter, lfilter, resample_poly, sosfilt

sys.path.insert(0, str(Path(__file__).resolve().parent))
from comun import ffmpeg, run  # noqa: E402

SR = 48000


def lp(x, f, o=2): return sosfilt(butter(o, f, "low", fs=SR, output="sos"), x, axis=0)
def bp(x, a, b, o=2): return sosfilt(butter(o, [a, b], "band", fs=SR, output="sos"), x, axis=0)


def lufs(x):
    """Sonoridad integrada ITU-R BS.1770 (filtro K + compuertas)."""
    if x.ndim == 1: x = x[:, None]
    b1, a1 = [1.53512485958697, -2.69169618940638, 1.19839281085285], [1, -1.69065929318241, 0.73248077421585]
    b2, a2 = [1, -2, 1], [1, -1.99004745483398, 0.99007225036621]
    y = lfilter(b2, a2, lfilter(b1, a1, x, axis=0), axis=0)
    blk, hop = int(0.4 * SR), int(0.1 * SR)
    ms = np.array([np.sum(np.mean(y[i:i + blk] ** 2, 0)) for i in range(0, max(1, len(y) - blk), hop)])
    l = -0.691 + 10 * np.log10(ms + 1e-12)
    ms = ms[l > -70]
    if len(ms) == 0: return -70.0
    rel = -0.691 + 10 * np.log10(ms.mean()) - 10
    ms = ms[(-0.691 + 10 * np.log10(ms)) > rel]
    return float(-0.691 + 10 * np.log10(ms.mean()))


def true_peak(x): return float(20 * np.log10(np.max(np.abs(resample_poly(x, 4, 1, axis=0))) + 1e-12))


def limiter(x, ceil_db=-1.3):
    """Limitador de pico real: detecta sobremuestreando ×4, mira 4 ms adelante, suelta en 80 ms."""
    from scipy.ndimage import minimum_filter1d
    c = 10 ** (ceil_db / 20)
    up = np.abs(resample_poly(x, 4, 1, axis=0)).max(1)
    pk = up.reshape(-1, 4).max(1)[:len(x)]
    if len(pk) < len(x): pk = np.pad(pk, (0, len(x) - len(pk)), mode="edge")
    need = np.minimum(1, c / np.maximum(pk, 1e-9))
    la = int(0.004 * SR)
    g = minimum_filter1d(need, 2 * la + 1)
    rel = np.exp(-1 / (0.08 * SR)); out = np.empty_like(g); cur = 1.0
    for i in range(len(g)):
        cur = g[i] if g[i] < cur else g[i] + (cur - g[i]) * rel
        out[i] = cur
    return x * out[:, None]


def whoosh_corto(d, seed=4):
    """Barrido de ruido filtrado, ataque y caída rápidos (cabe en huecos de 60–110 ms)."""
    n = int(d * SR); tt = np.arange(n) / SR
    s = bp(np.random.default_rng(seed).standard_normal(n), 300, 3000, 2)
    env = np.sin(np.pi * np.clip(tt / d, 0, 1)) ** 1.5
    return s * env


def cancion(path, inicio, N):
    with tempfile.TemporaryDirectory(prefix="mezcla_") as tmp:
        w = Path(tmp) / "m.wav"
        run([ffmpeg(), "-v", "error", "-y", "-ss", f"{inicio:.3f}", "-i", str(path), "-vn", "-ac", "2", "-ar", str(SR),
             "-c:a", "pcm_s16le", str(w)])
        m, _ = sf.read(str(w), dtype="float64", always_2d=True)
    out = np.zeros((N, 2)); k = min(N, len(m)); out[:k] = m[:k, :2]
    fi = int(0.06 * SR); out[:fi] *= np.linspace(0, 1, fi)[:, None]
    fo = min(N, int(0.30 * SR)); out[-fo:] *= np.linspace(1, 0, fo)[:, None] ** 1.5
    return out


def huecos_voz(voz, umbral=-34.0, minimo=0.05):
    """huecos REALES de voz: tramos donde la envolvente (RMS 10 ms) queda bajo `umbral` dBFS al menos `minimo` s."""
    h = int(0.01 * SR); n = len(voz) // h
    db = 20 * np.log10(np.sqrt((voz[:n * h].reshape(n, h) ** 2).mean(1)) + 1e-9)
    out, i = [], 0
    while i < n:
        if db[i] < umbral:
            j = i
            while j < n and db[j] < umbral: j += 1
            if (j - i) * 0.01 >= minimo: out.append((i * 0.01, j * 0.01))
            i = j
        else:
            i += 1
    return out


def ajustar_whooshes(ts, palabras, voz=None, largo=0.11, cerca=0.25, separacion=2.0, maximo=6):
    """Cada whoosh se mete en el hueco real de voz más cercano a su tiempo (≤ 0.3 s) y nunca sobre el centro de una
    palabra. Si no hay hueco, se descarta y se avisa. Devuelve [(a, b)] y avisos."""
    res, avisos = [], []
    huecos = huecos_voz(voz) if voz is not None else []
    # Whisper marca los bordes de cada palabra con ±0.1 s de error: la verdad la da la energía de la voz; de las
    # palabras solo se protege su tercio central
    nucleos = [(w["s"] + (w["e"] - w["s"]) / 3, w["e"] - (w["e"] - w["s"]) / 3) for w in (palabras or [])]
    for t in sorted(ts):
        if voz is None:
            res.append((t, t + largo)); continue
        cand = [(a, b) for a, b in huecos if a - cerca <= t <= b + cerca]
        if not cand:
            avisos.append(f"whoosh en {t:.2f} s descartado: no hay un hueco de voz ≥ 50 ms cerca (caería encima de su voz)")
            continue
        a, b = min(cand, key=lambda g: abs((g[0] + g[1]) / 2 - t))
        a, b = a + 0.005, b - 0.005
        if b - a > largo:
            m = min(max(t, a + largo / 2), b - largo / 2); a, b = m - largo / 2, m + largo / 2
        if any(a < e and b > s for s, e in nucleos):
            avisos.append(f"whoosh en {t:.2f} s descartado: pisaría una palabra")
            continue
        if res and a - res[-1][1] < separacion:
            avisos.append(f"whoosh en {t:.2f} s descartado: muy pegado al anterior (< {separacion:.1f} s)")
            continue
        res.append((round(a, 3), round(b, 3)))
        if len(res) >= maximo: break
    return res, avisos


def mezclar(voz, musica, salida, musica_db=15.0, inicio_musica=2.0, whooshes=(), palabras=None, duracion=None):
    v, sr = sf.read(str(voz), dtype="float64", always_2d=True)
    v = v.mean(1)
    if sr != SR:
        v = resample_poly(v, SR, sr)
    N = int(round((duracion if duracion else len(v) / SR) * SR))
    voice = np.zeros(N); voice[:min(N, len(v))] = v[:N]; voice = np.stack([voice, voice], 1)
    Lv = lufs(voice)
    info = {"voz_lufs": round(Lv, 2)}
    mus = np.zeros((N, 2))
    if musica and str(musica).lower() not in ("-", "ninguna", "none") and Path(musica).exists():
        mus = cancion(musica, inicio_musica, N)
        mus = mus - 0.30 * bp(mus, 1000, 4000, 2)                        # hueco para la voz
        env = lp(np.abs(voice[:, 0]), 5); env = np.clip(env / (np.percentile(env, 95) + 1e-9), 0, 1)
        mus = mus * (1 - 0.40 * env)[:, None]                            # ducking ≈ −4.4 dB mientras habla
        mus *= 10 ** ((Lv - musica_db - lufs(mus)) / 20)
        info["musica_bajo_voz_db"] = round(lufs(mus) - Lv, 2)
    elif musica and str(musica).lower() not in ("-", "ninguna", "none"):
        print(f"⚠️  no encuentro la música «{musica}»: va solo voz y efectos")
    wh, avisos = ajustar_whooshes(list(whooshes), palabras, voice[:, 0])
    for a_ in avisos: print("⚠️ ", a_)
    fx = np.zeros((N, 2))
    for k, (a, b) in enumerate(wh):
        s = whoosh_corto(b - a, seed=4 + k); i0 = int(a * SR); j = min(N, i0 + len(s))
        if j > i0: fx[i0:j, 0] += s[:j - i0]; fx[i0:j, 1] += s[:j - i0]
    if wh:
        fx = lp(fx, 2800, 4)
        fx *= (np.percentile(np.abs(voice[:, 0]), 99.5) * 0.28) / (np.abs(fx).max() + 1e-9)
    mix = voice + mus + fx
    mix *= 10 ** ((-14 - lufs(mix)) / 20)
    for _ in range(3):
        mix = limiter(mix, -2.0); mix *= 10 ** ((-14 - lufs(mix)) / 20)
    mix = limiter(mix, -2.2)
    # verificación: ¿algún whoosh encima de una palabra?
    sobre = []
    if palabras:                                   # tercio central de cada palabra
        for a, b in wh:
            for w in palabras:
                d = (w["e"] - w["s"]) / 3
                if w["s"] + d < b and w["e"] - d > a: sobre.append((w["w"], a))
    h = int(0.01 * SR)
    vdb = lambda i: 20 * np.log10(np.sqrt((voice[i:i + h, 0] ** 2).mean()) + 1e-9)
    con_voz = [round(a, 2) for a, b in wh for i in range(int(a * SR), int(b * SR), h) if vdb(i) > -30][:5]
    info.update(efectos=[list(x) for x in wh], whoosh_sobre_palabras=sobre, bloques_10ms_con_voz_bajo_whoosh=con_voz,
                mezcla_lufs=round(lufs(mix), 2), mezcla_tp=round(true_peak(mix), 2), dur=round(N / SR, 3))
    sf.write(str(salida), np.clip(mix, -1, 1).astype(np.float32), SR, subtype="PCM_24")
    print("mezcla:", json.dumps(info, ensure_ascii=False))
    return info


def main():
    ap = argparse.ArgumentParser(description="Voz + música con ducking + whooshes sintetizados → WAV a −14 LUFS")
    ap.add_argument("voz"); ap.add_argument("musica", help="archivo de música o «-» para ninguna"); ap.add_argument("salida")
    ap.add_argument("--musica-db", type=float, default=15.0, help="dB de la música BAJO la voz (por defecto 15)")
    ap.add_argument("--inicio-musica", type=float, default=2.0, help="segundo de la canción donde arranca")
    ap.add_argument("--whooshes", default="", help="tiempos separados por coma, p. ej. 2.8,6.9")
    ap.add_argument("--palabras", help="palabras.json de la toma limpia (verifica que ningún whoosh pise una palabra)")
    ap.add_argument("--duracion", type=float, help="segundos exactos de salida (= duración del video)")
    a = ap.parse_args()
    ts = [float(x) for x in a.whooshes.replace(" ", "").split(",") if x]
    pal = json.loads(Path(a.palabras).read_text(encoding="utf-8")) if a.palabras else None
    mezclar(a.voz, a.musica, a.salida, a.musica_db, a.inicio_musica, ts, pal, a.duracion)


if __name__ == "__main__":
    main()
