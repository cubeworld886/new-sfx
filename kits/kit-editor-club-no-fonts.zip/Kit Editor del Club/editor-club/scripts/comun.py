"""comun — utilidades compartidas del kit «editor-club» (Mac Apple Silicon / Intel y Windows).

- ffmpeg(): el ffmpeg del PATH (brew / winget) o, si no hay, el que trae `imageio-ffmpeg`.
- run(): subprocess SIN shell (rutas con espacios y acentos funcionan igual en Windows).
- probe(): duración, tamaño, fps y si es HDR, leyendo la cabecera con ffmpeg (no hace falta ffprobe).
- medir(): LUFS integrados y pico real (dBTP) con el filtro ebur128.
- procesos_render(): cuántos procesos de render caben (máx. 4, respetando ≥ 20 % de RAM libre).
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
_FF: str | None = None

# Windows: si la salida va a un archivo o a otro programa (p. ej. Claude Code), Python usa cp1252 y los «✓ ⚠️ →»
# romperían el script. Se fuerza UTF-8.
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def ffmpeg() -> str:
    """Ruta de ffmpeg: variable FFMPEG > ffmpeg del PATH > imageio-ffmpeg."""
    global _FF
    if _FF:
        return _FF
    cand = os.environ.get("FFMPEG") or shutil.which("ffmpeg")
    if not cand:
        try:
            import imageio_ffmpeg
            cand = imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            cand = None
    if not cand:
        raise SystemExit("No encuentro ffmpeg. Instálalo (Mac: brew install ffmpeg · Windows: winget install Gyan.FFmpeg) "
                         "o instala el paquete imageio-ffmpeg (pip install imageio-ffmpeg).")
    _FF = cand
    # mlx-whisper / faster-whisper a veces llaman a `ffmpeg` por nombre: que lo encuentren
    os.environ["PATH"] = str(Path(cand).parent) + os.pathsep + os.environ.get("PATH", "")
    return _FF


def run(cmd: list, cwd=None, env=None, check=True) -> str:
    """Ejecuta sin shell. Devuelve stdout + stderr (ffmpeg escribe sus medidas en stderr)."""
    r = subprocess.run([str(c) for c in cmd], cwd=cwd, env=env, capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    if check and r.returncode != 0:
        raise RuntimeError(f"Falló: {' '.join(str(c) for c in cmd[:6])} …\n{r.stderr[-1500:]}")
    return (r.stdout or "") + (r.stderr or "")


def probe(path) -> dict:
    """Lee la cabecera con `ffmpeg -i` (sin ffprobe, que imageio-ffmpeg no trae)."""
    txt = run([ffmpeg(), "-hide_banner", "-i", str(path)], check=False)
    m = re.search(r"Duration: (\d+):(\d+):(\d+(?:\.\d+)?)", txt)
    dur = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)) if m else 0.0
    v = next((l for l in txt.splitlines() if "Video:" in l and "attached pic" not in l), "")
    a = next((l for l in txt.splitlines() if "Audio:" in l and "none" not in l.split("Audio:")[1][:8]), "")
    wh = re.search(r", (\d{2,5})x(\d{2,5})", v)
    fps = re.search(r"([\d.]+) fps", v)
    rot = re.search(r"rotation of (-?[\d.]+)", txt)
    w, h = (int(wh.group(1)), int(wh.group(2))) if wh else (0, 0)
    if rot and abs(float(rot.group(1))) % 180 == 90:
        w, h = h, w
    return {"duracion": dur, "video": bool(v), "audio": bool(a), "ancho": w, "alto": h,
            "fps": float(fps.group(1)) if fps else 30.0,
            "hdr": ("arib-std-b67" in v) or ("smpte2084" in v)}


def medir(f) -> tuple[float, float]:
    """(LUFS integrados, pico real dBTP) del audio de un archivo."""
    m = run([ffmpeg(), "-hide_banner", "-nostats", "-i", str(f), "-map", "0:a:0", "-af", "ebur128=peak=true", "-f", "null", "-"])
    lu = float(m.split("I:")[-1].split("LUFS")[0])
    pk = float(m.split("Peak:")[-1].split("dBFS")[0])
    return lu, pk


def ram_total_gb() -> float:
    try:
        if sys.platform == "win32":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            s = MS(); s.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s))
            return s.ullTotalPhys / 2 ** 30
        if sys.platform == "darwin":
            return int(run(["sysctl", "-n", "hw.memsize"]).strip()) / 2 ** 30
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2 ** 30
    except Exception:
        return 8.0


def procesos_render(maximo: int = 4) -> int:
    """Máx. 4 procesos; cada uno usa ~1.5 GB en vertical: deja siempre ≥ 20 % de la RAM libre."""
    cpus = os.cpu_count() or 2
    por_ram = int(ram_total_gb() * 0.8 / 2.5)
    return max(1, min(maximo, cpus // 2 or 1, por_ram))
