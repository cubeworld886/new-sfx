# Kit Editor del Club · edita tus videos con Claude en el estilo de Diego Cabrera

Con este kit, tu Claude edita tus videos a cámara (reels verticales e intros de YouTube) en el estilo «Club de Monetización».
Hace lo siguiente:
- quita los silencios;
- deja tu voz profesional;
- pone los textos con una palabra clave en azul;
- agrega stock y motion graphics tipo After Effects;
- no deja outro.

## Qué necesitas
- **Claude Code**: la app de escritorio de Claude (pestaña Code) o la terminal. Claude.ai en el navegador no sirve, porque el video se procesa en tu computadora.
- **Una computadora:** Mac (ideal con chip M1 o superior) o Windows, con unos 10 GB libres.
- **Tus videos y tu material:** tu foto de perfil, tu stock (videos y capturas tuyas) y, si quieres, una música con derechos.

## Cómo se usa (3 pasos)
1. Descomprime este kit en una carpeta (por ejemplo `Documentos/Editor del Club`).
2. Abre Claude Code **dentro de esa carpeta**.
3. Copia todo el contenido de **`PROMPT.md`**, pégalo en Claude y cambia solo:
   - la ruta de tu video;
   - si el video es vertical u horizontal.

La primera vez, Claude instala todo solo (tarda unos minutos) y te hace 5 preguntas sobre tu marca. Después, para cada video nuevo basta con escribir: **«edita este video en el estilo del Club: [ruta del video]»**.

## Qué trae
| Carpeta | Para qué |
|---|---|
| `PROMPT.md` | El único prompt que tienes que pegar. |
| `editor-club/SKILL.md` | El cerebro: estilo, reglas, flujo, audio y el porqué de cada regla. |
| `editor-club/scripts/` | Las herramientas que usa Claude: preparar la toma, voz pro, motor del estilo, efectos tipo After Effects, mezcla y master. |
| `editor-club/referencias/` | Hojas de cuadros de videos aprobados, para que Claude compare. |
| `editor-club/ejemplos/` | Planes de edición de ejemplo (vertical y horizontal). |
| `editor-club/marca/` | Aquí van tu `avatar.png` y los logos oficiales de las plataformas. |

## Importante
- Todo corre en tu computadora y es gratis. No necesitas pagar APIs.
- El kit **no incluye música**: usa una que tengas derecho a usar.
- Si Claude se equivoca, corrígelo con una frase. El prompt le pide guardar cada corrección como regla nueva para que no se repita.
