#!/usr/bin/env python3
"""Fast offline tests: official skill copies, byte identity, collision safety, validator."""
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]


def mod(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

install = mod("install_official", BASE / "scripts" / "install_official_hyperframes.py")
valid = mod("shotlist", BASE / "scripts" / "validate_shotlist.py")


class InstallerTests(unittest.TestCase):
    def test_official_copies_exact(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "repo"
            for name in install.NAMES:
                d = source / "skills" / name / "references"
                d.mkdir(parents=True)
                (d.parent / "SKILL.md").write_bytes(f"---\nname: {name}\n---\n".encode())
                (d / "binary.dat").write_bytes(bytes([0, 1, 19, 127, 255, 200]))
            target = root / "installed"
            args = ["--source", str(source), "--target", str(target)]
            self.assertEqual(install.main(args), 0)
            for name in install.NAMES:
                self.assertEqual(install.snapshot(source / "skills" / name), install.snapshot(target / name))
            self.assertEqual(install.main(args), 0)  # idempotent
            # A local user change may not be clobbered without --force.
            (target / "hyperframes" / "SKILL.md").write_text("custom edit")
            self.assertEqual(install.main(args), 2)
            self.assertEqual((target / "hyperframes" / "SKILL.md").read_text(), "custom edit")
            self.assertEqual(install.main(args + ["--force"]), 0)
            self.assertEqual(install.snapshot(source / "skills" / "hyperframes"), install.snapshot(target / "hyperframes"))
            self.assertTrue(list(target.glob("hyperframes.backup-*")))


class TimelineTests(unittest.TestCase):
    def test_sample(self):
        data = json.loads((BASE / "examples/cinema/shotlist.json").read_text())
        errs, warns = valid.validate(data)
        self.assertEqual(errs, [])
        self.assertEqual(warns, [])

    def test_seam_and_morph_guard(self):
        data = json.loads((BASE / "examples/cinema/shotlist.json").read_text())
        data["shots"][2]["start_frame"] += 2
        errs, _ = valid.validate(data)
        self.assertTrue(any("gap/overlap" in err for err in errs))
        data["shots"][2]["start_frame"] -= 2
        data["shots"][1]["transition_to_next"]["type"] = "shape-morph"
        errs, _ = valid.validate(data)
        self.assertTrue(any("geometry_pair" in err for err in errs))


if __name__ == "__main__":
    unittest.main()
