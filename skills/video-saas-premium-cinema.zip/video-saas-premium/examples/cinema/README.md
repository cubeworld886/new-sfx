# Plantilla Cinema — 30 segundos

El archivo `shotlist.json` es una **maqueta narrativa** de un video de producto que muestra una operacion real en un restaurante. No incorpora grabaciones, UI ni activos del cliente: son **placeholders** por sustituir antes de producir. No inventar cifras ni estados.

Ejecutar:

```bash
python ../../scripts/validate_shotlist.py shotlist.json
```

La lista usa **frames semiexclusivos** `[start_frame,end_frame)`; a 60 fps, 1800 frames equivalen a 30.0 segundos. `motif_exit` y el siguiente `motif_entry` obligan a pensar una continuidad, no transiciones aleatorias. `transition_to_next.duration_frames` es una indicacion creativa alrededor del seam; el timeline real debe situar clips/hosts segun contrato vigente de HyperFrames. No implicar que las escenas se superponen fisicamente solo porque hay una transicion indicada.

Producir despues de: aportar capturas reales, confirmar las funciones mostradas, adaptar textos/marca, completar `SPEC.md` y verificar assets/licencias. La estructura es una guia, no un archivo MP4.
