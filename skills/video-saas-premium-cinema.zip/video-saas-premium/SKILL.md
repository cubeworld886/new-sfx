---
name: video-saas-premium
description: Dirigir, producir, diagnosticar y entregar anuncios cinematograficos premium para SaaS, apps, marcas y productos con motion graphics 2D/3D, animacion de interfaces reales, tipografia cinetica, morphing, camaras, particulas, efectos, diseno sonoro y render profesional. Reutiliza el kit original video-saas-premium (HyperFrames, GSAP, Three.js, ElevenLabs, SFX, capturas reales) y coordina las siete skills oficiales de HyperFrames sin modificarlas. Usar para comerciales tipo Apple, Figma, videos de lanzamiento, anuncios de apps o webs, trailers de producto, referencias de motion design y produccion automatizada desde Claude Code o Codex.
---

# Video SaaS Premium — Cinema Director Edition

**Principio:** un anuncio cinematografico no es una acumulacion de presets. Debe mostrar algo verdadero del producto, encadenar escenas con una logica espacial, sincronizar los acentos musicales y entregar una composicion reproducible, revisada fotograma a fotograma.

**Conservar la skill original.** Los directorios `kit/`, `scripts/` originales, `examples/starter/`, `references/` originales y `LICENSE` se mantienen sin modificaciones. `references/SKILL-original.md` y `assets/video-saas-premium-original.zip` guardan el original exacto. Esta capa agrega capacidades; no sustituye el flujo previo de marca, concepto, UI real, voz y SFX.

## Inicio obligatorio: fuente oficial y entorno

1. Identificar si es un proyecto nuevo o una iteracion. Para trabajos existentes, auditar archivos, duraciones, tracks, animaciones y aprobaciones antes de cambiar.
2. **Activar las skills oficiales de HyperFrames por separado**, no sobreescribir ni editar sus archivos. Ejecutar una sola vez `python scripts/install_official_hyperframes.py --agent both` para instalar las siete skills oficiales completas desde GitHub en las carpetas del agente (requiere Git y red). Para una sola plataforma: `--agent claude` o `--agent codex`. La skill funciona parcialmente sin ellas, pero **no afirmar** que quedaron instaladas hasta comprobarlo. La guia se encuentra en [Integracion oficial](references/hyperframes-oficial.md).
3. Leer **`/hyperframes`** antes de usar HyperFrames; luego usar `/hyperframes-cli`, `/hyperframes-registry` y `/media-use` para una produccion nueva. Seleccionar `/figma`, `/remotion-to-hyperframes`, `/slideshow` solo segun tipo de trabajo. Las skills oficiales tienen precedencia sobre esta skill para el **contrato tecnico actual** de HyperFrames.
4. Comprobar `node`, `npx hyperframes --help`, `ffmpeg`, Chrome/Chromium, Python 3. Para 3D complejo, comprobar Blender. Revisar version y cuotas del render; **no** asegurar herramientas o suscripciones que no existan.

> **Importante:** este ZIP contiene el instalador verificable, no una copia offline de los cientos de archivos upstream: las siete skills se copian tal cual al ejecutar el instalador. No alterar su codigo, ni integrarlo por texto en este `SKILL.md`.

## Ruta de produccion (real, auditable y reutilizable)

| Etapa | Accion / criterio de salida |
| --- | --- |
| 1 — Investigacion | Extraer marca con `scripts/brand_from_url.py`, leer el producto, recoger capturas reales; identificar hechos demostrables y licencias. Consultar `references/capturas-ui.md`. |
| 2 — Concepto | Extraer una verdad / propuesta de valor; explorar 2–3 mecanismos narrativos realmente distintos. Seguir `references/proceso-creativo.md`; cuando la persona pida autonomia total, elegir el mas defendible sin frenar. |
| 3 — Guion tecnico | Redactar `SPEC.md` y `shotlist.json`: secuencias con tiempo en segundos y frames, objetivo visual, fuente de UI, movimiento principal, conexion entre escenas, SFX/VO y criterio de exito. Usar `examples/cinema/shotlist.json` y `python scripts/validate_shotlist.py <archivo>`. |
| 4 — Desarrollo | Crear proyecto modular HyperFrames conforme al contrato actual; instalar bloques del registro antes de escribir efectos equivalentes; utilizar kit legacy solo donde respete dicho contrato. Para escenas cinematograficas usar `kit/cinema-motion.js` / `kit/vector-morph.js`, Three.js o Blender segun la necesidad. |
| 5 — Sonido | Voz natural con ElevenLabs opcional, sincronizacion por palabra verificable, musica con licencia, SFX por beat, transitorios, ambientes y ducking. Reutilizar `scripts/eleven_vo.py`, `scripts/audio_tools.py`, `scripts/sfx_curate.py`. |
| 6 — Revision | `npx hyperframes check --json`, snapshots de todas las escenas y **cada mitad de transicion**, revisiones de encuadre/movimiento/texto, control de red flags. Ajustar hasta que pase. |
| 7 — Render | Previsualizar, entregar el formato y framerate especificados; para 4K60 validar soporte y recursos, sin prometer 4K real si assets y geometria no lo resuelven. Auditar MP4 final con `python scripts/review_video.py video.mp4 --out review/`. |
| 8 — Entrega | Entregar MP4, archivos fuente editables, assets/licencias, `SPEC.md`, `REVIEW.md`, lista de notas y comandos de reproduccion. Nunca declarar validado algo que no se haya ejecutado o visto. |

## Lenguaje visual que se debe usar (no solo nombrar)

- **Cadena de transformaciones:** elegir un elemento narrativo (color, borde, gesto, icono, ruta) que migre de una escena a la siguiente. Ej.: logo → tarjeta UI → ruta de entrega → paquete 3D → tipografia. Cada enlace conserva posicion, direccion, velocidad o silueta; no cortar arbitrariamente.
- **Camara con intencion:** definir punto focal, posicion inicial/final, profundidad, duracion, curva y momento del impacto. Acompanar clic/resultado con zoom a la interaccion y luego revelar el contexto. Usar `CINEMA.camera()` para DOM y 3D fisico real para objetos.
- **Cortes invisibles:** match-on-action, whip-pan con salida y entrada complementarias, occlusion wipe, shape morph validado, mask reveal y paso 2D↔3D. **No** sustituir un morph real por un crossfade al describir el resultado.
- **Efectos con jerarquia:** motion blur direccional, brillos controlados, reflejos, micro-particulas, luces, estelas SVG, profundidad y sobresaltos musicales solo en beats clave. No abusar de lens flare, flashes, glitch ni rebotes.
- **UI veraz:** usar capturas o datos reales; reconstruccion fiel; nunca inventar funcionalidades, precios o pantallas de productos existentes. Los datos demo deben etiquetarse como tal.
- **Tipografia cinetica:** frases cortas, tracking y kerning trabajados, maxima legibilidad, jerarquia y ritmo sincronizado con la voz. La letra **se mueve por un motivo**, no por tener animacion.
- **Sonido narrativo:** toda interaccion importante puede tener SFX, no cada pixel. Cada evento sonoro debe anclarse a un cambio visual real. Revisar ausencia de clipping y balance VO/BGM.

Leer solo las referencias necesarias: [direccion](references/direccion-cinematografica.md), [transiciones](references/transiciones-y-morphing.md), [3D](references/pipeline-3d.md), [sonido](references/diseno-sonoro.md), [calidad](references/control-calidad.md), [integracion](references/hyperframes-oficial.md).

## Contrato de compatibilidad con HyperFrames

- Inspeccionar el `SKILL.md` oficial **instalado** antes de construir: el runtime/documentacion puede haber cambiado desde que se creo el kit original.
- HyperFrames hace seek sobre la linea de tiempo; toda animacion tiene que ser **determinista** al pedir un instante arbitrario. Timeline GSAP pausado y registrado por `data-composition-id`; no `requestAnimationFrame` suelto, intervalos, `Date.now`, random no sembrado ni loops infinitos.
- Scene clips: duracion y track declarados por HTML `class="clip"`, `data-start`, `data-duration`, `data-track-index`, segun la version instalada. Evitar animar `display`, `visibility` o `autoAlpha` en el elemento `.clip`; mover un hijo.
- Para imagen real/video, efectos de tratamiento (color, grain, blur, LUT) con `media-treatment` oficial y composicion adecuada, no CSS arbitrario que no respete render. No duplicar funciones del registry cuando exista un bloque oficial mantenido.
- Los scripts de `kit/` existentes son **legacy**. No afirmar que `examples/starter/index.html` cumple todas las exigencias del HyperFrames actual. Migrar envoltorios y tracks del proyecto creado, conservar comportamiento visual y probar frame por frame.
- Si una capacidad requiere un motor externo (Blender/Fusion/After Effects) usarlo solo si hay acceso real; producir una alternativa 2.5D cuando sea imposible, sin venderla como 3D fisico.

## Niveles de produccion

**N1 Producto:** capturas autenticas + camara UI + titulos + audio preciso.

**N2 Cinematico:** N1 + dispositivos 3D, match-cuts, transiciones narrativas, reflejos, sombras, estelas y color final.

**N3 Hero film:** N2 + simulacion/morph geometrico real, movimientos de camara 3D con continuidad, escenas Blender/compositing, composicion multipase, sonido cinematografico y revision de cada transicion. Escalar al nivel solicitado, no prometer N3 cuando solo haya piezas N1.

## Defaults y decisiones

- Calidad sobre cantidad; ritmo por actos, no efectos permanentes. Escenas 2D y 3D deben alternarse cuando ayuden a entender el producto.
- No forzar dialogos de confirmacion cuando la persona ya proporciono referencias, objetivo, capturas o autorizo producir todo. Solicitar solo las decisiones que cambian significativamente el resultado; si el usuario quiere ideas, presentar opciones.
- Para producciones dirigidas a gerentes de restaurante, mostrar **causa → flujo real de operacion → beneficio verificable** y no una lista generica de funcionalidades. Si un personaje de marca tiene canon, obtener sus assets verdaderos y mantener anatomia y animacion reales.
- No usar assets con licencias incompatibles ni publicar datos privados expuestos en capturas. Proteger las claves en variables de entorno / llavero.
- Cuando una herramienta falle o no exista, dar estado real, artefactos parciales validos y el comando preciso para continuar sin afirmar un resultado inexistente.

## Chequeos minimos antes de declarar terminado

1. Fuente de UI verificada y campos sensibles anonimizados.
2. Shotlist sin huecos ni tiempos negativos: `python scripts/validate_shotlist.py examples/cinema/shotlist.json`.
3. CLI HyperFrames `check` sin errores sin resolver; frames clave revisados visualmente.
4. Transiciones verificadas en **punto de entrada, 25%, 50%, 75% y salida**.
5. Render final reproducible sin negro inesperado, flashes accidentales, texto cortado, niveles excesivos o cortes de audio.
6. Documentacion final con archivos, herramientas realmente ejecutadas y limitaciones.

No es una skill que genere modelos 3D, voces, musica ni escenas por si misma: coordina codigo, herramientas y validacion para producirlos cuando estan disponibles.
