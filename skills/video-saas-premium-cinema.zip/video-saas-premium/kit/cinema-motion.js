/* Cinema Director Extension — deterministic GSAP helpers for HyperFrames.
 * Original kit/{motion-kit,premium,three-stage} files are not modified.
 * Call during composition construction, before registering its paused timeline.
 * Elements below must be CHILDREN of timed .clip nodes, never the .clip itself.
 */
(function (host) {
  "use strict";
  const D = (v, f) => (Number.isFinite(v) ? v : f);
  const POSITIVE = (v, name) => {
    if (!(Number.isFinite(v) && v > 0)) throw new Error(`${name} must be > 0`);
    return v;
  };
  const ensureInner = (element, name) => {
    if (!element) throw new Error(`Missing element: ${name}`);
    if (typeof element !== "string" && element.classList && element.classList.contains("clip"))
      throw new Error("Animate an inner element, not a HyperFrames .clip node");
    return element;
  };
  const target = (focal, scale, { width = 1920, height = 1080 } = {}) => {
    const [x, y] = focal;
    if (![x, y, scale, width, height].every(Number.isFinite)) throw new Error("Non-finite camera parameter");
    POSITIVE(scale, "camera.scale");
    return { x: width / 2 - x * scale, y: height / 2 - y * scale, scale };
  };
  const CINEMA = {
    /** Pure camera math; center focal canvas coordinates at chosen zoom. */
    focusTransform: target,
    /** Deterministic camera motion over a fixed duration. */
    camera(tl, child, o = {}) {
      ensureInner(child, "camera child");
      POSITIVE(o.duration ?? 0.8, "duration");
      const from = target(o.from?.focal ?? [960, 540], o.from?.scale ?? 1, o.stage);
      const to = target(o.to?.focal ?? [960, 540], o.to?.scale ?? 1, o.stage);
      tl.fromTo(child, { ...from, rotation: D(o.from?.angle, 0), transformOrigin: "0 0" },
        { ...to, rotation: D(o.to?.angle, 0), duration: o.duration ?? 0.8, ease: o.ease ?? "power3.inOut", immediateRender: false }, D(o.at, 0));
      return tl;
    },
    /** Match-cut: two visual layers share direction at the seam. Not an SVG morph. */
    matchCut(tl, o) {
      const a = ensureInner(o.outgoing, "outgoing");
      const b = ensureInner(o.incoming, "incoming");
      const dur = POSITIVE(o.duration ?? 0.24, "duration");
      const at = D(o.at, 0), dir = D(o.direction, 1), travel = D(o.travel, 160);
      const start = at - dur * 0.5;
      tl.fromTo(a, { x: 0, opacity: 1, scale: 1 },
        { x: -travel * dir, opacity: 0, scale: 1.05, duration: dur, ease: "power3.in", immediateRender: false }, start);
      tl.fromTo(b, { x: travel * dir, opacity: 0, scale: 0.95 },
        { x: 0, opacity: 1, scale: 1, duration: dur, ease: "power3.out", immediateRender: false }, start);
      return tl;
    },
    /** Fast spatial transition with coordinated exit / entrance. */
    whipPan(tl, o) {
      const exit = ensureInner(o.exit, "exit");
      const enter = ensureInner(o.enter, "enter");
      const at = D(o.at, 0), dur = POSITIVE(o.duration ?? 0.32, "duration");
      const distance = D(o.distance, 820), axis = o.axis === "y" ? "y" : "x", sign = o.sign === -1 ? -1 : 1;
      const exitProps = { [axis]: -distance * sign, opacity: 0, duration: dur * 0.6, ease: "power4.in", immediateRender: false };
      const startProps = { [axis]: distance * sign, opacity: 0 };
      const enterProps = { [axis]: 0, opacity: 1, duration: dur * 0.7, ease: "power4.out", immediateRender: false };
      tl.fromTo(exit, { [axis]: 0, opacity: 1 }, exitProps, at);
      tl.fromTo(enter, startProps, enterProps, at + dur * 0.3);
      return tl;
    },
    /** Kinetic title: the inputs must already be authored DOM elements. */
    kineticWords(tl, children, o = {}) {
      const nodes = Array.from(children);
      const at = D(o.at, 0), duration = POSITIVE(o.duration ?? 0.56, "duration");
      nodes.forEach((el, i) => {
        ensureInner(el, `word ${i}`);
        tl.fromTo(el, { opacity: 0, y: D(o.offsetY, 46), rotationX: D(o.angle, -15), scale: 0.97 },
          { opacity: 1, y: 0, rotationX: 0, scale: 1, duration, ease: o.ease ?? "expo.out", immediateRender: false }, at + i * D(o.stagger, 0.075));
      });
      return tl;
    },
    /** Draw an SVG stroke forward (route reveal, highlight, underline). */
    routeReveal(tl, path, o = {}) {
      ensureInner(path, "SVG path");
      if (typeof path.getTotalLength !== "function") throw new Error("routeReveal expects SVGPathElement");
      const length = path.getTotalLength();
      POSITIVE(length, "SVG path length");
      const dur = POSITIVE(o.duration ?? 1.3, "duration");
      path.setAttribute("stroke-dasharray", `${length} ${length}`);
      tl.fromTo(path, { attr: { "stroke-dashoffset": length } },
        { attr: { "stroke-dashoffset": 0 }, duration: dur, ease: o.ease ?? "power2.inOut", immediateRender: false }, D(o.at, 0));
      return tl;
    },
    /** Mask reveal = an occlusion transition, not a geometric morph. */
    occlusionReveal(tl, inner, o = {}) {
      ensureInner(inner, "occlusionReveal inner");
      const top = o.from === "top", side = o.from === "left";
      const clip = top ? "inset(0% 0% 100% 0%)" : side ? "inset(0% 100% 0% 0%)" : "inset(0% 0% 0% 100%)";
      tl.fromTo(inner, { clipPath: clip },
        { clipPath: "inset(0% 0% 0% 0%)", duration: POSITIVE(o.duration ?? 0.55, "duration"), ease: "power3.inOut", immediateRender: false }, D(o.at, 0));
      return tl;
    },
    /** Seeded DOM sparkle burst, built once and keyed on an explicit paused timeline. */
    sparkleBurst(tl, parent, o = {}) {
      if (!parent || typeof parent.appendChild !== "function") throw new Error("sparkleBurst requires a parent element");
      const count = Math.max(1, Math.min(96, Math.floor(D(o.count, 22))));
      const at = D(o.at, 0), duration = POSITIVE(o.duration ?? 0.65, "duration");
      let seed = ((o.seed ?? 11927) >>> 0) || 1;
      const rnd = () => { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return (seed >>> 0) / 4294967296; };
      const out = [];
      for (let i = 0; i < count; ++i) {
        const dot = document.createElement("span");
        dot.className = "cinema-spark";
        dot.style.cssText = `position:absolute;left:${D(o.x, 0)}px;top:${D(o.y, 0)}px;width:${D(o.size, 3)}px;height:${D(o.size, 3)}px;border-radius:50%;background:${o.color ?? "#ffd79b"};pointer-events:none;will-change:transform,opacity;`;
        parent.appendChild(dot);
        const theta = 2 * Math.PI * rnd(), r = D(o.radius, 130) * (0.3 + 0.7 * rnd());
        tl.fromTo(dot, { x: 0, y: 0, scale: 0.2, opacity: 0 },
          { x: Math.cos(theta) * r, y: Math.sin(theta) * r, scale: 1.1 + rnd(), opacity: 1,
            duration: duration * 0.6, ease: "power2.out", immediateRender: false }, at);
        tl.to(dot, { opacity: 0, duration: duration * 0.4, ease: "power1.in" }, at + duration * 0.6);
        out.push(dot);
      }
      return out;
    }
  };
  host.CINEMA = CINEMA;
})(typeof window !== "undefined" ? window : globalThis);
