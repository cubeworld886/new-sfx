/* Real outline-geometry interpolation for compatible SVG polygons.
 * This is a 2D vertex morph, not a 3D mesh morph, SDF morph or a mere crossfade.
 * Author both point sets with identical vertex count and winding.
 */
(function (host) {
  "use strict";
  function validate(points, label) {
    if (!Array.isArray(points) || points.length < 3) throw new Error(`${label} needs >=3 vertices`);
    for (const point of points) {
      if (!Array.isArray(point) || point.length !== 2 || !point.every(Number.isFinite))
        throw new Error(`Invalid vertex in ${label}`);
    }
  }
  function lerpPolygon(a, b, t) {
    validate(a, "from"); validate(b, "to");
    if (a.length !== b.length) throw new Error("Morph source/target must have equal vertex counts");
    if (!Number.isFinite(t)) throw new Error("Morph progress must be finite");
    const p = Math.min(1, Math.max(0, t));
    return a.map((v, i) => [v[0] + (b[i][0] - v[0]) * p, v[1] + (b[i][1] - v[1]) * p]);
  }
  const pathString = (pts) => pts.map(([x, y], i) => `${i ? "L" : "M"}${x.toFixed(3)} ${y.toFixed(3)}`).join(" ") + " Z";
  function morphPath(path, a, b, t) {
    if (!path || typeof path.setAttribute !== "function") throw new Error("SVG <path> required");
    path.setAttribute("d", pathString(lerpPolygon(a, b, t)));
  }
  function onTimeline(tl, path, from, to, { at = 0, duration = 1, ease = "power2.inOut" } = {}) {
    if (!(Number.isFinite(duration) && duration > 0)) throw new Error("duration must be > 0");
    const state = { progress: 0 };
    morphPath(path, from, to, 0);
    tl.fromTo(state, { progress: 0 },
      { progress: 1, duration, ease, immediateRender: false, onUpdate: () => morphPath(path, from, to, state.progress) }, at);
    return state;
  }
  host.VECTOR_MORPH = { lerpPolygon, pathString, morphPath, onTimeline };
})(typeof window !== "undefined" ? window : globalThis);
