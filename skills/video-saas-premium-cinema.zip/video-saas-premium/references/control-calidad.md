# Control de calidad / Review Protocol

## Puertas de calidad (sin saltar pasos)

### G0 — Proveniencia

- UI de cliente verificada contra captura. Comprobar nombre, numero, icono, estado, fuente, espaciado y textos.
- Datos personales, tokens, correos y sesiones redactados antes de exponer material.
- Licencia/documentacion de modelos 3D, musica, SFX, tipografias y fotos.
- Confirmar si se generaron assets por IA; no presentarlos como capturas oficiales.

### G1 — Tiempos

```bash
python scripts/validate_shotlist.py examples/cinema/shotlist.json
```

Validar FPS, duracion en frames, continuidad, escenas sin huecos, motivos compartidos. Anotar timing de voz y motivos de cada transicion, no solo el titulo de la animacion.

### G2 — Composicion HyperFrames

```bash
npx hyperframes check --json
npx hyperframes snapshot --review
```

Los flags exactos pueden cambiar; consultar `/hyperframes-cli` instalado y `npx hyperframes --help`. Revisar fallos; no tapar warnings con `data-layout-allow-*` a menos que el solapamiento sea intencional.

**Revision visual obligatoria:** inicio, final, primer resultado legible de cada escena; en cada union, fotogramas al 0%, 25%, 50%, 75% y 100%; dos frames anteriores y posteriores al corte. Preguntar: ¿continuidad de velocidad/direccion? ¿texto legible? ¿capas coherentes? ¿se congela alguna escena? ¿se ve la UI autentica? ¿pestañea un canvas 3D en seek aleatorio?

### G3 — QA del MP4

```bash
python scripts/review_video.py salida.mp4 --out review/ --shotlist shotlist.json --sample-fps 1
```

Genera `review/contact-sheet.png`, `review/report.json` y muestras JPEG. **No sustituye** inspeccion humana o vision contextual, solo senala muestras negras/blancas, cambios masivos y posibles holds de forma heuristica. Son posibles falsos positivos con fondos blancos, cortes intencionales o momentos dramaticos oscuros.

Verificar adicionalmente: codecs, duracion, bitrate razonable, pixel dimensions, fps real, audio presente, ausencia de clipping, volumen, sincronizacion, safe areas, y primer/ultimo frame exportados.

### G4 — Rendimiento

- Medir tiempos de render y memoria con un plano complejo y el frame de mayor carga.
- Si GSAP/Three.js falla al buscar fotogramas hacia atras, la escena no es determinista.
- Cargas de assets deben completarse antes del render, no depender de red inestable.
- Comprobar dispositivos/formatos solicitados (16:9, 9:16, 1:1 son composiciones especificas, no un crop automatico que corte CTA).

### G5 — Entrega

Acompanar MP4 con: directorio fuente, version del motor, resultado de QA, captura de 4–8 frames, shotlist y una lista de assets autorizados. Marcar **verificado**, **no verificado** o **bloqueado** por cada paso. Si no hay herramienta para render, entregar proyecto/artefactos parciales y comandos reproducibles, sin decir "video terminado".

## Matriz de fallos frecuentes

| Fallo | Causa posible | Correccion |
| --- | --- | --- |
| Canvas vacio a tiempos arbitrarios | Se uso RAF/deltaTime en vez de seek absoluto | Render cada estado desde `t`, registrar timeline 3D |
| Flash blanco al cruzar escenas | Capa sin fondo, oclusion incompleta, post bloom | Animar child wrappers; revisar frame intermedio |
| UI falsa, texto borroso | Captura estirada, assets inventados o baja resolucion | Reproducir desde captura real a escala 1:1 |
| Whip sin energia | Salida y entrada con distintas aceleraciones/direcciones | Cuidar curva, desplazamiento y blur direccional |
| "Morph" que parece fade | No existe malla/poligono intermediario | Vector path real o disimular corte por oclusion; documentar |
| Tirones al aparecer titulos | Efectos SVG/composicion muy caros, cambio de layout | Precalcular geometria, evitar layout thrash, revisar GPU |
| Sonido fuera de beat | Timeline de audio independiente estimado | Marcas de tiempo por palabra/transitorio; escuchar MP4 |
| Render no coincide con preview | Asset remoto/cache, animacion no seek-safe | Assets locales, seed fija, buscar snapshots aleatorios |
