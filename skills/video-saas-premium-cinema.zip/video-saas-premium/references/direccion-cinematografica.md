# Direccion cinematografica orientada a producto

## Lo que hace memorable a una secuencia

Usar **una idea visual transformable**, no diez afirmaciones juntas. Una pelicula comercial de 30 s puede tener 6–9 planos, pero cada plano debe revelar algo que el usuario pueda hacer con el producto. Las transiciones deben representar la relacion entre procesos. La estetica (negro, cristal, metal, glow, 3D) queda subordinada al significado.

El anuncio de referencia analizado usa una cadena funcional: marca → compra → localizacion → envio → paquete 3D → confirmacion → cierre tipografico. Se puede adoptar **el metodo de continuidad y el nivel de craft**, no copiar el metraje, ilustraciones o diseño protegido de un tercero.

### Documento director (SPEC.md)

Escribir una ficha de una pagina con:

- **Verdad del producto:** que hace de manera verificable, para quien, bajo que condicion y con que resultado.
- **Promesa dramatica:** un cambio concreto visible desde el principio al final.
- **Motivo conductor:** una figura, color, linea, sonido o gesto que evoluciona.
- **Paleta y materiales:** fondo / superficie / acento / iluminacion / profundidad, con muestras reales de marca.
- **Ritmo:** tiempos de curiosidad (hold), acciones, impactos y respiracion.
- **Comportamiento de camara:** cada plano con focal, escala, altura, orientacion, duracion, curva y velocidad en la union.
- **Fuente de autenticidad:** captura, vector oficial, audio aprobado, prueba visible y licencias.
- **Criterios de aceptacion:** frame legible, interfaz fiel, transicion sin flash, voz audible, logo reconocible.

## Gramática de un plano premium

1. **Anticipacion** (0.12–0.3 s): un movimiento da contexto y direccion.
2. **Aparicion** (0.2–0.65 s): el sujeto entra, con blur y volumen moderados.
3. **Demostracion** (0.6–2.8 s): mostrar la accion real, con informacion suficiente para comprender.
4. **Resolucion** (0.3–1.0 s): el resultado queda quieto antes de la transicion siguiente.
5. **Conexion** (0.16–0.55 s): transferir energia a la siguiente escena con un motivo comun.

Estas son **referencias creativas**, no reglas temporales absolutas. Un frame hero puede respirar mucho mas; un montage musical puede requerir cortes rapidos.

## Matriz de continuidad

Para cada union A → B, definir por lo menos dos de estas variables: posicion, silueta, color, direccion, velocidad, profundidad, sonido, accion. El ancla de A debe tener un destino explicito en B.

| Salida A | Entrada B | Mecanismo propuesto |
| --- | --- | --- |
| Punto luminoso en icono | Cursor de una UI | Match-cut de posicion + escala + clic con SFX |
| Barra de progreso | Ruta sobre mapa | Morph vectorial de linea (SVG con camino compatible) |
| Tarjeta rectangular | Pantalla del telefono | Occlusion + camara 2.5D; no declarar morph 3D |
| Mesa circular del mapa | Detalle de mesa 3D | Match-cut de silueta + movimiento de camara |
| Paquete entrando desde la derecha | Palabra que entra desde la derecha | Whip paralelo + corte oculto por oclusion |

**Una secuencia sin ancla es un cambio de diapositiva, no una transicion narrativa.**

## Direccion para software real

- Enseñar primero el mundo de trabajo del cliente: barra, mesa, cocina, inventario, recepcion, gimnasio, etc.
- Mostrar una sola operacion sobre la UI real, con zoom que siga el punto de atencion, no un panoramico generico.
- Cortar hacia el resultado confirmado de la operacion. Evitar nombres de estados, porcentajes o datos ficticios.
- Hacer que el movimiento de los elementos (linea, tarjeta, cuadrante, rotacion) signifique transferencia de informacion.
- Terminar con marca, beneficio especifico verificable y contacto autentico cuando el usuario lo provea.

## Planos prohibidos por defecto

- Stock de personas sonriendo sin relacion con el producto.
- Proliferacion de pantallas inventadas; dashboard futurista sin lectura util.
- Zooms de 250% que cortan las palabras y no revelan ninguna accion.
- Tipografia gigante y lemas vacios: «la revolucion del futuro», «sin limites» si no hay prueba.
- Flashes de blanco, glitch repetitivo, ondas arbitrarias, lens flares excesivos, particulas por todas partes.
- Sonido de impacto en cada letra sin contexto musical o narrativo.

## Tres sabores de direccion

**Film de objeto:** caja, telefono, logotipo extruido y reflejos; sensacion material. Requiere Blender o Three.js y luces reales.

**Film de interfaz:** camara del cursor, gestos, llamadas-respuesta, mapas, tarjetas; alta densidad de informacion real.

**Film tipografico:** palabras cortas, escala, profundidad, caida de energia, silencios y cortes invisibles; exige sonido preciso.

Se pueden combinar en un mismo comercial, alternando materiales segun la historia.
