# Direccion sonora: musica, voz y sound design

Esta referencia complementa `references/voz-y-musica.md` y `references/sfx.md` del proyecto original. **Esas herramientas y scripts siguen siendo la base.**

## Construir el mapa sonoro a partir del mapa de movimiento

Cada plano debe tener una fila en el shotlist con los eventos sonoros **anclados a una accion visible**. Establecer: instante de inicio, pico del gesto, colas, pista musical, prioridad y rango frecuencial.

- **VO:** transmitir la idea (beneficio verificable) con respiracion. No narrar todos los elementos visuales si se entienden solos.
- **UI:** clic, friccion del swipe, tipo de tecla, confirmacion con cola breve. Diferenciar un rechazo de un exito en la textura sonora.
- **3D:** introducir whoosh espacial, roce de material, resonancia y cierre grave en los cambios de masa.
- **Transicion:** seleccionar un unico elemento dominante: whip, impacto o exhalacion. Los secundarios deben dejar espacio.
- **Ambiente:** capas sutiles que conecten espacios; si cambia a 3D abstracto, la reverberacion y el timbre explican el cambio.

## Guia de mezcla, no dogma

- Mantener voz inteligible, deesser cuando haga falta; limpiar ruido, respiraciones molestas y consonantes demasiado duras.
- Reducir (ducking) la musica y los SFX cuando entra voz. Hacer fades con tiempos conscientes, no cortes bruscos por palabra.
- Como punto de partida para plataformas sociales puede considerarse ~−16 LUFS integrado y true peak ≤−1 dBTP; **adaptar a cada medio y requisitos del cliente**. El numero no garantiza una buena mezcla.
- Comprobar clipping, ausencia de clicks en cortes, no saturacion en mono, picos de baja frecuencia, colas truncadas y sincronizacion labial/por palabra cuando exista voz o personaje.
- No extraer musica comercial no licenciada ni usar SFX de licencias restrictivas. Guardar lista de licencias y atribuciones.

## Procedimiento concreto

1. Preparar el guion, locutor y marcas de palabra. Si se usa ElevenLabs, reutilizar `scripts/eleven_vo.py`; nunca registrar la API key en los archivos.
2. Marcar el downbeat de la solucion: ahi se abre la capa musical, sube brillo tonal y se revela la UI/objeto.
3. Para cada transicion escoger **un** pico SFX. Usar `scripts/sfx_curate.py` para materiales aprobados y `scripts/audio_tools.py` para inspeccion.
4. Introducir silencio intencional antes de un impacto cuando la historia lo justifique, sin mutear la voz por accidente.
5. Renderizar prueba de audio, escuchar con audifonos y altavoz pequeno, comprobar MP4 final.

## Cues repetibles (ejemplo, no audio incorporado)

| Evento | SFX | Entrada/cola |
| --- | --- | --- |
| Foco sobre boton real | soft click + transient corto | 1–2 frames antes del contacto; cola <0.2 s |
| Pantalla → ruta | airy whoosh + trazo granular | 0.1 s antes del inicio; pico cuando se completa |
| Morph de logotipo | riser corto con pitch controlado | crece con cambio de geometria; no exagerar |
| Caja 3D aterriza | thunk suave + subgrave limitado | pico al contacto, fade natural de cola |
| Marca final | acorde breve + cola amplia | dejar leer CTA y logotipo |

No implementar audio propio cuando `/media-use` o el CLI oficial actual incluyen un procedimiento superior para una tarea concreta.
