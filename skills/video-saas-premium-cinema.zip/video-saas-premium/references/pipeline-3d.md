# Pipeline 3D y composicion cinematografica

## Elegir la tecnica, no una marca de software

| Necesidad | Implementacion recomendada |
| --- | --- |
| UI real en un iPhone que gira sutilmente | `kit/three-stage.js` y Three.js; textura tomada de la UI real |
| Mascota canonica con rig/morph targets existentes | Importar geometria, articulaciones, animaciones y materiales **originales**; no redibujar ni inventar ojos o extremidades |
| Packshot premium metal/vidrio, reflejos fisicos | Blender + luces de estudio, HDRI legal, render por pases |
| Toma de UI con profundidad simulada | Capas DOM/2.5D y `CINEMA.camera`; identificarla como 2.5D |
| Morph entre objetos 3D radicalmente distintos | Correspondencia de malla validada, simulacion o cambio por oclusion; un fundido no es morph |
| Composicion, luz y tratamiento de metraje | Fusion de DaVinci Resolve, Blender Compositor o herramientas equivalentes presentes |

## Escena 3D hero: checklist

1. Convertir el logo del cliente en SVG/paths validos. Para extruir: comparar geometria resultante con el logo real, sin simplificarlo hasta perder identidad.
2. Modelo de dispositivo a escala plausible; material PBR, roughness, clearcoat y metalness con limites creibles. Cuidar normal maps y color-space de texturas.
3. Pantalla de la app: textura viva desde capturas/estado real; evitar chat simulado o datos sintéticos presentados como reales.
4. 3 luces utiles: key grande (forma), fill discreto (lectura), rim controlado (separacion). Emision de luces no debe sobreexponer texto.
5. Sombra de contacto/occlusion en superficies. Reflejo debe corresponder a entorno.
6. Camara lente virtual (p. ej. 35–65 mm equivalente) con DOF solo si no reduce la legibilidad de la UI. No confundir FOV con zoom arbitrario.
7. Render 3D con determinismo por tiempo. Usar `t` absoluto para `position`, `quaternion`, morph targets, luces, materiales; no simular por integracion variable.
8. Si se renderiza Blender por separado: anotar FPS, resolucion, alpha, color-space, primer frame y ultimo frame; sincronizar con el timeline HyperFrames.

## Transiciones 2D → 3D sin salto

- Congelar el key visual (pantalla, icono, barra de progreso), casar tamaño/rotacion/profundidad y conservar direccion.
- Transformar el estado visible en plano/texture `CanvasTexture` o render textura de la UI al colocarlo dentro del modelo 3D.
- En una ventana breve (0.15–0.4 s) realizar occlusion/match de silueta, no crossfade flotante de la escena completa.
- Un zoom que entra en la UI puede salir a través de un cristal real 3D si existe la geometria intermedia; si no, esconder el corte bajo el bisel.
- Para un paneo entre escenas, cuidar aceleracion y direccion; una rotacion aparente invertida del siguiente plano provoca discontinuidad.

## Rendimiento y calidad

- Validar primero a 1080p/30 o fps de preview; despues comprobar 4K/60 si fue solicitado y es posible. No vender un upscale de texturas 720p como detalle nativo 4K.
- Adaptar `devicePixelRatio`, texture sizes, antialiasing, sombras y samples al render. Controlar la memoria GPU.
- Limitar las luces con shadow maps costosos, bloom global y partículas transparentes superpuestas. Un frame con buena luz es mejor que 300 efectos compitiendo.
- Preferir geometry instancing para particulas repetidas y usar alta densidad solo para planos donde el detalle se ve.
- Mantener reversibilidad: conservar `.blend`, `.glb`, fuentes de textura, parametros de render y composiciones.

## No prometer lo que no se ha comprobado

El uso de Blender, Resolve o After Effects exige acceso a la instalacion correspondiente. La skill no los trae incluidos. Si no estan, producir la mejor variante posible con Three.js/HyperFrames o dejar un pase de composicion claramente identificado, sin declarar completa una simulacion inexistente.
