# Transiciones, morphing, camara y continuidad temporal

## Clasificar honestamente la transformacion

- **Match-cut:** A y B tienen un ancla visual o movimiento que coincide; puede haber un corte escondido. No es un morph geometrico.
- **Whip pan:** A acelera fuera y B entra con direccion y velocidad compatibles. Mantener exposicion, paleta y distorsion acordes.
- **Occlusion:** un objeto, borde, marco o superficie cubre completamente la imagen y al descubrirla revela otra escena. El corte ocurre cuando la oclusion domina.
- **Shape morph:** una silueta **realmente cambia de geometria**. Para SVG, interpolar vertices compatibles o recurrir a un algoritmo de remuestreo/morph especializado y comprobado.
- **3D morph:** mallas con correspondencia de vertices o un mecanismo fisico/topologico equivalente; los modelos no se vuelven un morph solo por escalar o desvanecer uno sobre otro.
- **Light streak:** un trazo con luminancia controlada arrastra la atencion. No convertirlo en pantalla blanca.
- **Camera bridge:** trayectoria de camara continua entre dos entornos con un objeto comun, empleando un corte por oclusion si los entornos no son una escena 3D unica.

## Usar extensiones nuevas sin romper el kit anterior

Incluir `kit/cinema-motion.js` luego de GSAP y **despues** de la creacion de la estructura de escenas:

```js
const tl = gsap.timeline({paused: true});
CINEMA.camera(tl, document.querySelector('#ui-inner'), {
  at: 2.2, duration: 0.9, from: {focal:[960, 540], scale:1},
  to: {focal:[1180, 460], scale:1.72}, ease:'power3.inOut'
});
CINEMA.matchCut(tl, {
  outgoing: document.querySelector('#out-inner'),
  incoming: document.querySelector('#in-inner'),
  at: 3.6, duration: 0.26, direction: 1, travel: 190
});
window.__timelines['my-composition-id'] = tl;
```

Las funciones actuan sobre hijos de `.clip`; **no** en el propio `.clip` como prohibe el contrato actual. Autorizar ambos planos y sus tracks en la composicion oficial; las transiciones necesitan visibilidad y tiempo de solapamiento apropiados. Inspeccionar `hyperframes/references/format.md` y `hyperframes-cli` version instalados.

### Morph SVG de vertices comprobables

Incluir `kit/vector-morph.js`:

```js
const path = document.querySelector('#morph-shape');
const hex = [[0,50],[25,7],[75,7],[100,50],[75,93],[25,93]];
const box = [[0,0],[50,0],[100,0],[100,100],[50,100],[0,100]];
VECTOR_MORPH.onTimeline(tl, path, hex, box, {at:4.0,duration:0.75});
```

Esto es **morph 2D real** porque los puntos de la figura cambian; no hay crossfade. Ambas figuras deben tener igual numero de vertices, orden de recorrido y puntos semanticos correspondientes; si no, se producirian torsiones. Para letras, siluetas complejas, agujeros o figuras con topologia distinta, usar una herramienta adecuada y probar con snapshots a 25%, 50%, 75%.

### SVG route, motion blur y sonido

```js
CINEMA.routeReveal(tl, document.querySelector('#route-path'), {at:7.3, duration:0.92});
```

Animar un stroke SVG predefinido y acompañar el extremo con un punto real; usar el `MKP.blurOf` original sobre DOM de titulos cuando convenga. Si el sujeto es metraje, aplicar blur/tratamiento con la via oficial (`media-use`) y no con filtros CSS arbitrarios que cambien entre frame preview y render.

## Seek-safety: el criterio que evita renders rotos

- Animar estados numericos reproducibles desde el tiempo, no «acumular velocidad cada frame».
- Para Three.js, al renderizar el frame `t` calcular posicion/rotacion/estado segun `t`, sin `deltaTime` acumulativo ni random nuevo; usar semillas estables.
- No usar `setInterval`, `requestAnimationFrame` autonomo, loops infinitos ni playback manual durante la captura de HyperFrames.
- Registrar un solo timeline principal pausado por composicion segun la skill oficial.
- No modificar `display`, `visibility`, `autoAlpha` en los nodos `.clip`. Envolver y animar un `*-inner`.
- Revisa **puntos 0, 25, 50, 75, 100%** de cada transicion, capturas de saltos temporales adelante/atras y frames en los limites de clip.

## Direccion de easing

- `expo.out`: llegada/impacto rapido + asentamiento, usar una vez en un gesto protagonista.
- `power3.inOut`: travel de camara o cambio de escala con continuidad moderada.
- `power4.in`: aceleracion terminal de whip. Complementar con entrada `power4.out`.
- `sine.inOut`: orbita y respiracion suaves, siempre finitas y compatibles con seek.

Evitar aplicar un rebote en cada elemento: hace que la interfaz parezca juguete y deteriora lectura. Ajustar curvas a la musica y a la masa visual real.
