# Integracion oficial de HyperFrames (sin alterar upstream)

## Fuente confiable

- Repositorio oficial: https://github.com/heygen-com/hyperframes
- Guia de instalacion: https://github.com/heygen-com/hyperframes/blob/main/docs/guides/skills.mdx
- Fuente exacta de los bundles publicados: `skills/` del repositorio anterior.
- Estado de referencia consultado el 2026-10-27: commit `3b2058a2b7a2ebb36abd5887c35aa48f7398a389`; **la ultima version al instalar puede cambiar**.
- Archivo de manifiesto oficial: `skills-manifest.json` (lista los bundles y numero de ficheros). La copia instalada debe corresponder a un unico commit en GitHub.
- Licencia del repositorio oficial: Apache-2.0. Conservar los avisos de licencia originales; consultar licencia upstream vigente antes de redistribuir.

## Los siete bundles OFICIALES

| Skill upstream intacta | Dominio | Ficheros segun manifiesto consultado |
| --- | --- | ---: |
| `hyperframes` | Director de video, contrato, tipos de film, review | 77 |
| `hyperframes-cli` | Init, lint, timeline, snapshot, render, Studio | 13 |
| `hyperframes-registry` | Componentes, transiciones, bibliotecas | 13 |
| `media-use` | Musica, clips, voz, captions, imagenes y tratamientos | 116 |
| `figma` | Assets, tokens, storyboard desde Figma | 2 |
| `remotion-to-hyperframes` | Portar composiciones/codigo anterior | 78 |
| `slideshow` | Presentaciones interactivas | 2 |

**No mezclar estos bundles dentro del propio SKILL.md.** Cada uno debe conservar su directorio y todos sus archivos sin modificaciones. `video-saas-premium` es una octava skill propia y **coordina** las siete oficiales como compañeras.

## Instalacion completa con verificacion de bytes

La descarga de 301 archivos no se incluye como copia offline en `skill.zip` porque las fuentes remotas no pudieron materializarse en este entorno de creacion. En su lugar, `scripts/install_official_hyperframes.py` hace un `git clone --sparse` del repositorio oficial, copia las siete carpetas sin editar ningun byte, calcula el SHA-256 de cada archivo y lo compara despues de instalar. Registra la SHA del commit de origen **fuera** de los directorios oficiales.

Desde la carpeta de la nueva skill:

```bash
python scripts/install_official_hyperframes.py --agent both
# Solo Claude Code:
python scripts/install_official_hyperframes.py --agent claude
# Solo Codex:
python scripts/install_official_hyperframes.py --agent codex
# Revisar antes, sin copiar:
python scripts/install_official_hyperframes.py --agent both --dry-run
# Para fijar exactamente el commit observado el 2026-10-27:
python scripts/install_official_hyperframes.py --agent both --commit 3b2058a2b7a2ebb36abd5887c35aa48f7398a389
```

En Windows, usar `py` si `python` no esta en PATH; estos comandos funcionan en PowerShell. Requiere **Git y conexion HTTPS**. Si los bundles actuales difieren, los preserva y avisa; `--force` respalda cada carpeta antes de sustituirla. Una instalacion correcta imprime `installed-exact` o `already-identical`; si indica `conflict-preserved`, no considerarla completa.

Para no modificar el directorio global, instalar en una carpeta temporal con `--target C:\\ruta\\skills` y revisar. El argumento `--source C:\\ruta\\hyperframes` usa un checkout oficial ya disponible, sin red. Ejecutar con permisos de usuario normales; no hace falta elevacion.

Metodo alternativo oficial, administrado por el propio CLI:

```bash
npx hyperframes skills           # los 7 bundles publicados
npx hyperframes skills update    # actualiza el conjunto core y otros ya instalados
```

En Claude Code existe tambien el plugin versionado oficial:

```bash
claude plugin marketplace add heygen-com/hyperframes
claude plugin install hyperframes@hyperframes
```

No ejecutar simultaneamente instalador de Git y plugin si eso crea instalaciones duplicadas sin comprender las rutas. El origen oficial puede cambiar sus instrucciones, por lo que preferir su documentacion actual sobre memorias antiguas.

## Contrato de precedencia

1. Si cambia la sintaxis del CLI o de composiciones, seguir `hyperframes/SKILL.md` y `hyperframes-cli/SKILL.md` efectivamente instalados.
2. Antes de codificar un efecto comun buscarlo en `hyperframes-registry`; preferir un bloque fiable en lugar de duplicarlo.
3. `media-use` gobierna licencias, generacion/ingesta y tratamiento de material multimedia.
4. El kit `video-saas-premium/kit/` continua util, pero si el starter heredado contradice el contrato, actualizar la **composicion del proyecto**, no alterar los archivos oficiales.
5. Mantener cada bundle oficial como skill independiente: el instalador no inyecta ficheros de esta extension en ellos.

## Comprobacion de instalacion

- En la carpeta de skills del agente deben existir los siete subdirectorios con su respectivo `SKILL.md` y referencias.
- La procedencia queda en `.hyperframes-official-source.json` **fuera** de cada subdirectorio.
- Reiniciar Claude Code o Codex para que recargue las skills.
- Ejecutar `/hyperframes` o citar `hyperframes` en la tarea; si el agente no reconoce el comando, inspeccionar rutas de descubrimiento y la version de la herramienta.
