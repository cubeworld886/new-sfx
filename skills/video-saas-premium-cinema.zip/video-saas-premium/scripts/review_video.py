#!/usr/bin/env python3
"""Generate a storyboard contact sheet and objective media diagnostics from an MP4.

Requires ffmpeg + ffprobe and Pillow. No AI vision. Highlight anomalies for
human review; heuristics never assert that an intentional cut is a defect.
"""
from __future__ import annotations

import argparse
import json
import math
import shutil
import subprocess
import sys
from pathlib import Path


def command(*args, timeout=150):
    p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
    if p.returncode:
        raise RuntimeError(f"{' '.join(map(str, args[:3]))}: {p.stderr[-1800:]}")
    return p.stdout


def probe(video: Path):
    data = command("ffprobe", "-v", "error", "-show_entries", "format=duration,size:stream=index,codec_type,codec_name,width,height,avg_frame_rate", "-of", "json", str(video), timeout=30)
    return json.loads(data)


def seam_checkpoints(data):
    if not isinstance(data, dict): return []
    fps = data.get("fps", 30)
    if not isinstance(fps, (int, float)) or fps <= 0: return []
    times = []
    for shot in data.get("shots", [])[:-1]:
        edge = shot.get("end_frame")
        if not isinstance(edge, int): continue
        transition = shot.get("transition_to_next", {})
        window = max(1, int(transition.get("duration_frames", 1))) if isinstance(transition, dict) else 1
        half = window / (2.0 * fps)
        seam = edge / fps
        times.append({"from": shot.get("id"), "seam_seconds": round(seam, 3),
                      "keyframes_seconds": [round(max(0, seam + half * x), 3) for x in (-1, -0.5, 0, 0.5, 1)]})
    return times


def summarize(images, sample_fps):
    from PIL import Image, ImageChops, ImageStat
    metrics, previous = [], None
    for i, path in enumerate(images):
        with Image.open(path) as src:
            gray = src.convert("L")
            stat = ImageStat.Stat(gray)
            mean, stddev = stat.mean[0], stat.stddev[0]
            change = None
            if previous is not None:
                diff = ImageChops.difference(gray, previous)
                change = round(ImageStat.Stat(diff).mean[0], 2)
            metrics.append({"frame_index": i, "seconds": round(i / sample_fps, 3),
                            "mean_luma": round(mean, 2), "luma_stddev": round(stddev, 2),
                            "sampled_change": change})
            previous = gray.copy()
    notes = []
    for i, d in enumerate(metrics):
        if d["mean_luma"] < 7 and d["luma_stddev"] < 7:
            notes.append(f"Near-black sample at {d['seconds']}s (could be intentional)")
        if d["mean_luma"] > 245 and d["luma_stddev"] < 6:
            notes.append(f"Near-white sample at {d['seconds']}s (inspect for a flash)")
        if d["sampled_change"] is not None and d["sampled_change"] > 86:
            notes.append(f"Very large change around {d['seconds']}s (inspect cut/transition)")
    freeze = 0
    for d in metrics[1:]:
        if d["sampled_change"] is not None and d["sampled_change"] < 0.15:
            freeze += 1
            if freeze == max(3, round(sample_fps * 2)):
                notes.append(f"Potential extended stillness ending at {d['seconds']}s (could be a deliberate hold)")
        else: freeze = 0
    return metrics, notes


def contact_sheet(images, metrics, dest, columns=4):
    from PIL import Image, ImageDraw
    w, h, caption_h, margin = 400, 225, 28, 14
    cols = min(columns, len(images))
    rows = math.ceil(len(images) / cols)
    sheet = Image.new("RGB", (cols * (w + margin) + margin, rows * (h + caption_h + margin) + margin), (22, 23, 28))
    draw = ImageDraw.Draw(sheet)
    for i, path in enumerate(images):
        left = margin + (i % cols) * (w + margin)
        top = margin + (i // cols) * (h + caption_h + margin)
        with Image.open(path) as src:
            thumb = src.convert("RGB")
            thumb.thumbnail((w, h), Image.Resampling.LANCZOS)
            x = left + (w - thumb.width) // 2
            y = top + (h - thumb.height) // 2
            sheet.paste(thumb, (x, y))
        label = f"{metrics[i]['seconds']:.2f}s  |  L={metrics[i]['mean_luma']:.0f}"
        draw.text((left + 6, top + h + 6), label, fill=(234, 236, 242))
    sheet.save(dest, "PNG", optimize=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("video", type=Path)
    ap.add_argument("--out", type=Path, default=Path("video-review"))
    ap.add_argument("--shotlist", type=Path)
    ap.add_argument("--sample-fps", type=float, default=1.0)
    ap.add_argument("--max-samples", type=int, default=160)
    args = ap.parse_args()
    if not args.video.is_file():
        print("ERROR: video not found", file=sys.stderr); return 1
    if not all(shutil.which(x) for x in ("ffmpeg", "ffprobe")):
        print("ERROR: ffmpeg and ffprobe required", file=sys.stderr); return 1
    if not 0.2 <= args.sample_fps <= 8 or not 1 <= args.max_samples <= 500:
        print("ERROR: invalid fps/max-samples", file=sys.stderr); return 1
    try:
        from PIL import Image  # noqa: F401
    except ImportError:
        print("ERROR: Pillow required (pip install Pillow)", file=sys.stderr); return 1
    args.out.mkdir(parents=True, exist_ok=True)
    try:
        info = probe(args.video)
        duration = float(info["format"]["duration"])
        fps = min(args.sample_fps, args.max_samples / duration) if duration else args.sample_fps
        fps = max(fps, 0.01)
        pattern = str(args.out / "sample_%04d.jpg")
        command("ffmpeg", "-hide_banner", "-nostdin", "-loglevel", "error", "-y", "-i", str(args.video),
                "-an", "-vf", f"fps={fps:.8f},scale=640:-2:flags=lanczos", "-q:v", "4", "-frames:v", str(args.max_samples), pattern,
                timeout=max(60, min(300, duration * 3)))
        images = sorted(args.out.glob("sample_*.jpg"))
        if not images: raise RuntimeError("ffmpeg did not extract any images")
        metrics, warnings = summarize(images, fps)
        sheet = args.out / "contact-sheet.png"
        contact_sheet(images, metrics, sheet)
        seams = []
        if args.shotlist:
            seams = seam_checkpoints(json.loads(args.shotlist.read_text(encoding="utf-8")))
        report = {"file": str(args.video), "duration_seconds": round(duration, 3),
                  "tracks": info.get("streams", []), "sample_fps": round(fps, 3), "frames_reviewed": len(images),
                  "warnings": warnings, "seam_keyframes_to_inspect": seams, "samples": metrics,
                  "contact_sheet": str(sheet)}
        (args.out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"Reviewed {len(images)} frames; {len(warnings)} candidates for inspection")
        print(f"CONTACT_SHEET: {sheet}\nREPORT: {args.out / 'report.json'}")
        return 0
    except (RuntimeError, OSError, ValueError, KeyError, subprocess.TimeoutExpired) as e:
        print(f"ERROR: {e}", file=sys.stderr); return 1


if __name__ == "__main__":
    sys.exit(main())
