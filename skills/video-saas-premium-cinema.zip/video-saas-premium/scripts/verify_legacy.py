#!/usr/bin/env python3
"""Verify all original video-saas-premium assets/scripts/refs were preserved."""
from __future__ import annotations
import hashlib
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EDITED_FOR_ORCHESTRATION = {"SKILL.md", "README.md", "agents/openai.yaml"}


def main():
    manifest = json.loads((ROOT / "references/original-manifest.json").read_text(encoding="utf-8"))
    original = ROOT / "assets/video-saas-premium-original.zip"
    errors = []
    if hashlib.sha256(original.read_bytes()).hexdigest() != manifest["source_zip_sha256"]:
        errors.append("Original ZIP is not byte-identical")
    with zipfile.ZipFile(original) as archive:
        for path, expected in manifest["sha256_files"].items():
            src = f"video-saas-premium/{path}"
            if hashlib.sha256(archive.read(src)).hexdigest() != expected:
                errors.append(f"Original archive entry changed: {path}")
            if path in EDITED_FOR_ORCHESTRATION:
                continue
            dest = ROOT / path
            if not dest.is_file():
                errors.append(f"Original file is missing: {path}")
            elif hashlib.sha256(dest.read_bytes()).hexdigest() != expected:
                errors.append(f"Original content changed: {path}")
    for key, stored in (("SKILL.md", "SKILL-original.md"), ("README.md", "README-original.md")):
        copy = ROOT / "references" / stored
        if hashlib.sha256(copy.read_bytes()).hexdigest() != manifest["sha256_files"][key]:
            errors.append(f"The copy of the original {key} is corrupted")
    print("Original assets check:", "PASS" if not errors else "FAIL")
    print("Checked", len(manifest["sha256_files"]), "original files; only entrypoint, README and agent metadata replaced")
    for x in errors: print("ERROR:",x)
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
