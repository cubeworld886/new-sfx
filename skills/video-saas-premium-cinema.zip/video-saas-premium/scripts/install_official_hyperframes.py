#!/usr/bin/env python3
"""Install all seven official HyperFrames skill directories verbatim, as peers.

Source: https://github.com/heygen-com/hyperframes/tree/main/skills
Requires Git and outbound HTTPS unless --source points to a local clone.
No official file is edited, inserted into, or removed from the copied skill dirs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

REPO = "https://github.com/heygen-com/hyperframes.git"
NAMES = (
    "hyperframes", "hyperframes-cli", "hyperframes-registry", "media-use",
    "figma", "remotion-to-hyperframes", "slideshow",
)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def snapshot(directory: Path) -> dict[str, str]:
    if not directory.is_dir():
        raise ValueError(f"Directory not found: {directory}")
    result = {}
    for p in sorted(directory.rglob("*")):
        if p.is_symlink():
            raise ValueError(f"Symlink disallowed in official copy: {p}")
        if p.is_file():
            result[p.relative_to(directory).as_posix()] = sha256(p)
    if "SKILL.md" not in result:
        raise ValueError(f"Official skill is missing SKILL.md: {directory}")
    return result


def run(*argv: str) -> str:
    try:
        p = subprocess.run(argv, text=True, capture_output=True, check=True, timeout=180)
        return p.stdout.strip()
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as exc:
        detail = getattr(exc, "stderr", "") or str(exc)
        raise RuntimeError(f"Command failed: {' '.join(argv)}\n{detail[:1800]}") from exc


def agents_targets(kind: str, scope: str, project_dir: Path) -> list[Path]:
    home = Path.home()
    base = project_dir.resolve() if scope == "project" else home
    names = [".claude", ".codex"] if kind == "both" else [".claude" if kind == "claude" else ".codex"]
    return [base / name / "skills" for name in names]


def copy_exact(src: Path, target: Path, *, force: bool, dry_run: bool) -> dict:
    reference = snapshot(src)
    if target.is_symlink():
        raise ValueError(f"Refusing to replace symlink: {target}")
    if target.exists():
        actual = snapshot(target)
        if actual == reference:
            return {"status": "already-identical", "files": len(actual)}
        if not force:
            return {"status": "conflict-preserved", "files": len(actual)}
    if dry_run:
        return {"status": "would-install" if not target.exists() else "would-replace", "files": len(reference)}
    target.parent.mkdir(parents=True, exist_ok=True)
    staged = Path(tempfile.mkdtemp(prefix=".hf-stage-", dir=str(target.parent)))
    # mkdtemp creates staging dir; only copy src files into it.
    try:
        shutil.copytree(src, staged, dirs_exist_ok=True, symlinks=False)
        if snapshot(staged) != reference:
            raise RuntimeError(f"Byte verification failed before install: {src.name}")
        if target.exists():
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            backup = target.with_name(f"{target.name}.backup-{stamp}")
            i = 1
            while backup.exists():
                backup = target.with_name(f"{target.name}.backup-{stamp}-{i}")
                i += 1
            target.rename(backup)
        staged.rename(target)
        if snapshot(target) != reference:
            raise RuntimeError(f"Byte verification failed after install: {target}")
        return {"status": "installed-exact", "files": len(reference)}
    finally:
        if staged.exists():
            shutil.rmtree(staged)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--agent", choices=["claude", "codex", "both"], default="both")
    ap.add_argument("--scope", choices=["user", "project"], default="user")
    ap.add_argument("--project-dir", type=Path, default=Path.cwd())
    ap.add_argument("--target", type=Path, help="Explicit destination skill parent directory; overrides agent/scope")
    ap.add_argument("--source", type=Path, help="Offline path to an unchanged official HyperFrames repository checkout")
    ap.add_argument("--commit", help="Optional official commit SHA/tag to pin; default HEAD of main")
    ap.add_argument("--force", action="store_true", help="Back up conflicting directories before replacing")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args(argv)
    roots = [args.target.expanduser().resolve()] if args.target else agents_targets(args.agent, args.scope, args.project_dir)
    workdir = None
    try:
        if args.source:
            source = args.source.expanduser().resolve()
            commit = "local-checkout"
            if (source / ".git").exists():
                try:
                    commit = run("git", "-C", str(source), "rev-parse", "HEAD")
                except RuntimeError:
                    pass
        else:
            if not shutil.which("git"):
                raise RuntimeError("Git not found. Install Git or run `npx hyperframes skills` from the official HyperFrames CLI.")
            workdir = tempfile.TemporaryDirectory(prefix="hyperframes-official-")
            source = Path(workdir.name) / "hyperframes"
            print("Downloading official upstream (sparse Git clone)...", flush=True)
            run("git", "clone", "--depth", "1", "--filter=blob:none", "--sparse", REPO, str(source))
            if args.commit:
                run("git", "-C", str(source), "fetch", "--depth", "1", "origin", args.commit)
                run("git", "-C", str(source), "checkout", "--detach", "FETCH_HEAD")
            run("git", "-C", str(source), "sparse-checkout", "set", "skills")
            commit = run("git", "-C", str(source), "rev-parse", "HEAD")
        upstream = source / "skills"
        for skill in NAMES:
            snapshot(upstream / skill)
        result = {"source": REPO, "commit": commit, "skills": {}, "destinations": [str(x) for x in roots], "dry_run": args.dry_run}
        errors = 0
        for dest in roots:
            for skill in NAMES:
                info = copy_exact(upstream / skill, dest / skill, force=args.force, dry_run=args.dry_run)
                result["skills"][f"{dest}/{skill}"] = info
                print(f"{info['status']:>20} {dest / skill} ({info['files']} files)")
                if info["status"] == "conflict-preserved":
                    errors += 1
        if not args.dry_run and not errors:
            for dest in roots:
                dest.mkdir(parents=True, exist_ok=True)
                meta = dest / ".hyperframes-official-source.json"
                meta.write_text(json.dumps({"repository": REPO, "commit": commit, "installed_skills": list(NAMES), "timestamp_utc": datetime.now(timezone.utc).isoformat()}, indent=2) + "\n", encoding="utf-8")
        print(f"Official commit: {commit}")
        if errors:
            print("Conflicts were preserved. Run with --force to back up and replace them after review.", file=sys.stderr)
        return 2 if errors else 0
    except (RuntimeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    finally:
        if workdir is not None:
            workdir.cleanup()


if __name__ == "__main__":
    raise SystemExit(main())
