#!/usr/bin/env python3
"""Validate cinematic shot timeline/continuity without third-party dependencies.

Usage: python scripts/validate_shotlist.py examples/cinema/shotlist.json [--strict] [--json]
"""
import argparse
import json
import sys
from pathlib import Path

TRANSITIONS = {"cut", "match-cut", "whip", "occlusion", "shape-morph", "camera-bridge", "3d-morph", "fade"}


def validate(data):
    errors, warnings = [], []
    if not isinstance(data, dict):
        return ["JSON root must be an object"], warnings
    fps = data.get("fps", 0)
    if not isinstance(fps, int) or not 1 <= fps <= 240:
        errors.append("fps must be an integer between 1 and 240")
        fps = 30
    total = data.get("total_frames", 0)
    if not isinstance(total, int) or total <= 0:
        errors.append("total_frames must be a positive integer")
    shots = data.get("shots")
    if not isinstance(shots, list) or not shots:
        return errors + ["shots must be a nonempty array"], warnings
    ids = set()
    previous = None
    for index, s in enumerate(shots):
        label = f"shot[{index}]"
        if not isinstance(s, dict):
            errors.append(f"{label} must be an object"); continue
        sid = s.get("id")
        if not isinstance(sid, str) or not sid.strip():
            errors.append(f"{label}.id required")
        elif sid in ids:
            errors.append(f"{label}.id repeated: {sid}")
        ids.add(sid)
        begin, end = s.get("start_frame"), s.get("end_frame")
        if not all(isinstance(x, int) and not isinstance(x, bool) for x in [begin, end]):
            errors.append(f"{label} start/end frames must be integers")
            continue
        if begin < 0 or end <= begin:
            errors.append(f"{label} invalid frame range [{begin},{end})")
        if previous is None and begin != 0:
            errors.append("first shot must start at frame 0")
        elif previous is not None:
            if begin != previous["end_frame"]:
                errors.append(f"{label} starts {begin}; prior shot ends {previous['end_frame']} (gap/overlap)")
            a = previous.get("transition_to_next", {})
            trans = a.get("type", "cut") if isinstance(a, dict) else "cut"
            if trans not in TRANSITIONS:
                errors.append(f"{previous.get('id')}: unknown transition: {trans}")
            elif trans != "cut" and trans != "fade":
                motif_from = previous.get("motif_exit")
                motif_to = s.get("motif_entry")
                if not motif_from or not motif_to:
                    errors.append(f"{previous.get('id')} -> {sid}: missing transition motif")
                elif motif_from != motif_to:
                    warnings.append(f"{previous.get('id')} -> {sid}: motifs differ ({motif_from} != {motif_to}); justify match manually")
            if trans in {"shape-morph", "3d-morph"}:
                if not isinstance(a.get("geometry_pair"), list) or len(a["geometry_pair"]) != 2:
                    errors.append(f"{previous.get('id')} -> {sid}: morph requires two geometry_pair assets")
            d = a.get("duration_frames", 0) if isinstance(a, dict) else 0
            if not isinstance(d, int) or d < 0 or d > fps * 2:
                errors.append(f"{previous.get('id')}: transition duration must be 0..{fps*2} frames")
            if trans not in {"cut", "fade"} and d == 0:
                warnings.append(f"{previous.get('id')}: transition requested with zero duration")
        cam = s.get("camera", {})
        if cam:
            for key in ("from", "to"):
                c = cam.get(key)
                if not isinstance(c, dict) or not isinstance(c.get("focal"), list) or len(c["focal"]) != 2 or not all(isinstance(x, (int, float)) for x in c["focal"]):
                    errors.append(f"{label}.camera.{key}.focal must have two numeric entries")
                if not isinstance(c, dict) or not isinstance(c.get("scale"), (int, float)) or c["scale"] <= 0:
                    errors.append(f"{label}.camera.{key}.scale must be positive")
                elif c["scale"] > 4.5:
                    warnings.append(f"{label}.camera.{key}: very high zoom ({c['scale']})")
        if not s.get("purpose"):
            warnings.append(f"{label}: missing story purpose")
        if not s.get("sources"):
            warnings.append(f"{label}: no referenced real UI/brand/3D source")
        if not s.get("sound"):
            warnings.append(f"{label}: no sound direction (silence may be intentional)")
        previous = s
    if isinstance(total, int) and previous and isinstance(previous.get("end_frame"), int) and previous["end_frame"] != total:
        errors.append(f"last shot ends at {previous['end_frame']} != total_frames ({total})")
    if data.get("output", {}).get("width") and data.get("output", {}).get("height"):
        w,h = data["output"]["width"],data["output"]["height"]
        if not (isinstance(w, int) and isinstance(h, int) and w > 0 and h > 0):
            errors.append("output.width/height must be positive integers")
    return errors, warnings


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("shotlist", type=Path)
    parser.add_argument("--strict", action="store_true", help="Treat warnings as failure")
    parser.add_argument("--json", action="store_true", help="Machine-readable report")
    args = parser.parse_args()
    try:
        data = json.loads(args.shotlist.read_text(encoding="utf-8"))
        errors, warnings = validate(data)
    except (OSError, json.JSONDecodeError) as e:
        errors, warnings = [str(e)], []
    result = {"ok": not errors and (not args.strict or not warnings), "errors": errors, "warnings": warnings}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("SHOTLIST", "PASS" if result["ok"] else "FAIL")
        for e in errors: print(" ERROR:", e)
        for w in warnings: print("  WARN:", w)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
