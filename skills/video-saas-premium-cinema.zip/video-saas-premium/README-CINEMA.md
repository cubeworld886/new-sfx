# VIDEO SAAS PREMIUM — CINEMA DIRECTOR EDITION

**Extension aditiva del paquete `video-saas-premium` original.** Conserva intactos los helpers JS/Three.js/GSAP, scripts de branding y voz, SFX y starter. Incorpora direccion de comerciales cinematograficos, herramientas de morph/transiciones y QA, y un instalador de las **7 skills oficiales de HyperFrames**.

## Instalar en Claude Code o Codex

1. Extraer `skill.zip` para que quede:

```
~/.claude/skills/video-saas-premium/SKILL.md
# o en Windows: %USERPROFILE%\.claude\skills\video-saas-premium\SKILL.md
# o Codex: ~/.codex/skills/video-saas-premium/SKILL.md
```

2. Instalar **los siete bundles upstream oficiales intactos** desde GitHub (requiere Git/red) en las carpetas de ambos agentes:

```
cd ~/.claude/skills/video-saas-premium
python scripts/install_official_hyperframes.py --agent both
```

En Windows PowerShell: `py scripts\install_official_hyperframes.py --agent both` desde el directorio de la skill. Para probar con un checkout previamente clonado: `--source /ruta/al/hyperframes`. Para instalar solo Codex: `--agent codex`. El instalador **no sobreescribe** skills preexistentes diferentes sin `--force`; si se usa `--force` hace una copia de seguridad. Reiniciar los agentes para descubrir las nuevas skills.

3. En Claude Code o Codex pedir:

> Usa video-saas-premium y las skills oficiales de HyperFrames. Quiero un comercial de 30 segundos para mi producto, cinematico 2D/3D, con continuidad de objetos entre escenas, zooms de UI real, efectos luminosos, diseño sonoro, transiciones y revision fotograma a fotograma. Reutiliza mis capturas y assets de marca.

## Estructura

- `SKILL.md`: instrucciones del director cinematografico y orquestacion.
- `kit/`: **todo** el kit original + `cinema-motion.js`, `vector-morph.js`, `cinema-motion.css`.
- `scripts/`: herramientas originales + instalador seguro y validadores de shotlist/video.
- `references/`: documentacion original + direccion, morphing, 3D, mezcla, review, integracion oficial.
- `examples/starter/`: ejemplo original conservado.
- `examples/cinema/`: plantilla de shotlist para una produccion profesional (referencia, aun necesita capturas reales).
- `tests/`: tests offline de las herramientas nuevas.
- `assets/video-saas-premium-original.zip`: ZIP original exacto para restaurar o comparar.
- `references/original-manifest.json`: SHA-256 de cada archivo original.

## La limitacion importante

**Este paquete no incluye el motor de render HyperFrames ni Blender, DaVinci, ElevenLabs o librerias externas:** instala/usa esas dependencias donde el agente este trabajando. Para respetar los archivos oficiales **sin modificarlos**, no se han pegado/copiado parcialmente en la skill: el instalador obtiene las 7 skills completas desde el propio repositorio oficial y comprueba que la copia conserva exactamente los bytes de origen. Esto requiere una instalacion adicional con red.

## Salida de calidad

Un comercial terminado implica MP4 real, fuentes editables, efectos de sonido legales, `SPEC.md`, shotlist, muestras/snapshots de todas las transiciones, comprobacion de sonido y QA. La skill **no puede garantizar** produccion en 4K60 sin hardware/CLI/recursos correctos; verifica antes de prometer.

## Licencias

- Paquete original, copyright 2026 Rayyan Montoya, licencia MIT (`LICENSE`).
- HyperFrames es propiedad de sus autores y se distribuye bajo la licencia oficial del repositorio (Apache-2.0 en el momento de esta version); las siete skills se instalan directamente de la fuente y se mantienen separadas.
- Recursos externos y musica/modelos: licencias de cada archivo. No redistribuir fuentes, SFX ni musica de terceros sin autorizacion.
